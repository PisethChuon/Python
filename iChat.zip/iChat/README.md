# iChat

## Scope of Your App
    Decide on features:
        - Core Feature: Real-time messaging, user authentication, message history, ... etc.
        - Additional Features: Typing indicator, media sharing, group chats, ... etc.
    Target audience and platform:
        - Is it for both (Android and iOS)

## Set Up Enviroment
    Set up Firbase:
        - If decide going to use firbase.
        - ...

## Implement Core Functionlities
    User authentication
        - Use firebase authentication (on the table)
        - ...

    Chat Backend (on the table)
        - Option 1: Use Firbase firestore
        - Option 2: Build a custom backend

    Real-Time Messaging (on the table)

    UI design
        - Figma

## Manage State
    Choose a state management solution:
        - GetX (easy to use and efficient).

## Test the App
    Test on multiple devices (real devices).
    Focus on both functional and performance testing
        - Message delivery speed.
        - Handling of offline scenarios.

## Deploy the App
    Generate API and iOS
    Publish to app stores:
        - Google play store
        - Apple App store

## Optional Enhancements
    Push notifications
    Media Sharing
    Group Chats

## On the table
    flutter_local_notifications
    image_picker
    getx
    cached_network_image

## Hight Level Design of iChat Messenger

The following steps describe the communication between both clients:

- User A and User B create a communication channel with the chat server.
- User A send a message to the chat server
- Upon receiving the message, the chat server acknowledges back to user A.
- The chat server sends the message to user B and stores the message in the database if the receiver's status is offline.
- User B sends an achnowledgment to the chat server.
- The chat server notifies user A that the message has been successfully delivered.
- When user B read the message, the application notifies that chat server.
- The chat server notifies user A that user B has read the message.