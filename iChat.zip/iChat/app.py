import os
import requests
from requests_oauthlib import OAuth2Session
from oauthlib.oauth2 import WebApplicationClient

# Replace with your own credentials
CLIENT_ID = '468223077763-qui6gn8ggs600gd8o4h5apjjabkeissj.apps.googleusercontent.com'
CLIENT_SECRET = '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'
AUTHORIZATION_BASE_URL = 'https://accounts.google.com/o/oauth2/auth'  # For Google
TOKEN_URL = 'https://accounts.google.com/o/oauth2/token'  # For Google
REDIRECT_URI = 'http://localhost:8000/callback'  # Set this to your redirect URI

# Step 1: Create an OAuth2Session
oauth = OAuth2Session(CLIENT_ID, redirect_uri=REDIRECT_URI)

# Step 2: Get the authorization URL
authorization_url, state = oauth.authorization_url(AUTHORIZATION_BASE_URL)
print('Please go to this URL and authorize the app:', authorization_url)

# Step 3: Get the authorization response from the user
redirect_response = input('Paste the full redirect URL here: ')

# Step 4: Fetch the token
oauth.fetch_token(TOKEN_URL, authorization_response=redirect_response, client_secret=CLIENT_SECRET)

# Step 5: Make an authenticated request
# This example is for Google API; adjust if using other services
user_info = oauth.get('https://www.googleapis.com/oauth2/v1/userinfo')
print('User info:', user_info.json())
