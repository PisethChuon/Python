# DRR

It is a daily non-gaming report automation project.

Here are the list of documents.

- [User Guide](./doc/user-guide/user-guide.md)
- [Test Plan](./doc/test-plan/test-plan.md)
- [SDD](./doc/sdd/sdd.md)
