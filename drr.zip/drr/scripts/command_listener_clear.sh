#!/bin/bash
cd /home/malinka/projects/drr_cmd/app
source .venv/bin/activate
python3 -m drr.command_listener clear
