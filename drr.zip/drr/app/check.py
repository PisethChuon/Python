import time
from drr import config_reader

config = config_reader.get()
print('---config values---')
for key, value in config.items():
    print(f"{key} -> {value}")

while True:
    print('I\'m running.')
    time.sleep(10)