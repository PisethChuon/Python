"""
Command Listener Module

It listens to any command given through email's subject by the users.

Author: Phann Malinka
"""

import logging
import sqlite3
import sys
import time
import traceback
from drr.email import get_email_account, search_unread_emails_by_subject, send_email
from drr import config_reader
from drr.my_logger import logger
import datetime
from drr.report import run_report, get_log_attachment_data
from drr.db import find_running_logs, force_fail, insert_fail_log
from drr.util import *
from drr.util_config import *


config = config_reader.get()

# set the starting logging level
logger.setLevel(logging.INFO)

email_account = get_email_account(0)

sqlite_conn = sqlite3.connect(SQLITE_FILE)
sqlite_cur = sqlite_conn.cursor()
result = sqlite_conn.execute(f"SELECT count(name) FROM sqlite_master WHERE type='table' AND name='service'")
counts = result.fetchone()

# check if table service is there
if counts[0] == 0:
    sqlite_conn.execute("CREATE TABLE service(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, status INTEGER, created_dt TEXT DEFAULT CURRENT_TIMESTAMP, modified_dt TEXT DEFAULT CURRENT_TIMESTAMP)")
    logger.debug(f"table service was just created in {SQLITE_FILE}")


def clear():
    # make sure to reset the command listener clear if it is taking too long
    sqlite_cur.execute(f"UPDATE service SET status = 0, modified_dt = CURRENT_TIMESTAMP WHERE name = '{COMMAND_LISTENER_CLEAR}'"
                    f"AND status = 1 AND modified_dt <= datetime('now', '-{config[CLEAR_TIMEOUT]} minute')")
    sqlite_conn.commit()

    """
    check if command listener clear was already running.
    1. if it wasn't, insert a new record by setting status = 1
    2. if it was, exit
    """
    result = sqlite_cur.execute(f"SELECT status FROM service WHERE name = '{COMMAND_LISTENER_CLEAR}'")
    statuses = result.fetchone()
    if statuses == None:
        sqlite_cur.execute(f"INSERT INTO service (name, status) VALUES ('{COMMAND_LISTENER_CLEAR}', 1)")
        sqlite_conn.commit()
    elif statuses[0] == 1:
        logger.info(f"{COMMAND_LISTENER_CLEAR} was still running")
        exit(0)
    elif statuses[0] == 0:
        sqlite_cur.execute(f"UPDATE service SET status = 1, modified_dt = CURRENT_TIMESTAMP "
                            f"WHERE name = '{COMMAND_LISTENER_CLEAR}' AND status = 0")
        sqlite_conn.commit()

    timeout = int(config[CLEAR_TIMEOUT])
    logger.info(f"[{COMMAND_LISTENER_CLEAR}]: set status = FAIL for those commands that not yet finished within {timeout} minutes")
    force_fail(timeout)
    
    # update service status
    sqlite_cur.execute(f"UPDATE service SET status = 0, modified_dt = CURRENT_TIMESTAMP WHERE name = '{COMMAND_LISTENER_CLEAR}'")
    sqlite_conn.commit()


def run():
    # make sure to reset the command listener run if it is taking too long
    sqlite_cur.execute(f"UPDATE service SET status = 0, modified_dt = CURRENT_TIMESTAMP WHERE name = '{COMMAND_LISTENER_RUN}'"
                        f"AND status = 1 AND modified_dt <= datetime('now', '-{config[CLEAR_TIMEOUT]} minute')")
    sqlite_conn.commit()

    """
    check if command listener run was already running.
    1. if it wasn't, insert a new record by setting status = 1
    2. if it was, exit
    """            
    # check if command listener run was still running
    result = sqlite_cur.execute(f"SELECT status FROM service WHERE name = '{COMMAND_LISTENER_RUN}'")
    statuses = result.fetchone()
    if statuses == None:
        sqlite_cur.execute(f"INSERT INTO service (name, status) VALUES ('{COMMAND_LISTENER_RUN}', 1)")
        sqlite_conn.commit()
    elif statuses[0] == 1:
        logger.info(f"{COMMAND_LISTENER_RUN} was still running")
        exit(0)
    
    logger.debug(f"[{COMMAND_LISTENER_RUN}]: starts")
    
    """
    search for emails that contains the commands.
    search only in today from 00:00:00 till 23:59:59
    """
    now = datetime.datetime.now()
    search_from_date = datetime.datetime(year=now.year, month=now.month, day=now.day)
    search_to_date = datetime.datetime(year=now.year, month=now.month, day=now.day, 
                                    hour=23, minute=59, second=59)
    emails = search_unread_emails_by_subject(email_account=email_account, subject="das",
                            search_from=search_from_date, search_to=search_to_date)
    command_issuers = config[COMMAND_ISSUERS].split(",")

    # log the reject emails
    rejected_emails = [e for e in emails if e.sender.email_address not in command_issuers]
    for e in rejected_emails:
        datetime_received = e.datetime_received.astimezone(email_account.default_timezone)
        logger.debug(f"[{COMMAND_LISTENER_RUN}]: Rejected Email: subject: {e.subject}, sender={e.sender.email_address}, received at={datetime_received}")

    # work on the accepted emails
    for i in command_issuers:
        accepted_emails = [e for e in emails if e.sender.email_address == i]
        logger.info(f"[{COMMAND_LISTENER_RUN}]: Found {len(accepted_emails)} accepted unread emails from {i}")
        if logger.level == logging.DEBUG:
            for e in accepted_emails:
                datetime_received = e.datetime_received.astimezone(email_account.default_timezone)
                logger.debug(f"[{COMMAND_LISTENER_RUN}]: datetime received: {datetime_received}")
                logger.debug(f"[{COMMAND_LISTENER_RUN}]: sender: {e.sender}")
                logger.debug(f"[{COMMAND_LISTENER_RUN}]: subject: {e.subject}")

        if len(accepted_emails) == 0:
            continue
        
        # we only want the latest email
        email = accepted_emails[0]

        # mark that email as read
        email.is_read = True
        email.save(update_fields=['is_read'])

        datetime_received = email.datetime_received.astimezone(email_account.default_timezone)
        datetime_received_db = datetime.datetime(year=datetime_received.year, month=datetime_received.month,
                                                day=datetime_received.day, hour=datetime_received.hour,
                                                minute=datetime_received.minute, 
                                                second=datetime_received.second).strftime(DB_DT_FORMAT)
        logger.info(f"[{COMMAND_LISTENER_RUN}]: Receive command: {email.subject} from {email.sender.email_address} at {datetime_received_db}")
        
        # check if we already handle it before
        found_logs = find_running_logs(receive_dt=datetime_received_db)
        if len(found_logs) > 0:
            logger.info(f"[{COMMAND_LISTENER_RUN}]: The command={email.subject} received at {datetime_received_db} was already handled")
            continue

        # parse the command
        report_date = None
        splitted_command = email.subject.split(" ")
        if email.subject == 'das run':
            today = datetime.datetime.now()
            yesterday = today - datetime.timedelta(days=1)
            report_date = yesterday
            debug_level = logging.INFO
        elif len(splitted_command) == 4:
            # das run info 2024-07-07
            debug_level = splitted_command[2].upper()
            report_date = datetime.datetime.strptime(splitted_command[3], "%Y-%m-%d")
        else:
            logger.info(f"[{COMMAND_LISTENER_RUN}]: Invalid command received: {email.subject}")

            """
            to avoid sending this email again and again, 
            we insert this fail command into database
            """
            insert_fail_log(command=email.subject, run_by=email.sender.email_address, receive_dt=datetime_received_db)

            log = f"""
            <p>DateTime Received: {datetime_received_db}<p>
            <p>Command Issuer: {email.sender.email_address}</p>
            <p>Received Command: {email.subject}</p>
            <p>Status: INVALID</p>
            <p>Detail: das run or das run info/debug report_date</p>
            """
            subject = config[MAIL_NOTIFY_FAIL5_SUBJECT]
            recipient_groups = read_recipients(config[MAIL_NOTIFY_FAIL5_RECIPIENTS])
            for g in recipient_groups:
                send_email(email_account=email_account, 
                        subject=subject, 
                        body=log,
                        to_recipients=g["to"],
                        cc_recipients=g["cc"],
                        bcc_recipients=g["bcc"])
            continue
        
        run_report(report_date=report_date, log_level=debug_level, command=email.subject, run_by=i, receive_dt=datetime_received_db, caller=COMMAND_LISTENER_RUN)
        logger.info(f"[{COMMAND_LISTENER_RUN}]: command={email.subject} received at {datetime_received_db} is just successfully handled")
        
        # sleep for 5 seconds before checking commands sent from another user
        time.sleep(5)

    # update service status
    sqlite_cur.execute(f"UPDATE service SET status = 0, modified_dt = CURRENT_TIMESTAMP WHERE name = '{COMMAND_LISTENER_RUN}'")
    sqlite_conn.commit()


if __name__ == "__main__":
    """
    Support the following commmands through email subject

    >>> das run
    - run DDR Automation Script
    - in log level = INFO
    - with report date = yesterday

    >>> das run debug 2024-07-07
    - run DDR Automation Script
    - in log level = DEBUG
    - with report date = 2024-07-07

    >>> das run info 2024-07-07
    - run DDR Automation Script
    - in log level = INFO
    - with report date = 2024-07-07

    das stands for DRR Automation Script

    In debug level, more log detail will be generated
    In info level, log detail will be lot less, this is the default level

    This command listener supports the following arguments.

    - run to fetch the new commands from inbox
    - clear to update those commands that were started long ago, and not yet stopped.
    """
    
    args = sys.argv[1:]

    if len(args) != 1:
        logger.error("Command Syntax")
        logger.error("python -m drr.command_listener run")
        logger.error("python -m drr.command_listener clear")
        exit(0)

    try:

        if args[0] == 'clear':
            clear()
        
        elif args[0] == 'run':
            run()
    
    except Exception as e:
        print(traceback.format_exc())
        logger.error(str(e))
        try:
            """
            if email_account is not None:
                subject = config[MAIL_NOTIFY_FAIL5_SUBJECT]
                recipient_groups = read_recipients(config[MAIL_NOTIFY_FAIL5_RECIPIENTS])
                for g in recipient_groups:
                    send_email(email_account=email_account,
                            subject=subject,
                            body=None,
                            to_recipients=g["to"],
                            cc_recipients=g["cc"],
                            bcc_recipients=g["bcc"],
                            attachments=get_log_attachment_data())
            """
        except Exception as e:
            logger.error(str(e))
    finally:
        """
        to tell logger it is time to send the log to all handlers.
        """
        if logger.level == logging.DEBUG:
            logger.debug("\n")
        elif logger.level == logging.INFO:
            logger.info("\n")
        elif logger.level == logging.WARNING:
            logger.warning("\n")
        elif logger.level == logging.ERROR:
            logger.error("\n")
        elif logger.level == logging.CRITICAL:
            logger.critical("\n")
