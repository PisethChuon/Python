"""
Logger module is to configure the logging.
Make sure that this module is used instead of the generic logging.

Author: Phann Malinka
"""
from datetime import datetime
import logging.handlers
import sys
import os
from drr.db_log_handler import DbLogHandler
from drr import config_reader
from drr.util_config import *

config = config_reader.get()
now = datetime.now()
log_file = os.path.join(config[LOG_DIR], f"drr-{now.strftime('%Y%m%d')}.log")
logger = logging.getLogger("drr")

"""
we want to print the log to
1- console
2- file
3- database
"""
console_handler = logging.StreamHandler(sys.stdout)

# max size 5mb
file_handler = logging.handlers.RotatingFileHandler(
    log_file, maxBytes=(1048576*5), backupCount=7
)

db_handler = DbLogHandler()

# format of the log
formatter = logging.Formatter("%(asctime)s [%(filename)s:%(lineno)s:%(funcName)s()] %(levelname)s: %(message)s")

file_handler.setFormatter(formatter)
console_handler.setFormatter(formatter)

logger.addHandler(console_handler)
logger.addHandler(file_handler)
logger.addHandler(db_handler)

