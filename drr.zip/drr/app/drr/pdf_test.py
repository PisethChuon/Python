""""
PDF test module is to test PDF module.

Author: Phann Malinka
"""
import datetime
from dotenv import dotenv_values
from drr import db
from drr.pdf import create_pdf
from drr.util import get_sheets_data

config = dotenv_values(".env")


def test_create_pdf():
    today = datetime.datetime.now()
    yesterday = today - datetime.timedelta(days=1)
    report_date = yesterday.strftime("%d%m%y")
    report_file_name = f"{config['report_name']} {report_date}"
    pdf_file = f'tmp/{report_file_name}.pdf'
    structure_df = db.get_structure()
    sheet_dict = get_sheets_data(structure_df, yesterday)
    create_pdf(sheet_dict, yesterday, pdf_file)


if __name__ == '__main__':
    test_create_pdf()
