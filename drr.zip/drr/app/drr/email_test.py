"""
Email test module is to test email module.

Author: Phann Malinka
"""

from drr import email
from drr import excel


def test_send_email():
   pass

if __name__ == '__main__':
    test_send_email()
