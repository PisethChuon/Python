"""
PDF module is to take care of generating the PDF document.

Author: Phann Malinka
"""
import datetime
from html import escape
from drr import config_reader
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT, TA_CENTER
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch, cm
from reportlab.platypus import Paragraph, Table, TableStyle, PageBreak, SimpleDocTemplate
import pandas as pd
from drr.my_logger import logger
from drr.util import *
from drr.util_config import *


config = config_reader.get()

def create_pdf_header(report_date: datetime.datetime):
    """
    Create header for pdf file

    @param report_date - the date of report
    @return elements of header
    """
    logger.debug(f"create pdf header >>> report_date={report_date}")

    elements = []

    styles = getSampleStyleSheet()

    title_parent_style = "Heading2"

    report_date_print = report_date.strftime('%d %b %Y')
    report_day_print = report_date.strftime('%a')

    # report header line1
    title_line1 = Paragraph(config[REPORT_TITLE_LINE1],
                            ParagraphStyle(
                                parent=styles[title_parent_style],
                                fontSize=pdf_font_size,
                                name="title",
                                wordWrap="LTR",
                                alignment=TA_LEFT,
                            ))

    # report header line2
    title_line2 = Paragraph(config[REPORT_TITLE_LINE2],
                            ParagraphStyle(
                                parent=styles[title_parent_style],
                                fontSize=pdf_font_size,
                                name="title",
                                wordWrap="LTR",
                                alignment=TA_LEFT,
                            ))
    
    report_date_title = Paragraph("Date:",
                                  ParagraphStyle(
                                      parent=styles[title_parent_style],
                                      fontSize=pdf_font_size,
                                      name="title",
                                      alignment=TA_LEFT
                                  ))

    report_date_value = Paragraph(report_date_print,
                                  ParagraphStyle(
                                      parent=styles[title_parent_style],  
                                      fontSize=pdf_font_size,
                                      name="title",
                                      #wordWrap="LTR",
                                      alignment=TA_CENTER
                                  ))

    report_date_table = Table([
        [report_date_title, report_date_value]
    ], colWidths=[1.1 * cm, 2.2 * cm])

    report_day_title = Paragraph("Day:",
                                 ParagraphStyle(
                                     parent=styles[title_parent_style],
                                     fontSize=pdf_font_size,
                                     name="title",
                                     alignment=TA_LEFT
                                 ))

    report_day_value = Paragraph(report_day_print,
                                 ParagraphStyle(
                                     parent=styles[title_parent_style],
                                     fontSize=pdf_font_size,
                                     name="title",
                                     #wordWrap="LTR",
                                     alignment=TA_CENTER
                                 ))

    report_day_table = Table([
        [report_day_title, report_day_value]
    ], colWidths=[1.1 * cm, 2.2 * cm])

    header_table = Table([
        [title_line1, report_date_table],
        [title_line2, report_day_table]
    ], colWidths=[7 * cm, None], rowHeights=[0.5 * cm, 0.5 * cm])

    header_table.setStyle(TableStyle([
        ("ALIGN", (0, 0), (0, -1), "LEFT"),
        ("ALIGN", (1, 0), (1, -1), "RIGHT"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ('TOPPADDING', (0, 0), (-1, -1), 0),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('RIGHTPADDING', (0, 0), (-1, -1), 0)
    ]))

    elements.append(header_table)

    return elements


def create_table_header_summary(section: str):
    """
    Create table header for summary sheet

    @param section - the section name to create the table header for
    """
    logger.debug(f"create table header summary >>> section={section}")

    blank_cell = Paragraph("")
    hc_n1 = Paragraph("<b>N1</b>", style_header)
    hc_n2 = Paragraph("<b>N2</b>", style_header)
    hc_total = Paragraph("<b>Total</b>", style_header)
    hc_var = Paragraph("<b>Var.</b>", style_header)
    hc_mtd = Paragraph("<b>MTD</b>", style_header)
    hc_ytd = Paragraph("<b>YTD</b>", style_header)
    hp_today_actual = Paragraph("<b>Today Actual</b>", style_header)
    hp_section = Paragraph(f"<b>{section}</b>", style_header)
    data = []

    if section == "REVENUE":
        hp_mtd_actual = Paragraph("<b>MTD Actual ('000s)</b>", style_header)
        hp_mtd_budget = Paragraph("<b>MTD Budget ('000s)</b>", style_header)
        hp_full_month_budget = Paragraph("<b>Full Month Budget ('000s)</b>", style_header)
        hp_ytd_actual = Paragraph("<b>YTD Actual ('000s)</b>", style_header)
        hp_ytd_budget = Paragraph("<b>YTD Budget ('000s)</b>", style_header)
        hp_last_year = Paragraph("<b>Last Year ('000s)</b>", style_header)

        data = [[hp_section, hp_today_actual, blank_cell, blank_cell, hp_mtd_actual, blank_cell,
                 blank_cell, hp_mtd_budget, blank_cell, hp_full_month_budget, blank_cell,
                 blank_cell, hp_ytd_actual, blank_cell, blank_cell, hp_ytd_budget, blank_cell,
                 hp_last_year, blank_cell, blank_cell, blank_cell],
                [blank_cell, hc_n1, hc_n2, hc_total, hc_n1, hc_n2, hc_total, hc_total, hc_var, hc_n1, hc_n2,
                 hc_total, hc_n1, hc_n2, hc_total, hc_total, hc_var, hc_mtd, hc_var, hc_ytd, hc_var]]

    else:
        hp1_mtd_actual = Paragraph("<b>MTD Actual</b>", style_header)
        hp1_mtd_budget = Paragraph("<b>MTD Budget</b>", style_header)
        hp1_full_month_budget = Paragraph("<b>Full Month Budget</b>", style_header)
        hp1_ytd_actual = Paragraph("<b>YTD Actual</b>", style_header)
        hp1_ytd_budget = Paragraph("<b>YTD Budget</b>", style_header)
        hp1_last_year = Paragraph("<b>Last Year</b>", style_header)

        data = data + [
            [blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell,
             blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell,
             blank_cell, blank_cell, blank_cell, blank_cell, blank_cell],
            [hp_section, hp_today_actual, blank_cell, blank_cell, hp1_mtd_actual, blank_cell,
             blank_cell, hp1_mtd_budget, blank_cell, hp1_full_month_budget, blank_cell,
             blank_cell, hp1_ytd_actual, blank_cell, blank_cell, hp1_ytd_budget, blank_cell,
             hp1_last_year, blank_cell, blank_cell, blank_cell],
            [blank_cell, hc_n1, hc_n2, hc_total, hc_n1, hc_n2, hc_total, hc_total, hc_var, hc_n1, hc_n2,
             hc_total, hc_n1, hc_n2, hc_total, hc_total, hc_var, hc_mtd, hc_var, hc_ytd, hc_var]
        ]

    return data


def create_table_header_detail_room():
    """
    create table header for detail room sheet
    """
    logger.debug("create table header detail room")
    
    blank_cell = Paragraph("")
    hc_no_of_room = Paragraph("<b>No of Rooms</b>", style_header)
    hc_arr = Paragraph("<b>ARR</b>", style_header)
    hc_rev = Paragraph("<b>REV</b>", style_header)
    hp_header1 = Paragraph("<b>COMPLEX ROOM REVENUE</b>", style_header)
    hc_header2 = Paragraph("<b>BY MARKET SEGMENT</b>", style_header)
    hp_today = Paragraph("<b>TODAY</b>", style_header)
    hp_current_month_to_date = Paragraph("<b>CURRENT MONTH TO DATE</b>", style_header)
    hp_last_year_month = Paragraph("<b>LAST YEAR MONTH</b>", style_header)
    hp_budget_month = Paragraph("<b>BUDGET MONTH</b>", style_header)
    hp_current_ytd = Paragraph("<b>CURRENT YTD</b>", style_header)
    hp_last_year_ytd = Paragraph("<b>LAST YEAR YTD</b>", style_header)

    # header rows
    data = [[hp_header1, hp_today, blank_cell, blank_cell, hp_current_month_to_date, blank_cell,
             blank_cell, hp_last_year_month, blank_cell, blank_cell, hp_budget_month, blank_cell,
             blank_cell, hp_current_ytd, blank_cell, blank_cell, hp_last_year_ytd, blank_cell,
             blank_cell],
            [hc_header2, hc_no_of_room, hc_arr, hc_rev, hc_no_of_room, hc_arr, hc_rev, hc_no_of_room, hc_arr,
             hc_rev, hc_no_of_room, hc_arr, hc_rev, hc_no_of_room, hc_arr, hc_rev, hc_no_of_room, hc_arr, hc_rev]]

    return data


def create_table_header_detail_fb():
    """
    create table header for detail fb sheet
    """
    logger.debug("create table header detail fb")

    blank_cell = Paragraph("")
    hc_food = Paragraph("<b>Food</b>", style_header)
    hc_beverage = Paragraph("<b>Beverage</b>", style_header)
    hc_other = Paragraph("<b>Other</b>", style_header)
    hc_total = Paragraph("<b>Total</b>", style_header)
    hp_header1 = Paragraph(f"<b>{escape('F&B REVENUE')}</b>", style_header)
    hp_today = Paragraph("<b>Today</b>", style_header)
    hp_month_to_date = Paragraph("<b>Month to date</b>", style_header)
    hp_last_year_month = Paragraph("<b>Last Year<br/>Month</b>", style_header)
    hp_budget_current_month = Paragraph("<b>Budget<br/>Current Month</b>", style_header)
    hp_current_ytd = Paragraph("<b>Current<br/>YTD</b>", style_header)
    hp_last_year_ytd = Paragraph("<b>Last Year<br/>YTD</b>", style_header)

    # header rows
    data = [[hp_header1, hp_today, blank_cell, blank_cell, blank_cell, hp_month_to_date, blank_cell, blank_cell,
             blank_cell, hp_last_year_month, hp_budget_current_month, hp_current_ytd, hp_last_year_ytd],
            [blank_cell, hc_food, hc_beverage, hc_other, hc_total, hc_food, hc_beverage, hc_other, hc_total,
             blank_cell, blank_cell, blank_cell, blank_cell]]

    return data


def highlight_rows(table_styles: list, special_row: dict, background_color: str):
    """
    highlight some particular rows

    @param table_styles - a list of table styles
    @param special_row - a list of some particular rows
    @param background_color - a background color
    """
    logger.debug(f"highlight rows >>> special row={special_row}, background_color={background_color}")
    
    for row_number in special_row.values():
        if row_number == -1:
            continue
        table_styles.append(('BACKGROUND', (0, row_number), (-1, row_number), background_color))
    return table_styles


def split_dfs(section_dfs: list, sections: list) -> list:
    """
    split a list of dataframe into two lists

    @param section_dfs - a list of dataframe
    @param sections - a list of dividers
    @return a list of splits
    """
    logger.debug(f"split dataframes >>> sections={sections}")
    
    split = []
    tmp = []
    for i, section_df in enumerate(section_dfs):
        section_ = section_df.columns.tolist()[0]
        if section_ not in sections:
            tmp.append(section_df)
        else:
            split.append(tmp)
            tmp = [section_df]
    split.append(tmp)
    return split


def create_pdf_summary(section_dfs: list, report_date: datetime.datetime, pdf_file: str):
    """
    Create a pdf file report for summary sheet

    @param section_dfs - list of dataframe
    @param report_date - report date
    @param pdf_file - the path of the output pdf file
    @return elements on page
    """
    logger.debug(f"create pdf for summary >>> report_date={report_date}, pdf_file={pdf_file}")

    if section_dfs is None:
        raise ValueError("section_dfs is required")

    if report_date is None:
        raise ValueError("report_date is required")

    if pdf_file is None or len(pdf_file) == 0:
        raise ValueError("pdf_file is required")

    """
    All sections inside a pdf are called elements
    """
    elements = []

    elements = elements + create_pdf_header(report_date)

    table_styles = [
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        # set surrounding border
        ('BOX', (0, 0), (-1, -1), 0.25, colors.black),
        # set first vertical border
        ('LINEBEFORE', (0, 0), (-1, -1), border_size_2, colors.black),
        # set later vertical border
        ('LINEAFTER', (0, 0), (-1, -1), border_size_2, colors.black),
        ('TOPPADDING', (0, 0), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 2),
        ('LEFTPADDING', (0, 0), (-1, -1), 2),
        ('RIGHTPADDING', (0, 0), (-1, -1), 2)
    ]

    prev_len = 0
    header_row = 2
    blank_row_count = 0
    data = []
    row_height_list = []

    blank_cell = Paragraph("")

    for i, section_df in enumerate(section_dfs):
        if len(section_df) == 0:
            continue
        section = section_df.columns.tolist()[0]

        # create table header
        data = data + create_table_header_summary(section)

        # row height for two header rows
        row_height_list = row_height_list + [pdf_data_row_height, pdf_data_row_height]

        # special rows
        special_row = get_special_rows(section_df)

        # merge some columns
        table_styles = (table_styles +
                        [
                            # merge row 0 and row 1 at column 1
                            ('SPAN', (0, (i * header_row) + prev_len + (i * blank_row_count)),
                                (0, (i * header_row) + prev_len + (i * blank_row_count) + 1)),

                            # merge column 1 and column 3 at row 1
                            ('SPAN', (1, (i * header_row) + prev_len + (i * blank_row_count)),
                                (3, (i * header_row) + prev_len + (i * blank_row_count))),

                            # merge column 4 and column 6 at row 1
                            ('SPAN', (4, (i * header_row) + prev_len + (i * blank_row_count)),
                                (6, (i * header_row) + prev_len + (i * blank_row_count))),

                            # merge column 7 and column 8 at row 1
                            ('SPAN', (7, (i * header_row) + prev_len + (i * blank_row_count)),
                                (8, (i * header_row) + prev_len + (i * blank_row_count))),

                            # merge column 9 and column 11 at row 1
                            ('SPAN', (9, (i * header_row) + prev_len + (i * blank_row_count)),
                                (11, (i * header_row) + prev_len + (i * blank_row_count))),

                            # merge column 12 and column 14 at row 1
                            ('SPAN', (12, (i * header_row) + prev_len + (i * blank_row_count)),
                                (14, (i * header_row) + prev_len + (i * blank_row_count))),

                            # merge column 15 and column 16 at row 1
                            ('SPAN', (15, (i * header_row) + prev_len + (i * blank_row_count)),
                                (16, (i * header_row) + prev_len + (i * blank_row_count))),

                            # merge column 17 and column 20 at row 1
                            ('SPAN', (17, (i * header_row) + prev_len + (i * blank_row_count)),
                                (20, (i * header_row) + prev_len + (i * blank_row_count))),

                            # set top border on header first row except first column
                            ('LINEABOVE', (0, (i * header_row) + prev_len + (i * blank_row_count)),
                                (-1, (i * header_row) + prev_len + (i * blank_row_count)), border_size_2, colors.black),

                            # set bottom border on header first row except first column
                            ('LINEBELOW', (1, (i * header_row) + prev_len + (i * blank_row_count)),
                                (-1, (i * header_row) + prev_len + (i * blank_row_count)), border_size_2, colors.black),

                            # set bottom border on header second row
                            ('LINEBELOW', (0, (i * header_row) + prev_len + (i * blank_row_count) + 1),
                                (-1, (i * header_row) + prev_len + (i * blank_row_count) + 1), border_size_2,
                                colors.black)

                        ])

        # we can't use r, because it is not serial
        k = 0
        for r, row in section_df.iterrows():
            ps = []
            row_height_list.append(pdf_data_row_height)
            
            """
            apply number format, bold format, percentage format

            percentage value is to be aligned to the center
            number value is to be aligned to the right

            both percentage value and number value will have bracket instead of a negative sign (-)

            if it is number, add a space at the front and a space at the back.
            """
            
            for c, col in enumerate(section_df.columns):
                p = None
                if c == 0:
                    """
                    column 1 is the row name, some row names are bold
                    some columns are having the blank row on the top of them.
                    """
                    if (special_row[ROOMS_INTERNAL] != -1 and special_row[ROOMS_INTERNAL] == k):
                        p = Paragraph(f"<i>{escape(row[col])}</i>", style_row_name)
                    elif (special_row[ROOMS_EXTERNAL] != -1 and special_row[ROOMS_EXTERNAL] == k):
                        p = Paragraph(f"<i>{escape(row[col])}</i>", style_row_name)
                    elif special_row[ROOMS_TOTAL] != -1 and special_row[ROOMS_TOTAL] == k:
                        p = Paragraph(f"<b>{escape(row[col])}</b>", style_row_name)
                    elif special_row[FB_REVENUE] != -1 and special_row[FB_REVENUE] == k:
                        p = Paragraph(f"<b>{escape(row[col])}</b>", style_row_name)
                    elif special_row[OTHERS_REVENUE] != -1 and special_row[OTHERS_REVENUE] == k:
                        p = Paragraph(f"<b>{escape(row[col])}</b>", style_row_name)
                    elif special_row[TOTAL_HOTEL_REVENUE] != -1 and special_row[TOTAL_HOTEL_REVENUE] == k:
                        p = Paragraph(f"<b>{escape(row[col])}</b>", style_row_name)
                        data = data + [[
                            blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell,
                            blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell,
                            blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell
                        ]]
                        blank_row_count = blank_row_count + 1
                        row_height_list = row_height_list + [pdf_data_row_height]
                    elif special_row[OCCUPANCY_EXTERNAL] != -1 and special_row[OCCUPANCY_EXTERNAL] == k:
                        p = Paragraph(f"<b>{escape(row[col])}</b>", style_row_name)
                    elif special_row[HOUSE_USE_ROOMS] != -1 and special_row[HOUSE_USE_ROOMS] == k:
                        p = Paragraph(f"{escape(row[col])}", style_row_name)
                        data = data + [[
                            blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell,
                            blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell,
                            blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell 
                        ]]
                        blank_row_count = blank_row_count + 1
                        row_height_list = row_height_list + [pdf_data_row_height]
                    elif special_row[AVERAGE_ROOM_RATE_EXTERNAL] != -1 and special_row[
                        AVERAGE_ROOM_RATE_EXTERNAL] == k:
                        p = Paragraph(f"<b>{escape(row[col])}</b>", style_row_name)
                        data = data + [[
                            blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell,
                            blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell,
                            blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell
                        ]]
                        blank_row_count = blank_row_count + 1
                        row_height_list = row_height_list + [pdf_data_row_height]
                    elif special_row[ROOM_ARRIVALS] != -1 and special_row[ROOM_ARRIVALS] == k:
                        p = Paragraph(f"{escape(row[col])}", style_row_name)
                        data = data + [[
                            blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell,
                            blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell,
                            blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell
                        ]]
                        blank_row_count = blank_row_count + 1
                        row_height_list = row_height_list + [pdf_data_row_height]
                    else:
                        p = Paragraph(f"{escape(row[col])}", style_row_name)
                else:
                    """
                    Column Var. is the columns that have percentage values.
                    But those values will also need to be bold for those particular rows.
                    """
                    if "Var." in col:
                        if row[section] == 'Sleeper Density':
                            p = (Paragraph(f" {row[col]:,.2f} ", style_data) if float(row[col]) >= 0 \
                                 else Paragraph(f"({(-1)*row[col]:,.2f})", style_data) ) \
                                    if not pd.isna(row[col]) else Paragraph(" - ", style_data)
                        else:
                            if ((special_row[ROOMS_TOTAL] != -1 and special_row[ROOMS_TOTAL] == k) or
                            (special_row[FB_REVENUE] != -1 and special_row[FB_REVENUE] == k) or 
                            (special_row[OTHERS_REVENUE] != -1 and special_row[OTHERS_REVENUE] == k) or 
                            (special_row[TOTAL_HOTEL_REVENUE] != -1 and special_row[TOTAL_HOTEL_REVENUE] == k) or 
                            (special_row[OCCUPANCY_EXTERNAL] != -1 and special_row[OCCUPANCY_EXTERNAL] == k) or 
                            (special_row[AVERAGE_ROOM_RATE_EXTERNAL] != -1 and special_row[AVERAGE_ROOM_RATE_EXTERNAL] == k)):
                                p = (Paragraph(f"<b>{row[col]:,.1%}</b>", style_data_percentage) if float(row[col]) >= 0 \
                                     else Paragraph(f"<b>({(-1)*float(row[col]):,.1%})</b>", style_data_percentage) ) \
                                        if not pd.isna(row[col]) else Paragraph(" - ", style_data_percentage)
                            else:
                                if ((special_row[ROOMS_INTERNAL] != -1 and special_row[ROOMS_INTERNAL] == k) or
                                (special_row[ROOMS_EXTERNAL] != -1 and special_row[ROOMS_EXTERNAL] == k)):
                                    p = (Paragraph(f"<i>{row[col]:,.1%}</i>", style_data_percentage) if float(row[col]) >= 0 \
                                     else Paragraph(f"<i>({(-1)*float(row[col]):,.1%})</i>", style_data_percentage) ) \
                                        if not pd.isna(row[col]) else Paragraph(" - ", style_data_percentage)
                                else:
                                    p = (Paragraph(f"{row[col]:,.1%}", style_data_percentage) if float(row[col]) >= 0 \
                                     else Paragraph(f"({(-1)*float(row[col]):,.1%})", style_data_percentage) ) \
                                        if not pd.isna(row[col]) else Paragraph(" - ", style_data_percentage)
                    else:
                        if ((special_row[ROOMS_TOTAL] != -1 and special_row[ROOMS_TOTAL] == k) or
                            (special_row[FB_REVENUE] != -1 and special_row[FB_REVENUE] == k) or 
                            (special_row[OTHERS_REVENUE] != -1 and special_row[OTHERS_REVENUE] == k) or 
                            (special_row[TOTAL_HOTEL_REVENUE] != -1 and special_row[TOTAL_HOTEL_REVENUE] == k)):                            
                            p = (Paragraph(f" <b>{row[col]:,.0f}</b> ", style_data) if float(row[col]) >= 0 \
                                     else Paragraph(f"<b>({(-1)*float(row[col]):,.0f})</b>", style_data) ) \
                                        if not pd.isna(row[col]) else Paragraph(" - ", style_data)
                        elif special_row[OCCUPANCY_EXTERNAL] != -1 and special_row[OCCUPANCY_EXTERNAL] == k:
                            p = (Paragraph(f"<b>{row[col]:,.1%}</b>", style_data) if float(row[col]) >= 0 \
                                     else Paragraph(f"<b>({(-1)*float(row[col]):,.1%})</b>", style_data) ) \
                                        if not pd.isna(row[col]) else Paragraph(" - ", style_data)
                        elif (special_row[AVERAGE_ROOM_RATE_EXTERNAL] != -1 and
                                special_row[AVERAGE_ROOM_RATE_EXTERNAL] == k):
                            p = (Paragraph(f" <b>{row[col]:,.2f}</b> ", style_data) if float(row[col]) >= 0 \
                                     else Paragraph(f"<b>({(-1)*float(row[col]):,.2f})</b>", style_data) ) \
                                        if not pd.isna(row[col]) else Paragraph(" - ", style_data)
                        elif special_row[ROOM_YIELD] != -1 and special_row[ROOM_YIELD] == k:
                            p = (Paragraph(f" {row[col]:,.2f} ", style_data) if float(row[col]) >= 0 \
                                     else Paragraph(f"({(-1)*float(row[col]):,.2f})", style_data) ) \
                                        if not pd.isna(row[col]) else Paragraph(" - ", style_data)
                        elif special_row[SLEEPER_DENSITY] != -1 and special_row[SLEEPER_DENSITY] == k:
                            p = (Paragraph(f" {row[col]:,.2f} ", style_data) if float(row[col]) >= 0 \
                                 else Paragraph(f"({(-1)*row[col]:,.2f})", style_data) ) \
                                    if not pd.isna(row[col]) else Paragraph(" - ", style_data) 
                        else:
                            if ((special_row[ROOMS_INTERNAL] != -1 and special_row[ROOMS_INTERNAL] == k) or
                                (special_row[ROOMS_EXTERNAL] != -1 and special_row[ROOMS_EXTERNAL] == k)):
                                p = (Paragraph(f" <i>{row[col]:,.0f}</i> ", style_data) if float(row[col]) >= 0 \
                                 else Paragraph(f"<i>({(-1)*float(row[col]):,.0f})</i>", style_data) ) \
                                    if not pd.isna(row[col]) else Paragraph(" - ", style_data)
                            else:
                                p = (Paragraph(f" {row[col]:,.0f} ", style_data) if float(row[col]) >= 0 \
                                 else Paragraph(f"({(-1)*float(row[col]):,.0f})", style_data) ) \
                                    if not pd.isna(row[col]) else Paragraph(" - ", style_data)
                ps.append(p)
            data.append(ps)

            """
            apply background color
            """
            if k % 2 == 0:
                table_styles.append(('BACKGROUND',
                                        (0, k + ((i + 1) * header_row) + (i * blank_row_count) + prev_len),
                                        (-1, k + ((i + 1) * header_row) + (i * blank_row_count) + prev_len),
                                        f"#{even_row_background_color2}"))
            k = k + 1

        """
        Highlight some particular rows, before that we need to update those values
        because along the way we added some blank rows.
        """
        if special_row[ROOMS_TOTAL] != -1:
            special_row[ROOMS_TOTAL] = special_row[ROOMS_TOTAL] + header_row

        if special_row[FB_REVENUE] != -1:
            special_row[FB_REVENUE] = special_row[FB_REVENUE] + header_row

        if special_row[OTHERS_REVENUE] != -1:
            special_row[OTHERS_REVENUE] = special_row[OTHERS_REVENUE] + header_row

        if special_row[TOTAL_HOTEL_REVENUE] != -1:
            special_row[TOTAL_HOTEL_REVENUE] = special_row[TOTAL_HOTEL_REVENUE] + header_row + 1

        if special_row[OCCUPANCY_EXTERNAL] != -1:
            special_row[OCCUPANCY_EXTERNAL] = special_row[OCCUPANCY_EXTERNAL] + 2 * header_row + 2 + prev_len

        if special_row[AVERAGE_ROOM_RATE_EXTERNAL] != -1:
            special_row[AVERAGE_ROOM_RATE_EXTERNAL] = (special_row[
                                                            AVERAGE_ROOM_RATE_EXTERNAL] + 2 * header_row
                                                        + 4 + prev_len)

        # reset those rows that are not to be highlighted
        special_row[ROOMS_INTERNAL] = -1
        special_row[ROOMS_EXTERNAL] = -1
        special_row[HOUSE_USE_ROOMS] = -1
        special_row[SLEEPER_DENSITY] = -1
        special_row[ROOM_YIELD] = -1
        special_row[ROOM_ARRIVALS] = -1

        table_styles = table_styles + highlight_rows(table_styles, special_row,
                                                        f"#{highlight_background_color2}")

        prev_len = prev_len + len(section_df)

        # handle the blank row at the end of every section
        if i != len(section_dfs) - 1:
            blank_row_count = blank_row_count + 1
            row_height_list = row_height_list + [pdf_data_row_height]
            table_styles = table_styles + [
                ('LINEBELOW', (0, ((i + 1) * header_row) + prev_len + (i * blank_row_count)),
                    (-1, ((i + 1) * header_row) + prev_len + (i * blank_row_count)),
                    border_size_2, colors.black)]

        # last row of the first section must be merged
        if i == 0:
            table_styles = (table_styles + [
                ('SPAN', (0, header_row + prev_len + 1),
                    (-1, header_row + prev_len + 1))
            ])

    if len(data) > 0:
        # add data to the pdf table and set size for its columns
        table = Table(data, colWidths=[2.1 * inch] + [None] * (len(data[0]) - 1),
                        rowHeights=row_height_list)
        # table style is to be applied at the end
        table.setStyle(TableStyle(table_styles))

        elements.append(table)

        # page break
        elements.append(PageBreak())

    return elements


def create_pdf_detail_room(section_dfs: list, report_date: datetime.datetime, pdf_file: str, time: int):
    """
    Create a pdf file report for detail room sheet

    @param section_dfs - list of dataframe
    @param report_date - report date
    @param pdf_file - the path of the output pdf file
    @param time - how many times this function is called
    @return elements on page
    """
    logger.debug(
        f"create pdf for detail room >>> report_date={report_date}, pdf_file={pdf_file}")

    if section_dfs is None:
        raise ValueError("section_dfs is required")

    if report_date is None:
        raise ValueError("report_date is required")

    if pdf_file is None or len(pdf_file) == 0:
        raise ValueError("pdf_file is required")

    """
    All sections inside a pdf are called elements
    """
    elements = []

    elements = elements + create_pdf_header(report_date)

    # previous len of all rows in each section
    prev_len = 0
    header_row = 2
    row_height_list = []

    blank_cell = Paragraph("")

    data = create_table_header_detail_room()

    # row height for two header rows
    row_height_list = row_height_list + [0.19 * inch, 0.35 * inch]

    table_styles = [
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        # set surrounding border
        ("BOX", (0, 0), (-1, -1), border_size_2, colors.black),
        # set later vertical border
        ("LINEAFTER", (0, 0), (-1, -1), border_size_1, colors.black),
        # set right vertical fat border on column 0
        ("LINEAFTER", (0, 0), (0, -1), border_size_2, colors.black),
        # set right fat border on column 3
        ("LINEAFTER", (3, 0), (3, -1), border_size_2, colors.black),
        # set right fat border on column 6
        ("LINEAFTER", (6, 0), (6, -1), border_size_2, colors.black),
        # set right fat border on column 9
        ("LINEAFTER", (9, 0), (9, -1), border_size_2, colors.black),
        # set right fat border on column 12
        ("LINEAFTER", (12, 0), (12, -1), border_size_2, colors.black),
        # set right fat border on column 15
        ("LINEAFTER", (15, 0), (15, -1), border_size_2, colors.black),
        # set fat bottom border at row 0
        ("LINEBELOW", (0, 0), (-1, 0), border_size_2, colors.black),
        # set bottom border at row 1
        ("LINEBELOW", (0, 1), (-1, 1), border_size_1, colors.black),
        # merge column 1 and column 3 at row 0
        ("SPAN", (1, 0), (3, 0)),
        # merge column 4 and column 6 at row 0
        ("SPAN", (4, 0), (6, 0)),
        # merge column 7 and column 9 at row 0
        ("SPAN", (7, 0), (9, 0)),
        # merge column 10 and column 12 at row 0
        ("SPAN", (10, 0), (12, 0)),
        # merge column 13 and column 15 at row 0
        ("SPAN", (13, 0), (15, 0)),
        # merge column 16 and column 18 at row 0
        ("SPAN", (16, 0), (18, 0)),

        ('TOPPADDING', (0, 0), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 2),
        ('LEFTPADDING', (0, 0), (-1, -1), 2),
        ('RIGHTPADDING', (0, 0), (-1, -1), 2)
        ]

    for i, section_df in enumerate(section_dfs):
        section = section_df.columns.tolist()[0]
        hp_section = Paragraph(f"<b>{section}</b>", style_row_name)

        """
        insert new row at the beginning of each section.
        section name is to be put there
        """
        data = data + [[
            hp_section, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell,
            blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell,
            blank_cell, blank_cell, blank_cell
        ]]

        # row height for the new row
        row_height_list = row_height_list + [pdf_data_row_height]


        # apply background color to the section row
        table_styles.append(('BACKGROUND',
                                (0, i + header_row - 1 + prev_len + 1),
                                (-1, i + header_row - 1 + prev_len + 1),
                                f"#{highlight_background_color3}"))

        """
        number formatting, background color
        """
        # we can't use r because it is not serial
        k = 0
        for r, row in section_df.iterrows():
            ps = []
            row_to_bold = ''

            if k % 2 == 0:
                table_styles.append(('BACKGROUND',
                                        (0, k + header_row - 1 + prev_len + (i + 1) + 1),
                                        (-1, k + header_row - 1 + prev_len + (i + 1) + 1),
                                        f"#{even_row_background_color2}"))

            for c, col in enumerate(section_df.columns):
                if c == 0:
                    # subtotal row has white background
                    if row[col] == "Subtotal":
                        table_styles = (table_styles +
                                        [('BACKGROUND',
                                            (0, k + header_row - 1 + prev_len + (i + 1) + 1),
                                            (-1, k + header_row - 1 + prev_len + (i + 1) + 1),
                                            colors.white)])

                    if row[col] in ["TOTAL (Excluding Internal)", "TOTAL (Internal)"]:
                        table_styles = (table_styles +
                                        [('BACKGROUND',
                                            (0, k + header_row - 1 + prev_len + (i + 1) + 1),
                                            (-1, k + header_row - 1 + prev_len + (i + 1) + 1),
                                            f"#{highlight_background_color2}")])
                    if row[col] in ["Subtotal", "TOTAL (Excluding Internal)", "TOTAL (Internal)"]:
                        row_to_bold = col
                        p = Paragraph(f"<b>{escape(row[col])}</b>", style_row_name)
                    else:
                        p = Paragraph(f"{escape(row[col])}", style_row_name)
                else:
                    if row_to_bold != '' and row[row_to_bold] in ["Subtotal", "TOTAL (Excluding Internal)",
                                                                    "TOTAL (Internal)"]:
                        if 'ARR' in col:
                            p = (Paragraph(f" <b>{row[col]:,.2f}</b> ", style_data) if float(row[col]) >= 0 \
                                else Paragraph(f"({(-1)*float(row[col]):,.2f})", style_data) ) \
                                if not pd.isna(row[col]) else Paragraph(" - ", style_data)
                        else:
                            p = (Paragraph(f" <b>{row[col]:,.0f}</b> ", style_data) if float(row[col]) >= 0 \
                                else Paragraph(f"({(-1)*float(row[col]):,.0f})", style_data) ) \
                                if not pd.isna(row[col]) else Paragraph(" - ", style_data)
                    else:
                        if 'ARR' in col:
                            p = (Paragraph(f" {row[col]:,.2f} ", style_data) if float(row[col]) >= 0 \
                                else Paragraph(f"({(-1)*float(row[col]):,.2f})", style_data) ) \
                                if not pd.isna(row[col]) else Paragraph(" - ", style_data)
                        else:
                            p = (Paragraph(f" {row[col]:,.0f} ", style_data) if float(row[col]) >= 0 \
                                else Paragraph(f"({(-1)*float(row[col]):,.0f})", style_data) ) \
                                if not pd.isna(row[col]) else Paragraph(" - ", style_data)
                ps.append(p)
            data.append(ps)

            
            # row height for this row
            row_height_list = row_height_list + [pdf_data_row_height]

            k = k + 1

        prev_len = prev_len + len(section_df)

        """
        set fat borders at the following rows:
        - subtotal of each section
        - the last row of each section
        """
        table_styles = table_styles + [
            ("LINEABOVE", (0, header_row + prev_len + i),
                (-1, header_row + prev_len + i), border_size_2, colors.black),
            ("LINEBELOW", (0, header_row + prev_len + i),
                (-1, header_row + prev_len + i), border_size_2, colors.black)
        ]

    table = Table(data, colWidths=[2.6 * inch] + [None] * (len(data[0]) - 1), rowHeights=row_height_list)
    table.setStyle(TableStyle(table_styles))

    elements.append(table)

    # page break
    elements.append(PageBreak())

    return elements


def create_pdf_detail_fb_section(section_df: pd.DataFrame, report_date: datetime.datetime, pdf_file: str):
    """
    Create a pdf file report for a section in detail fb sheet

    @param section_df - a dataframe
    @param report_date - report date
    @param pdf_file - the path of the output pdf file
    @return elements on page
    """
    logger.debug(
        f"create pdf for a section in detail fb >>> report_date={report_date}, pdf_file={pdf_file}")

    if section_df is None:
        raise ValueError("section_df is required")

    if report_date is None:
        raise ValueError("report_date is required")

    if pdf_file is None or len(pdf_file) == 0:
        raise ValueError("pdf_file is required")


    """
    All sections inside a pdf are called elements
    """
    elements = []

    elements = elements + create_pdf_header(report_date)

    header_row = 2
    row_height_list = []

    blank_cell = Paragraph("")

    data = create_table_header_detail_fb()

    # add row height for the two header rows
    row_height_list = row_height_list + [0.19 * inch, 0.20 * inch]

    table_styles = [
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("BOX", (0, 0), (-1, -1), border_size_2, colors.black),
        # set fat bottom border at row 0 for column 1,2,3,4,5,6,7,8
        ("LINEBELOW", (1, 0), (8, 0), border_size_2, colors.black),
        # set fat bottom border at row 1
        ("LINEBELOW", (0, 1), (-1, 1), border_size_2, colors.black),
        # set right border of each column
        ("LINEAFTER", (0, 0), (-1, -1), border_size_1, colors.black),
        # set right fat border at column 0
        ("LINEAFTER", (0, 0), (0, -1), border_size_2, colors.black),
        # set right fat border at column 4
        ("LINEAFTER", (4, 0), (4, -1), border_size_2, colors.black),
        # set right fat border at column 8
        ("LINEAFTER", (8, 0), (8, -1), border_size_2, colors.black),
        # set right fat border at column 9
        ("LINEAFTER", (9, 0), (9, -1), border_size_2, colors.black),
        # set right fat border at column 4
        ("LINEAFTER", (10, 0), (10, -1), border_size_2, colors.black),
        # set right fat border at column 4
        ("LINEAFTER", (11, 0), (11, -1), border_size_2, colors.black),
        # set right fat border at column 12
        ("LINEAFTER", (12, 0), (12, -1), border_size_2, colors.black),
        # merge column 1 and column 4 at row 0
        ("SPAN", (1, 0), (4, 0)),
        # merge column 5 and column 5 at row 0
        ("SPAN", (5, 0), (8, 0)),
        # merge row 0 and row 1 at column 9
        ("SPAN", (9, 0), (9, 1)),
        # merge row 0 and row 1 at column 10
        ("SPAN", (10, 0), (10, 1)),
        # merge row 0 and row 1 at column 11
        ("SPAN", (11, 0), (11, 1)),
        # merge row 0 and row 1 at column 12
        ("SPAN", (12, 0), (12, 1)),

        ('TOPPADDING', (0, 0), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 2),
        ('LEFTPADDING', (0, 0), (-1, -1), 2),
        ('RIGHTPADDING', (0, 0), (-1, -1), 2)
        ]

    section = section_df.columns.tolist()[0]
    hp_section = Paragraph(f"<b>{section}</b>", style_section)

    # insert new row that is the section name
    data = data + [[
        hp_section, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell, blank_cell,
        blank_cell, blank_cell, blank_cell, blank_cell, blank_cell
    ]]

    # add row height for the above new row
    row_height_list = row_height_list + [pdf_data_row_height]

    # apply borders to the section name row
    table_styles = table_styles + [
        ("LINEABOVE", (0, 2), (-1, 2), border_size_2, colors.black),
        ("LINEBELOW", (0, 2), (-1, 2), border_size_2, colors.black),
    ]

    # we can't use r because it is not serial
    k = 0
    for r, row in section_df.iterrows():
        ps = []
        total_col = ''

        # apply background color to even rows
        if k % 2 == 0:
            table_styles.append(('BACKGROUND',
                                    (0, k + (header_row - 1) + 1 + 1),
                                    (-1, k + (header_row - 1) + 1 + 1),
                                    f"#{even_row_background_color2}"))

        # number format and background color on some particular rows
        for c, col in enumerate(section_df.columns):
            if c == 0:
                if "Total F&B Revenue" in row[col]:
                    total_col = col
                    p = Paragraph(f"<b>{escape(row[col])}</b>", style_row_name)
                    table_styles.append(('BACKGROUND',
                                            (0, k + (header_row - 1) + 1 + 1),
                                            (-1, k + (header_row - 1) + 1 + 1),
                                            f"#{highlight_background_color2}"))
                else:
                    p = Paragraph(f"{escape(row[col])}", style_row_name)
            else:
                if total_col != '' and "Total F&B Revenue" in row[total_col]:      
                    p = (Paragraph(f"<b>{row[col]:,.0f}</b>", style_data) if float(row[col]) >= 0 \
                                else Paragraph(f"({(-1)*float(row[col]):,.0f})", style_data) ) \
                                if not pd.isna(row[col]) else Paragraph(" - ", style_data)
                else:
                    p = (Paragraph(f" {row[col]:,.0f} ", style_data) if float(row[col]) >= 0 \
                                else Paragraph(f"({(-1)*float(row[col]):,.0f})", style_data) ) \
                                if not pd.isna(row[col]) else Paragraph(" - ", style_data)

            ps.append(p)
        data.append(ps)

        # add row height for this row
        row_height_list = row_height_list + [pdf_data_row_height]
        
        k = k + 1

    table = Table(data, colWidths=[2.04 * inch] + [None] * (len(data[0]) - 1), rowHeights=row_height_list)

    table.setStyle(TableStyle(table_styles))

    elements.append(table)

    # page break
    elements.append(PageBreak())

    return elements


def create_pdf(sheet_dict: dict, report_date: datetime.datetime, pdf_file: str):
    """
    Create a pdf file report

    @param sheet_dict - a dictionary
    @param report_date - report date must be in yyyy-mm-dd
    @param pdf_file - the path of the output pdf file
    """
    logger.debug(f"create pdf >>> report_date={report_date}, pdf_file={pdf_file}")

    if sheet_dict is None:
        raise ValueError("sheet_dict is required")

    if report_date is None:
        raise ValueError("report_date is required")

    if pdf_file is None or len(pdf_file) == 0:
        raise ValueError("pdf_file is required")

    """
    pdf = SimpleDocTemplate(pdf_file, pagesize=(19 * inch, 12 * inch),
                            rightMargin=10, leftMargin=10, topMargin=10, bottomMargin=10)
    """
    pdf = SimpleDocTemplate(pdf_file, pagesize=(12 * inch, 8.26 * inch),
                            rightMargin=17, leftMargin=17, topMargin=17, bottomMargin=17)
    elements = []

    for sheet, dfs in sheet_dict.items():
        match sheet:
            case "Summary":
                elements = elements + create_pdf_summary(dfs, report_date, pdf_file)
            case "Detail Room":
                """
                split into pages at Gaming Mass
                """
                after_split_dfs = split_dfs(dfs, ["Gaming Mass"])
                for dfs_ in after_split_dfs:
                    elements = elements + create_pdf_detail_room(dfs_, report_date, pdf_file, 0)
            case "Detail F&B":
                for df in dfs:
                    elements = elements + create_pdf_detail_fb_section(df, report_date, pdf_file)
            case _:
                pass
    pdf.build(elements)

