"""
Excel test module is to test excel module.

Author: Phann Malinka
"""
import datetime
from dotenv import dotenv_values
from drr import db
from drr.excel import create_excel_detail_fb, create_excel
from drr.util import get_sheets_data

config = dotenv_values(".env")


def test_create_excel_detail_fb():
    today = datetime.datetime.now()
    yesterday = today - datetime.timedelta(days=1)
    report_date = yesterday.strftime("%d%m%y")
    report_file_name = f"{config['report_name']} {report_date}"
    excel_file = f'tmp/{report_file_name}.xlsx'
    structure_df = db.get_structure()
    sheet_dict = get_sheets_data(structure_df, yesterday)
    section_dfs = sheet_dict["Detail F&B"]
    create_excel_detail_fb(structure_df, section_dfs, yesterday, excel_file, "new")

def test_create_excel():
    today = datetime.datetime.now()
    yesterday = today - datetime.timedelta(days=1)
    report_date = yesterday.strftime("%d%m%y")
    report_file_name = f"{config['report_name']} {report_date}"
    excel_file = f'tmp/{report_file_name}.xlsx'
    executive_summary_file = f'tmp/{report_file_name} Executive Summary.xlsx'
    structure_df = db.get_structure()
    sheet_dict = get_sheets_data(structure_df, yesterday)
    create_excel(structure_df, sheet_dict, yesterday, excel_file, executive_summary_file)


if __name__ == '__main__':
    test_create_excel_detail_fb()
