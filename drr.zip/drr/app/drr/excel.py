"""
Excel module is to take care of generating the excel document.

Author: Phann Malinka
"""
import datetime
import pandas as pd
from drr import config_reader
from openpyxl.styles import Alignment, Border, Side, Font, PatternFill
from drr.my_logger import logger
from drr.util import *
from drr.util_config import *


config = config_reader.get()

def create_excel_header(worksheet, columns: list, report_date: datetime.datetime):
    """
    create excel header

    @param worksheet - worksheet object
    @param columns - columns of dataframe
    @param report_date - the report date
    """
    logger.debug(f"create excel header >>> columns={columns}, report_date={report_date}")

    if worksheet is None:
        raise ValueError("worksheet is required")

    if columns is None or len(columns) == 0:
        raise ValueError("columns is required")

    if report_date is None:
        raise ValueError("report_date is required")

    report_date_print = report_date.strftime('%d %b %Y')
    report_day_print = report_date.strftime('%a')

    # report header lines at top left and bottom left
    worksheet.cell(row=1, column=1, value=config[REPORT_TITLE_LINE1]).font = (
        Font(bold=True, size=report_header_font_size))
    worksheet.cell(row=2, column=1, value=config[REPORT_TITLE_LINE2]).font = (
        Font(bold=True, size=report_header_font_size))

    # report header lines at top right and bottom right
    worksheet.cell(row=1, column=len(columns) - 2, value='Date').font = Font(bold=True, size=report_header_font_size)
    worksheet.cell(row=2, column=len(columns) - 2, value='Day').font = Font(bold=True, size=report_header_font_size)

    # on top right, merge the last two columns together for row1 and row2
    worksheet.merge_cells(start_row=1, start_column=(len(columns) - 1),
                          end_row=1, end_column=(len(columns)))
    worksheet.merge_cells(start_row=2, start_column=(len(columns) - 1),
                          end_row=2, end_column=(len(columns)))

    # report date is at first row, top right
    report_date_cell = worksheet.cell(row=1, column=len(columns) - 1)
    report_date_cell.font = Font(bold=True, size=report_header_font_size)
    report_date_cell.alignment = Alignment(horizontal="center")
    report_date_cell.value = report_date_print

    # report day is at second row, top right
    report_day_cell = worksheet.cell(row=2, column=len(columns) - 1)
    report_day_cell.font = Font(bold=True, size=report_header_font_size)
    report_day_cell.alignment = Alignment(horizontal="center")
    report_day_cell.value = report_day_print


def create_summary_border(worksheet, columns: list, start_row: int):
    """"
    Create borders for summary sheet

    @param worksheet - the worksheet
    @param columns - the list of columns
    @param start_row - the start row
    """
    logger.debug(f"create summary border >>> columns={columns}, start_row={start_row}")

    # dataframe starts from zero index, but openpyxl starts from 1
    for r, row in enumerate(worksheet.iter_rows()):
        r = r + 1

        # skip header title rows
        if r < start_row:
            continue

        for c, col in enumerate(columns):
            c = c + 1
            cell = worksheet.cell(row=r, column=c)

            if r in [start_row, start_row + 1]:
                cell.border = Border(left=Side(border_style='thin', color=border_color),
                                     right=Side(border_style='thin', color=border_color),
                                     top=Side(border_style='thin', color=border_color),
                                     bottom=Side(border_style='thin', color=border_color))
                continue

            if c == 1:
                if r == worksheet.max_row:
                    cell.border = Border(left=Side(border_style='thin', color=border_color),
                                         right=Side(border_style='thin', color=border_color),
                                         bottom=Side(border_style='dotted', color=border_color))
                else:
                    cell.border = Border(left=Side(border_style='thin', color=border_color),
                                         right=Side(border_style='thin', color=border_color))
            elif c == len(columns):
                if r == worksheet.max_row:
                    cell.border = Border(bottom=Side(border_style='dotted', color=border_color),
                                         right=Side(border_style='thin', color=border_color))
                else:
                    cell.border = Border(right=Side(border_style='thin', color=border_color))
            else:
                if r == worksheet.max_row:
                    cell.border = Border(
                        bottom=Side(border_style='dotted', color=border_color),
                        right=Side(border_style='dotted', color=border_color))
                else:
                    cell.border = Border(right=Side(border_style='dotted', color=border_color))

    return worksheet


def create_excel_section_nagaworld(structure_df: pd.DataFrame, section_df: pd.DataFrame, excel_file: str,
                                   sheet: str, mode: str):
    """
    Create nagaworld section

    @param structure_df - the structure dataframe
    @param section_df - a dataframe
    @param excel_file - the path of the output Excel file
    @param sheet - sheet name
    @param mode - mode (append or new)
    """
    logger.debug(f"create excel for section nagaworld >>> excel_file={excel_file}, sheet={sheet}, mode={mode}")

    if structure_df is None:
        raise ValueError("structure_df is required")

    if excel_file is None or len(excel_file) == 0:
        raise ValueError("excel_file is required")

    if sheet is None or len(sheet) == 0:
        raise ValueError("sheet is required")
    
    if mode is None:
        raise ValueError("mode is required")
    
    if mode not in ["new", "append"]:
        raise ValueError("mode must be either new or append")

    """
    new - create new file
    append - append to existing file
    """
    create_file_mode = 'a'
    if_sheet_exists = 'overlay'
    if mode == 'new':
        excel_writer = pd.ExcelWriter(excel_file, engine="openpyxl")
    else:
        excel_writer = pd.ExcelWriter(excel_file, engine="openpyxl", 
                                      mode=create_file_mode, if_sheet_exists=if_sheet_exists)

    logger.debug(f"create excel file={excel_file}, mode={create_file_mode}, if_sheet_exists={if_sheet_exists}")

    logger.debug("structure data")
    logger.debug(structure_df)

    try:
        section = section_df.columns.tolist()[0]
        logger.debug(f"dataframe of section = {section}")
        logger.debug(section_df)

        """
        startrow starts from second row (1) because header needs 2 rows.
        first row to put the parent name
        second row to put the child name
        """
        section_df.to_excel(excel_writer, sheet_name=sheet, startrow=1, startcol=1, index=False)
        worksheet = excel_writer.sheets[sheet]
        logger.debug(f"write dataframe to sheet = {sheet} is done")

        """
        The Excel sheet looks like this.

        --------------------------------
                       |
        NAGAWORLD      | ---------------
                       |  A  |  B  |  C
        ---------------|-----|----------
        some row name  |  x  |  y  |  z               

        we are going to loop through all columns (A, B, C)
        find its parent and child from structure_df, then
        merge cell and update cell.
        in order to that, we need to know how many children a parent has.
        """
        parent_row = 1
        prev_parent = ''

        """
        merging parent cells and updating children cells
        """
        logger.debug("merge parent cells and update children cells")
        for c, col in enumerate(section_df.columns):
            # because this sheet start at column = 2
            c = c + 2

            if c == 2:
                # merge section name into 2 columns
                worksheet.merge_cells(start_row=1, start_column=1, end_row=2, end_column=2)
                logger.debug(f"merge cells: start_row=1, end_row=2, start_column=1, end_column=2")
                worksheet.cell(row=1, column=1, value=section)
                worksheet.cell(row=1, column=1).alignment = Alignment(horizontal='center', vertical='center')
                logger.debug(f"set cell value = {section} at row=1, column=1 and align center horizontally/vertically")

                # merge row name into 2 columns
                k = 3
                for cell in [worksheet.cell(row=r, column=1) for r in range(3, len(section_df) + 4)]:
                    value = worksheet.cell(row=k, column=2).value
                    worksheet.merge_cells(start_row=k, start_column=1, end_row=k, end_column=2)
                    logger.debug(f"merge cells: start_row={k}, end_row={k}, start_column=1, end_column=2")
                    worksheet.cell(row=k, column=1, value=value)
                    worksheet.cell(row=k, column=1).alignment = Alignment(horizontal='left', vertical='center')
                    logger.debug(f"set cell value = {value} at row={k}, column=1 and align left horizontally / center vertically")
                    k = k + 1

                continue

            # grab the column name out of the table
            column_name = worksheet.cell(2, c).value

            # find parent and child
            founds = structure_df.loc[(structure_df['SheetName'] == sheet)
                                      & (structure_df['SectionName'] == section)
                                      & (structure_df['ColumnName'] == column_name)
                                      ]
            parent = founds.iloc[0]['ParentColumnName']
            child = founds.iloc[0]['ChildColumnName']
            logger.debug(f"parent and child: sheet={sheet}, section={section}, column={column_name}, "
                        f"parent={parent}, child={child}")

            if parent == prev_parent:
                # update children row
                child_cell = worksheet.cell(row=2, column=c)
                child_cell.value = child
                child_cell.alignment = Alignment(horizontal='center', vertical='center')
                continue
            else:
                prev_parent = parent

            children_count_df = structure_df.loc[(structure_df['SheetName'] == sheet)
                                                 & (structure_df['SectionName'] == section)
                                                 & (structure_df['ParentColumnName'] == parent)
                                                 ]
            logger.debug("children count dataframe")
            logger.debug(children_count_df)

            group_by_row_name_df = (
                children_count_df.groupby("RowName", sort=False)["ExcelRow"].apply(list)
                .reset_index(name="ExcelRows"))

            """
            group_by_row_name_df looks like this:

            Room Revenue/Day  [3.0, 3.0, 3.0]
             F&B Revenue/Day  [4.0, 4.0, 4.0]
        External Occupancy %  [5.0, 5.0, 5.0]
External Average Room Rate (ARR)  [6.0, 6.0, 6.0]
             Hotel Revenue $  [8.0, 8.0, 8.0]

            the purpose is to find the first number in the list of the first row
            because each row has the same columns.
            """
            logger.debug("children count dataframe gouped by RowName")
            logger.debug(group_by_row_name_df)
            excel_row = group_by_row_name_df.iloc[0]['ExcelRows']

            children = children_count_df.loc[(children_count_df['ExcelRow'] == excel_row[0])]
            logger.debug(f"filter children count dataframe for excel row = {excel_row[0]}")
            logger.debug(children)

            num_col_to_span = len(children.index)

            # merge, align and update value in parent row
            worksheet.merge_cells(start_row=parent_row, start_column=c, end_row=parent_row,
                                  end_column=c + num_col_to_span - 1)
            parent_cell = worksheet.cell(row=parent_row, column=c)
            parent_cell.value = parent
            parent_cell.alignment = Alignment(horizontal='center', vertical='center')
            logger.debug(f"merge cells: start_row={parent_row}, end_row={parent_row}, "
                         f"start_column={c},  end_column={c + num_col_to_span - 1}")

            # update children row
            child_cell = worksheet.cell(row=2, column=c)
            child_cell.value = child
            child_cell.alignment = Alignment(horizontal='center', vertical='center')
            logger.debug(f"set cell value = {child} at row=2, column={c}")
        

        """
        insert a blank row right before hotel revenue row
        """
        logger.debug("insert a blank row before hotel revenue row")
        hotel_revenue_row = 0
        for r, row in section_df.iterrows():
            if row[section] == 'Hotel Revenue $':
                # r is not integer
                hotel_revenue_row = int(str(r)) + 2 + 1
                break
        if hotel_revenue_row != 0:
            worksheet.insert_rows(hotel_revenue_row, 1)
        
        """
        formatting ands styling
        """
        logger.debug("formatting and styling")
        for c, col in enumerate(section_df.columns):

            """
            because we start at column 2, column 1 is reserved to be merged into column 2 to put
            the row name. 
            that column 1 will be used to put the bullet point in later sections.
            """
            c = c + 2

            # set font bold to two header rows
            worksheet.cell(row=1, column=c).font = Font(bold=True)
            worksheet.cell(row=2, column=c).font = Font(bold=True)

            # set font bold to row name
            if c == 2:
                for cell in [worksheet.cell(row=r, column=1) for r in range(1, len(section_df) + 4)]:
                    cell.font = Font(bold=True)

            # adjust column width and row height
            column = str(chr(64 + c))
            if c == 1:
                worksheet.column_dimensions[column].width = 33.33
            else:
                worksheet.column_dimensions[column].width = 10
            k = 1
            for _ in [worksheet.cell(row=r, column=c) for r in range(1, len(section_df) + 4)]:
                worksheet.row_dimensions[k].height = 15.75
                k = k + 1

            # alignment
            k = 1
            for cell in [worksheet.cell(row=r, column=c) for r in range(1, len(section_df) + 4)]:
                # first column
                if c == 1 and (k != 1 and k != 2):
                    cell.alignment = Alignment(vertical='center')

                if c != 1 and (k != 1 and k != 2):
                    cell.alignment = Alignment(vertical='center', horizontal='center')
                k = k + 1

            """
            Apply number format to all rows except
            - external occupancy
            - external average room rate
            """
            k = 1
            for cell in [worksheet.cell(row=r, column=c) for r in range(1, len(section_df) + 4)]:
                cell.number_format = '#,##0'
                k = k + 1

        """
        border
        """
        logger.debug("bordering")
        for r, row in enumerate(worksheet.iter_rows()):
            # this is a new blank row, so skip it
            if r == worksheet.max_row-1:
                break
            
            if r == worksheet.max_row-2:
                c = 0
                for cell in row:
                    if c == worksheet.max_column-1:
                        cell.border = Border(top=Side(border_style="thin", color=border_color),
                        bottom=Side(border_style="thin", color=border_color),
                        left=Side(border_style="thin", color=border_color),
                        right=Side(border_style="thin", color=border_color))
                    else:
                        cell.border = Border(left=Side(border_style="thin", color=border_color),
                        top=Side(border_style="thin", color=border_color),
                        bottom=Side(border_style="thin", color=border_color))
                    c = c + 1
            else:
                c = 0
                for cell in row:
                    if c == worksheet.max_column-1:
                        cell.border = Border(top=Side(border_style="thin", color=border_color),
                        left=Side(border_style="thin", color=border_color),
                        right=Side(border_style="thin", color=border_color))
                    else:
                        cell.border = Border(top=Side(border_style="thin", color=border_color),
                        left=Side(border_style="thin", color=border_color))
                    c = c + 1

        """
        apply percentage format to external occupancy
        and float format to external average room rate
        """
        logger.debug("applying number format")
        for r, row in enumerate(worksheet.iter_rows()):
            if row[0].value == 'External Occupancy %':
                for c, col in enumerate(section_df.columns):
                    worksheet.cell(row=r + 1, column=c + 2).number_format = "0.0%"
            if row[0].value == 'External Average Room Rate (ARR)':
                for c, col in enumerate(section_df.columns):
                    worksheet.cell(row=r + 1, column=c + 2).number_format = "0.00"
    except:
        raise
    finally:
        if excel_writer is not None:
            excel_writer.close()


def create_excel_section_occupancy(structure_df: pd.DataFrame, section_df: pd.DataFrame, excel_file: str, sheet: str,
                                   start_row: int):
    """
    Create occupancy section

    @param structure_df - the structure dataframe
    @param section_df - a dataframe
    @param excel_file - the path of the output Excel file
    @param sheet - sheet name
    @param start_row - the starting row
    """
    logger.debug(f"create excel for section occupancy >>> excel_file={excel_file}, sheet={sheet}, start_row={start_row}")

    if structure_df is None:
        raise ValueError("structure_df is required")

    if excel_file is None or len(excel_file) == 0:
        raise ValueError("excel_file is required")

    if start_row <= 0:
        raise ValueError("start_row must be positive")

    create_file_mode = 'a'
    if_sheet_exists = 'overlay'
    excel_writer = pd.ExcelWriter(excel_file, engine="openpyxl", mode=create_file_mode, 
                                  if_sheet_exists=if_sheet_exists)
    logger.debug(f"create excel file={excel_file}, mode={create_file_mode}, if_sheet_exists={if_sheet_exists}")

    logger.debug("structure data")
    logger.debug(structure_df)

    try:
        section = section_df.columns.tolist()[0]
        logger.debug(f"dataframe of section = {section}")
        logger.debug(section_df)

        """
        This is the second section after NAGAWORLD. 
        Its content must be appended to the first section; that's why we need the start_row.
        """
        section_df.to_excel(excel_writer, sheet_name=sheet, startrow=start_row, startcol=1, index=False)
        worksheet = excel_writer.sheets[sheet]
        logger.debug(f"write dataframe to sheet={sheet}")

        # merge title
        # header is empty, but it is there, that's why start_row+1
        worksheet.merge_cells(start_row=start_row + 1, start_column=1, end_row=start_row + 1, end_column=3)
        logger.debug(f"merge cells: start_row={start_row + 1}, end_row={start_row + 1}, start_column=1, end_column=3")
        worksheet.cell(row=start_row + 1, column=1, value=section)
        worksheet.cell(row=start_row + 1, column=1).font = Font(bold=True)
        logger.debug(f"set cell value={section} at row={start_row + 1}, column=1")

        # remove first row border (it is treated as header, but it is not a real header)
        for i in range(1, len(section_df) + 1):
            worksheet.cell(row=start_row + 1, column=i).border = None

        # add a bullet point at the front of each row
        # and set font bold
        logger.debug("add a bullet point at the front of each row")
        k = start_row + 2
        for _ in [worksheet.cell(row=r, column=1) for r in range(start_row + 2, start_row + len(section_df) + 2)]:
            worksheet.cell(row=k, column=1).value = "•"
            worksheet.cell(row=k, column=1).font = Font(bold=True)
            k = k + 1

    except:
        raise
    finally:
        if excel_writer is not None:
            excel_writer.close()


def create_excel_section_keydata(structure_df: pd.DataFrame, section_df: pd.DataFrame, excel_file: str, sheet: str,
                                 start_row: int):
    """
    Create keydata section

    @param structure_df - the structure dataframe
    @param section_df - a dataframe
    @param excel_file - the path of the output Excel file
    @param sheet - sheet name
    @param start_row - the starting row
    """
    logger.debug(f"create excel for section key data >>> excel_file={excel_file}, sheet={sheet}, start_row={start_row}")

    if structure_df is None:
        raise ValueError("structure_df is required")

    if excel_file is None or len(excel_file) == 0:
        raise ValueError("excel_file is required")

    if start_row <= 0:
        raise ValueError("start_row must be positive")

    create_file_mode = 'a'
    if_sheet_exists = 'overlay'
    excel_writer = pd.ExcelWriter(excel_file, engine="openpyxl", mode=create_file_mode, 
                                  if_sheet_exists=if_sheet_exists)
    logger.debug(f"create excel file={excel_file}, mode={create_file_mode}, if_sheet_exists={if_sheet_exists}")

    logger.debug("structure data")
    logger.debug(structure_df)

    try:
        section = section_df.columns.tolist()[0]
        logger.debug(f"dataframe of section = {section}")
        logger.debug(section_df)

        """
        This is the third section after Occupancy. 
        Its content must be appended to the second section; that's why we need the start_row.
        """
        section_df.to_excel(excel_writer, sheet_name=sheet, startrow=start_row, startcol=1, index=False)
        worksheet = excel_writer.sheets[sheet]
        logger.debug(f"write dataframe to sheet={sheet}")

        # merge title
        # header is empty, but it is there, that's why start_row+1
        worksheet.merge_cells(start_row=start_row + 1, start_column=1, end_row=start_row + 1, end_column=3)
        logger.debug(f"merge cells: start_row={start_row + 1}, end_row={start_row + 1}, start_column=1, end_column=3")
        worksheet.cell(row=start_row + 1, column=1, value=section)
        worksheet.cell(row=start_row + 1, column=1).font = Font(bold=True)
        logger.debug(f"set cell value={section} at row={start_row + 1}, column=1")

        # remove header border
        for i in range(1, len(section_df) + 1):
            worksheet.cell(row=start_row + 1, column=i).border = None

        # add a bullet point at the front of each row
        # and set font bold
        logger.debug("add a bullet point at the front of each row")
        k = start_row + 2
        for _ in [worksheet.cell(row=r, column=1) for r in range(start_row + 2, start_row + len(section_df) + 1)]:
            worksheet.cell(row=k, column=1).value = "•"
            worksheet.cell(row=k, column=1).font = Font(bold=True)
            k = k + 1

        # merge column 3 through 6
        logger.debug("merge column 3 through 6")
        k = start_row + 2
        for _ in [worksheet.cell(row=r, column=3) for r in range(start_row + 2, start_row + len(section_df) + 2)]:
            worksheet.merge_cells(start_row=k, start_column=3, end_row=k, end_column=6)
            k = k + 1

        # set width
        w1 = 5
        w2 = 40
        logger.debug(f"set width={w1} for row name, and width={w2} for other columns")
        for c, col in enumerate(section_df.columns):
            column = str(chr(64 + c + 1))
            if c == 0:
                worksheet.column_dimensions[column].width = w1
            if c == 1:
                worksheet.column_dimensions[column].width = w2
    finally:
        if excel_writer is not None:
            excel_writer.close()


def create_excel_executive_summary(structure_df: pd.DataFrame, section_dfs: list, excel_file: str, mode: str):
    """
    Create an Excel file report for the executive summary

    @param structure_df - the structure dataframe
    @param section_dfs - a list of dataframe
    @param excel_file - the path of the output Excel file
    @param mode - the mode (append or new)
    """
    logger.debug(f"create excel for executive summary >>> excel_file={excel_file}, mode={mode}")

    if structure_df is None:
        raise ValueError("structure_df is required")

    if section_dfs is None:
        raise ValueError("section_dfs is required")
    
    if len(section_dfs) == 0:
        raise ValueError("section_dfs is empty")

    if excel_file is None or len(excel_file) == 0:
        raise ValueError("excel_file is required")

    sheet = "Executive Summary"

    prev_row_num = 0
    for i, df in enumerate(section_dfs):
        section = df.columns.tolist()[0]
        match section:
            case "NAGAWORLD":
                create_excel_section_nagaworld(structure_df, df, excel_file, sheet, mode)
            case "MTD External Rooms Occupancy % (Market Segments)":
                create_excel_section_occupancy(structure_df, df, excel_file, sheet, prev_row_num + 4)
            case "Key Data F&B":
                create_excel_section_keydata(structure_df, df, excel_file, sheet, prev_row_num + 6)
            case _:
                pass
        prev_row_num = prev_row_num + len(df)


def create_excel_summary(structure_df: pd.DataFrame, section_dfs: list, report_date: datetime.datetime,
                         excel_file: str, mode: str):
    """
    Create an Excel file report for the summary

    @param structure_df - the structure dataframe
    @param section_dfs - a list of dataframe for summary sheet
    @param report_date - report date
    @param excel_file - the path of the output Excel file
    @param mode - append or new
    """
    logger.debug(f"create excel summary >>> report_date={report_date}, "
                f"excel_file={excel_file}, mode={mode}")

    if structure_df is None:
        raise ValueError("structure_df must be created first")

    if section_dfs is None:
        raise ValueError("section_dfs is required")

    if report_date is None:
        raise ValueError("report_date is required")

    if excel_file is None or len(excel_file) == 0:
        raise ValueError("excel_file is required")

    if mode is None:
        raise ValueError("mode is required")
    
    if mode not in ["append", "new"]:
        raise ValueError("mode must be either append or new")

    sheet = "Summary"

    create_file_mode='a'
    if_sheet_exists = 'overlay'
    if mode == "new":
        excel_writer = pd.ExcelWriter(excel_file, engine="openpyxl")
    else:
        excel_writer = pd.ExcelWriter(excel_file, engine="openpyxl", mode=create_file_mode, 
                                      if_sheet_exists=if_sheet_exists)

    logger.debug(f"create excel file={excel_file}, mode={create_file_mode}, if_sheet_exists={if_sheet_exists}")

    border_all = Border(left=Side(border_style="thin", color=border_color),
                        right=Side(border_style="thin", color=border_color),
                        top=Side(border_style="thin", color=border_color),
                        bottom=Side(border_style="thin", color=border_color))
    
    logger.debug("structure data")
    logger.debug(structure_df)

    try:
        """
        must start from 3 because we leave 3 blank rows at the top
        1- first row for report header line 1
        2- second row for report header line 2
        3- third row for parent header
        since pandas row starts from 0, so the start_row is the fourth row in openpyxl.
        """
        start_row_xls = 4
        worksheet = None
        columns = []
        blank_row_count = 0
        for i, section_df in enumerate(section_dfs):
            section = section_df.columns.tolist()[0]
            section_df.to_excel(excel_writer, sheet_name=sheet, startrow=start_row_xls-1, index=False)
            worksheet = excel_writer.sheets[sheet]
            logger.debug(f"write dataframe to sheet={sheet} at startrow={start_row_xls-1}")

            prev_parent = ''

            if i == 0:
                columns = section_df.columns
                create_excel_header(worksheet, columns, report_date)
            
            """
            format and styling
            """
            logger.debug("formatting and styling")
            for c, col in enumerate(columns):
                c = c + 1

                """ 
                apply border for header rows

                why start_row_xls-1?

                start_row_xls is the row where we put the children.
                start_row_xls-1 is the row where we put the parents.
                """ 
                worksheet.cell(row=start_row_xls - 1, column=c).border = border_all
                worksheet.cell(row=start_row_xls, column=c).border = border_all

                # apply border for data rows
                if c == 1:
                    # border on first column
                    k = start_row_xls + 1
                    for cell in [worksheet.cell(row=r, column=c)
                                 for r in range(start_row_xls + 1, start_row_xls + 1 + len(section_df))]:
                        if k == start_row_xls + len(section_df):
                            # last row of first column
                            if i == len(section_dfs) - 1:
                                cell.border = Border(bottom=Side(border_style='thin', color=border_color),
                                                     left=Side(border_style='thin', color=border_color),
                                                     right=Side(border_style='thin', color=border_color))
                            else:
                                cell.border = Border(bottom=Side(border_style='dotted', color=border_color),
                                                     left=Side(border_style='thin', color=border_color),
                                                     right=Side(border_style='thin', color=border_color))
                        else:
                            cell.border = Border(left=Side(border_style='thin', color=border_color),
                                                 right=Side(border_style='thin', color=border_color))
                        k = k + 1
                else:
                    # border on last column
                    if c == len(section_df.columns.tolist()):
                        k = start_row_xls + 1
                        for cell in [worksheet.cell(row=r, column=c)
                                     for r in range(start_row_xls + 1, start_row_xls + 1 + len(section_df))]:
                            if k == start_row_xls + len(section_df):
                                # last row of last column
                                if i == len(section_dfs) - 1:
                                    cell.border = Border(right=Side(border_style='thin', color=border_color),
                                                         bottom=Side(border_style='thin', color=border_color))
                                else:
                                    cell.border = Border(right=Side(border_style='thin', color=border_color),
                                                         bottom=Side(border_style='dotted', color=border_color))
                            else:
                                cell.border = Border(right=Side(border_style='thin', color=border_color))
                            k = k + 1
                    else:
                        # handle columns in between first column and last columns
                        k = start_row_xls + 1
                        for cell in [worksheet.cell(row=r, column=c)
                                     for r in range(start_row_xls + 1, start_row_xls + 1 + len(section_df))]:
                            if k == start_row_xls + len(section_df):
                                # last row of that column
                                if i == len(section_dfs) - 1:
                                    cell.border = Border(
                                        left=Side(border_style='dotted', color=border_color),
                                        right=Side(border_style='dotted', color=border_color),
                                        bottom=Side(border_style='thin', color=border_color))
                                else:
                                    cell.border = Border(
                                        left=Side(border_style='dotted', color=border_color),
                                        right=Side(border_style='dotted', color=border_color),
                                        bottom=Side(border_style='dotted', color=border_color))

                            else:
                                cell.border = Border(left=Side(border_style='dotted', color=border_color),
                                                     right=Side(border_style='dotted', color=border_color))
                            k = k + 1

                # apply background color
                k = start_row_xls + 1
                for cell in [worksheet.cell(row=r, column=c)
                             for r in range(start_row_xls + 1, start_row_xls + 1 + len(section_df))]:
                    if k % 2 == 0:
                        cell.fill = PatternFill(start_color=even_row_background_color2,
                                                end_color=even_row_background_color2, fill_type="solid")
                    k = k + 1

                # apply bold font for header and row name
                worksheet.cell(row=start_row_xls - 1, column=c).font = Font(bold=True)
                worksheet.cell(row=start_row_xls, column=c).font = Font(bold=True)

                # set column width and row height
                column = str(chr(64 + c))
                if c == 1:
                    worksheet.column_dimensions[column].width = 45
                else:
                    worksheet.column_dimensions[column].width = 10

                """
                why start from start_row_xls - 1?

                we want to set the row height from parent row till the end row, 
                and start_row_xls is the children row.
                """
                k = start_row_xls - 1
                for _ in [worksheet.cell(row=r, column=c) for r in
                          range(start_row_xls - 1, start_row_xls + 1 + len(section_df))]:
                    worksheet.row_dimensions[k].height = excel_row_height
                    k = k + 1

                # alignment
                if c == 1:
                    # first column
                    for cell in [worksheet.cell(row=r, column=1) for r in
                                 range(start_row_xls + 1, start_row_xls + 1 + len(section_df))]:
                        cell.alignment = Alignment(horizontal="left", vertical="center")
                else:
                    # data columns
                    for cell in [worksheet.cell(row=r, column=c)
                                 for r in range(start_row_xls + 1, start_row_xls + 1 + len(section_df))]:
                        cell.alignment = Alignment(horizontal="right", vertical="center")

                sleeper_density_row = get_row_number(worksheet, "Sleeper Density")
                occupancy_row = get_row_number(worksheet, "Occupancy % (External)")
                average_room_rate_row = get_row_number(worksheet, "Average Room Rate (External)")
                room_yield_row = get_row_number(worksheet, "Room Yield (External Revenues/Physical Rooms)")
                
                # apply percentage format
                if col in (
                        "MTD Budget ('000s) Var.", "YTD Budget ('000s) Var.",
                        "Last Year ('000s) MTD Var.", "Last Year ('000s) YTD Var.",
                        "MTD Budget Var.", "YTD Budget Var.",
                        "Last Year MTD Var.", "Last Year YTD Var."
                ):
                    k = start_row_xls + 1
                    for cell in [worksheet.cell(row=r, column=c)
                                 for r in range(start_row_xls + 1, start_row_xls + 1 + len(section_df))]:
                        if (sleeper_density_row == 0) or (sleeper_density_row != 0 and k != sleeper_density_row):
                            cell.alignment = Alignment(horizontal="center", vertical="center")
                            cell.number_format = "0.0%"
                            if cell.value != "" and float(cell.value) < 0:
                                cell.value = (-1)*float(cell.value)
                                cell.number_format = "(0.0%)"
                        k = k + 1
                elif c > 1:
                    """
                    apply number format to all other columns where row is not
                        - Occupancy %
                        - Average Room Rate
                        - Room Yield
                        - Sleeper Density
                    """
                    k = start_row_xls + 1
                    for cell in [worksheet.cell(row=r, column=c)
                                 for r in range(start_row_xls + 1, start_row_xls + 1 + len(section_df))]:
                        cell.number_format = " #,##0 "
                        if cell.value != "" and float(cell.value) < 0:
                            cell.value = (-1)*(float(cell.value))
                            cell.number_format = "(#,##0)"
                        k = k + 1

                    if occupancy_row != 0:
                        cell = worksheet.cell(row=occupancy_row, column=c)
                        cell.number_format = "0.0%"
                        if cell.value != "" and float(cell.value) < 0:
                            cell.value = (-1)*(float(cell.value))
                            cell.number_format = "0.0%"

                    if average_room_rate_row != 0:
                        cell = worksheet.cell(row=average_room_rate_row, column=c)
                        cell.number_format = " 0.00 "
                        if cell.value != "" and float(cell.value) < 0:
                            cell.value = (-1)*(float(cell.value))
                            cell.number_format = "(0.00)"

                    if room_yield_row != 0:
                        cell = worksheet.cell(row=room_yield_row, column=c)
                        cell.number_format = " 0.00 "
                        if cell.value != "" and float(cell.value) < 0:
                            cell.value = (-1)*(float(cell.value))
                            cell.number_format = "(0.00)"

                if c > 1:
                    # sleeper density is formatted as 0.00 for positive value and (0.00) for negative value
                    if sleeper_density_row != 0:
                        sleeper_density_cell = worksheet.cell(row=sleeper_density_row, column=c)
                        sleeper_density_cell.number_format = " 0.00 "
                        if sleeper_density_cell.value != '' and float(sleeper_density_cell.value) < 0:
                            sleeper_density_cell.value = (-1) * float(sleeper_density_cell.value)
                            sleeper_density_cell.number_format = "(0.00)"

                    # replace NULL with -
                    k = start_row_xls + 1
                    for _ in [worksheet.cell(row=r, column=c)
                              for r in range(start_row_xls + 1, start_row_xls + 1 + len(section_df))]:
                        cell = worksheet.cell(row=k, column=c)
                        if cell.value == "":
                            cell.value = " - "
                        k = k + 1

            """
            merge cells for parent and update those children cells
            """
            logger.debug("merge parent cells and update children cells")
            for c, col in enumerate(columns):
                # enumerate starts from 0, but openpyxl starts from 1
                c = c + 1

                """
                put a section name at top left corner and align it center
                """
                if c == 1:
                    worksheet.merge_cells(start_row=start_row_xls-1, start_column=1, end_row=start_row_xls, end_column=1)
                    worksheet.cell(row=start_row_xls - 1, column=1, value=section)
                    worksheet.cell(row=start_row_xls - 1, column=1).alignment = Alignment(horizontal='center',
                                                                                  vertical='center')
                    continue

                # grab the column name out of the table
                column_name = worksheet.cell(start_row_xls, c).value

                # find parent and child
                founds = structure_df.loc[(structure_df['SheetName'] == sheet)
                                          & (structure_df['SectionName'] == section)
                                          & (structure_df['ColumnName'] == column_name)
                                          ]
                if len(founds) == 0:
                    continue

                parent = founds.iloc[0]['ParentColumnName']
                child = founds.iloc[0]['ChildColumnName']
                logger.debug(f"create_excel_summary: sheet={sheet}, section={section}, column={column_name}, "
                            f"parent={parent}, child={child}")

                if parent == prev_parent:
                    # update children row
                    child_cell = worksheet.cell(row=start_row_xls, column=c)
                    child_cell.value = child
                    child_cell.alignment = Alignment(horizontal='center', vertical='center')
                    continue
                else:
                    prev_parent = parent

                children_count_df = structure_df.loc[(structure_df['SheetName'] == sheet)
                                                     & (structure_df['SectionName'] == section)
                                                     & (structure_df['ParentColumnName'] == parent)
                                                     & (structure_df['HideColumn'] == 0)
                                                     ]
                logger.debug(children_count_df)

                group_by_row_name_df = (
                    children_count_df.groupby("RowName", sort=False)["ExcelRow"].apply(list)
                    .reset_index(name="ExcelRows"))

                """
                group_by_row_name_df looks like this:

                Room Revenue/Day  [3.0, 3.0, 3.0]
                 F&B Revenue/Day  [4.0, 4.0, 4.0]
            External Occupancy %  [5.0, 5.0, 5.0]
    External Average Room Rate (ARR)  [6.0, 6.0, 6.0]
                 Hotel Revenue $  [8.0, 8.0, 8.0]

                the purpose is to find the first number in the list of the first row
                because each row has the same columns.
                """
                logger.debug(group_by_row_name_df)
                excel_row = group_by_row_name_df.iloc[0]['ExcelRows']

                children = children_count_df.loc[(children_count_df['ExcelRow'] == excel_row[0])]
                logger.debug(children)

                num_col_to_span = len(children.index)

                # merge, align and update value in parent row
                worksheet.merge_cells(start_row=start_row_xls - 1, start_column=c, end_row=start_row_xls - 1,
                                      end_column=c + num_col_to_span - 1)
                parent_cell = worksheet.cell(row=start_row_xls - 1, column=c)
                parent_cell.value = parent
                parent_cell.alignment = Alignment(horizontal='center', vertical='center')

                # update children row
                child_cell = worksheet.cell(row=start_row_xls, column=c)
                child_cell.value = child
                child_cell.alignment = Alignment(horizontal='center', vertical='center')

            """
            insert a new blank row right before some particular rows
            also create its border right here as well
            """
            logger.debug("insert a new blank row before total hotel revenue row")
            total_hotel_revenue_row = get_row_number(worksheet, "TOTAL HOTEL REVENUE")
            if section == "REVENUE" and total_hotel_revenue_row != 0:
                worksheet.insert_rows(total_hotel_revenue_row, 1)
                worksheet.row_dimensions[total_hotel_revenue_row].height = excel_row_height
                for c, col in enumerate(columns):
                    c = c + 1
                    cell = worksheet.cell(row=total_hotel_revenue_row, column=c)
                    if c == 1:
                        cell.border = (
                            Border(left=Side(border_style='thin', color=border_color),
                                   right=Side(border_style='thin', color=border_color)))

                    elif c == len(columns):
                        cell.border = Border(
                            left=Side(border_style='dotted', color=border_color),
                            right=Side(border_style='thin', color=border_color))
                    else:
                        cell.border = Border(
                            right=Side(border_style='dotted', color=border_color))
                blank_row_count = blank_row_count + 1

            logger.debug("insert a new blank row before house use rooms row")
            house_use_rooms_row = get_row_number(worksheet, "House Use Rooms")
            if section == "STATISTICS" and house_use_rooms_row != 0:
                worksheet.insert_rows(house_use_rooms_row, 1)
                worksheet.row_dimensions[house_use_rooms_row].height = excel_row_height
                for c, col in enumerate(columns):
                    c = c + 1
                    cell = worksheet.cell(row=house_use_rooms_row, column=c)
                    if c == 1:
                        cell.border = (
                            Border(left=Side(border_style='thin', color=border_color),
                                   right=Side(border_style='thin', color=border_color)))

                    elif c == len(columns):
                        cell.border = Border(
                            left=Side(border_style='dotted', color=border_color),
                            right=Side(border_style='thin', color=border_color))
                    else:
                        cell.border = Border(
                            right=Side(border_style='dotted', color=border_color))
                blank_row_count = blank_row_count + 1

            logger.debug("insert a new blank row before average room rate row")
            average_room_rate_row = average_room_rate_row = get_row_number(worksheet, "Average Room Rate (External)")
            if section == "STATISTICS" and average_room_rate_row != 0:
                worksheet.insert_rows(average_room_rate_row, 1)
                worksheet.row_dimensions[average_room_rate_row].height = excel_row_height
                for c, col in enumerate(columns):
                    c = c + 1
                    cell = worksheet.cell(row=average_room_rate_row, column=c)
                    if c == 1:
                        cell.border = (
                            Border(left=Side(border_style='thin', color=border_color),
                                   right=Side(border_style='thin', color=border_color)))

                    elif c == len(columns):
                        cell.border = Border(
                            left=Side(border_style='dotted', color=border_color),
                            right=Side(border_style='thin', color=border_color))
                    else:
                        cell.border = Border(
                            right=Side(border_style='dotted', color=border_color))
                blank_row_count = blank_row_count + 1

            logger.debug("insert a new blank row before room arrivals row")
            room_arrivals_row = get_row_number(worksheet, "Room Arrivals")
            if section == "STATISTICS" and room_arrivals_row != 0:
                worksheet.insert_rows(room_arrivals_row, 1)
                worksheet.row_dimensions[room_arrivals_row].height = excel_row_height
                for c, col in enumerate(columns):
                    c = c + 1
                    cell = worksheet.cell(row=room_arrivals_row, column=c)
                    if c == 1:
                        cell.border = (
                            Border(left=Side(border_style='thin', color=border_color),
                                   right=Side(border_style='thin', color=border_color)))

                    elif c == len(columns):
                        cell.border = Border(
                            left=Side(border_style='dotted', color=border_color),
                            right=Side(border_style='thin', color=border_color))
                    else:
                        cell.border = Border(
                            right=Side(border_style='dotted', color=border_color))
                blank_row_count = blank_row_count + 1

            """
            insert a new blank row right at the bottom of every section
            """
            logger.debug(f"insert a new blank row at the bottom of section={section}, except last section")
            if i != len(section_dfs) - 1:
                worksheet.append([])
                worksheet.row_dimensions[start_row_xls + 1 + len(section_df) + blank_row_count].height = excel_row_height
                # apply border
                for c, col in enumerate(columns):
                    if c == 0:
                        worksheet.cell(row=start_row_xls + 1 + len(section_df) + blank_row_count, column=c + 1).border = (
                            Border(left=Side(border_style='thin', color=border_color)))
                    elif c == len(section_df.columns) - 1:
                        worksheet.cell(row=start_row_xls + 1 + len(section_df) + blank_row_count, column=c + 1).border = (
                            Border(right=Side(border_style='thin', color=border_color)))
                blank_row_count = blank_row_count + 1

            """
            next start row

            why start_row_xls + 1 + len(section_df) + blank_row_count + 1?

            last row in current section = start_row_xls + 1 + len(section_df).
            +1 is because we need to leave one blank row to put the parent in next section
            """
            start_row_xls = start_row_xls + 1 + len(section_df) + blank_row_count + 1

        """
        apply bold font and background color to some particular rows
        """
        logger.debug("applying bold font and background color")
        for r, row in enumerate(worksheet.iter_rows()):
            r = r + 1
            if row[0].value in ['Rooms (Total)', 'F&B Revenue', 'Others Revenue', 'TOTAL HOTEL REVENUE',
                                'Occupancy % (External)', 'Average Room Rate (External)']:
                for c, col in enumerate(columns):
                    c = c + 1
                    cell = worksheet.cell(row=r, column=c)
                    cell.font = Font(bold=True)
                    cell.fill = PatternFill(start_color=highlight_background_color2,
                                                                       end_color=highlight_background_color2,

                                                                       fill_type="solid")
            if row[0].value in ['Rooms (Internal)', 'Rooms (External)']:
                for c, col in enumerate(columns):
                    c = c + 1
                    worksheet.cell(row=r, column=c).font = Font(italic=True)
                
    except:
        raise
    finally:
        if excel_writer is not None:
            excel_writer.close()


def create_excel_detail_room(structure_df: pd.DataFrame, section_dfs: list, report_date: datetime.datetime,
                             excel_file: str, mode: str):
    """
    Create an Excel file report for the detail room

    @param structure_df - the structure dataframe
    @param section_dfs - a list of dataframe for summary sheet
    @param report_date - report date
    @param excel_file - the path of the output Excel file
    @parma mode - append or new
    """
    logger.debug(f"create excel for detail room >>>report_date={report_date}, "
                f"excel_file={excel_file}, mode={mode}")

    if structure_df is None:
        raise ValueError("structure_df is required")

    if section_dfs is None:
        raise ValueError("section_dfs is required")

    if report_date is None:
        raise ValueError("report_date is required")

    if excel_file is None or len(excel_file) == 0:
        raise ValueError("excel_file is required")

    if mode is None:
        raise ValueError("mode is required")
    
    if mode not in ["append", "new"]:
        raise ValueError("mode must be either append or new")
    
    sheet = "Detail Room"

    create_file_mode = 'a'
    if_sheet_exists = 'overlay'
    if mode == "new":
        excel_writer = pd.ExcelWriter(excel_file, engine="openpyxl")
    else:
        excel_writer = pd.ExcelWriter(excel_file, engine="openpyxl", 
                                      mode=create_file_mode, if_sheet_exists=if_sheet_exists)
    
    logger.debug(f"create excel file={excel_file}, mode={create_file_mode}, if_sheet_exists={if_sheet_exists}")

    border_all = Border(left=Side(border_style='thin', color=border_color),
                        right=Side(border_style='thin', color=border_color),
                        top=Side(border_style='thin', color=border_color),
                        bottom=Side(border_style='thin', color=border_color))

    logger.debug("structure data")
    logger.debug(structure_df)

    try:
        """
        must start from 3 because we leave 3 blank rows at the top
        1- first row for report header line 1
        2- second row for report header line 2
        3- third row for parent header
        since pandas row starts from 0, so the start_row is the fourth row in openpyxl.
        """
        start_row_xls = 4
        parent_last_columns = []
        worksheet = None
        columns = []
        for i, section_df in enumerate(section_dfs):
            section = section_df.columns.tolist()[0]
            section_df.to_excel(excel_writer, sheet_name=sheet, startrow=start_row_xls - 1, index=False)
            worksheet = excel_writer.sheets[sheet]
            logger.debug(f"write dataframe to sheet={sheet} at startrow={start_row_xls - 1}")

            worksheet.insert_rows(start_row_xls + 1, amount=1)
            section_cell = worksheet.cell(row=start_row_xls + 1, column=1)
            section_cell.value = section
            section_cell.font = Font(bold=True)
            section_cell.alignment = Alignment(horizontal="left", vertical="center")
            logger.debug(f"insert a new row before row={start_row_xls}, and set cell "
                         f"value={section} at row={start_row_xls}, column=1")

            four_border_row = 0
            highlight_row = 0
            subtotal_row = 0

            """
            merge cells for parent and update those cell value
            this is for only first section
            """
            logger.debug("merge parent cells and update children cells")
            if i == 0:
                columns = section_df.columns
                header_row_count = 2
                prev_parent = ''

                # create report header
                create_excel_header(worksheet, columns, report_date)

                for c, col in enumerate(columns):
                    # enumerate starts from 0, but openpyxl starts from 1
                    c = c + 1

                    # put a some titles at row 1 and row 2 of column 1
                    if c == 1:
                        worksheet.cell(row=start_row_xls - 1, column=1, value="COMPLEX ROOM REVENUE")
                        worksheet.cell(row=start_row_xls, column=1, value='BY MARKET SEGMENT')
                        continue

                    # grab the column name out of the table
                    column_name = worksheet.cell(start_row_xls, c).value

                    # find parent and child
                    founds = structure_df.loc[(structure_df['SheetName'] == sheet)
                                              & (structure_df['SectionName'] == section)
                                              & (structure_df['ColumnName'] == column_name)
                                              ]
                    if len(founds) == 0:
                        continue

                    parent = founds.iloc[0]['ParentColumnName']
                    child = founds.iloc[0]['ChildColumnName']
                    logger.debug(f"column={column_name} is mapped to parent={parent}, child={child}")

                    
                    # if no parent, then merge row 1 and row 2
                    if parent is None:
                        worksheet.merge_cells(start_row=start_row_xls - 1, start_column=c, end_row=start_row_xls, end_column=c)
                        cell = worksheet.cell(row=start_row_xls - 1, column=c)
                        cell.value = column_name
                        cell.alignment = Alignment(horizontal='center', vertical='center')
                        continue

                    if parent == prev_parent:
                        # update children row
                        child_cell = worksheet.cell(row=start_row_xls, column=c)
                        child_cell.value = child
                        child_cell.alignment = Alignment(horizontal='center', vertical='center')
                        continue

                    prev_parent = parent

                    children_count_df = structure_df.loc[(structure_df['SheetName'] == sheet)
                                                         & (structure_df['SectionName'] == section)
                                                         & (structure_df['ParentColumnName'] == parent)
                                                         & (structure_df['HideColumn'] == 0)]

                    logger.debug(f"find all children of parent = {parent} from structure")
                    logger.debug(children_count_df)

                    group_by_row_name_df = (
                        children_count_df.groupby("RowName", sort=False)["ExcelRow"].apply(list)
                        .reset_index(name="ExcelRows"))

                    """
                    group_by_row_name_df looks like this:

                    Room Revenue/Day  [3.0, 3.0, 3.0]
                     F&B Revenue/Day  [4.0, 4.0, 4.0]
                External Occupancy %  [5.0, 5.0, 5.0]
        External Average Room Rate (ARR)  [6.0, 6.0, 6.0]
                     Hotel Revenue $  [8.0, 8.0, 8.0]

                    the purpose is to find the first number in the list of the first row
                    because each row has the same columns.
                    """
                    logger.debug("children count dataframe grouped by RowName")
                    logger.debug(group_by_row_name_df)
                    excel_row = group_by_row_name_df.iloc[0]['ExcelRows']

                    children = children_count_df.loc[(children_count_df['ExcelRow'] == excel_row[0])]

                    logger.debug(f"children count dataframe filtered by excelrow={excel_row[0]}")
                    logger.debug(children)

                    num_col_to_span = len(children.index)
                    parent_last_columns.append(c + num_col_to_span - 1)

                    # merge, align and update value in parent row
                    worksheet.merge_cells(start_row=start_row_xls - 1, start_column=c, end_row=start_row_xls - 1,
                                          end_column=c + num_col_to_span - 1)
                    parent_cell = worksheet.cell(row=start_row_xls - 1, column=c)
                    parent_cell.value = parent
                    parent_cell.alignment = Alignment(horizontal='center', vertical='center')

                    # update children row
                    child_cell = worksheet.cell(row=start_row_xls, column=c)
                    child_cell.value = child
                    child_cell.alignment = Alignment(horizontal='center', vertical='center')
            else:
                header_row_count = 0

            """
            format and styling on data rows
            """
            logger.debug("formatting and styling")
            for c, col in enumerate(columns):
                c = c + 1

                # apply header border
                worksheet.cell(row=start_row_xls - 1, column=c).border = border_all
                worksheet.cell(row=start_row_xls, column=c).border = border_all
                if c == 1:
                    # border on first column
                    k = start_row_xls + 1
                    for cell in [worksheet.cell(row=r, column=c)
                                 for r in range(start_row_xls + 1, start_row_xls +  1 + len(section_df) + 1)]:
                        if cell.value in ['Subtotal', 'TOTAL (Excluding Internal)', 'TOTAL (Internal)']:
                            four_border_row = k
                            cell.border = Border(top=Side(border_style='thin', color=border_color),
                                                 bottom=Side(border_style='thin', color=border_color),
                                                 left=Side(border_style='thin', color=border_color),
                                                 right=Side(border_style='thin', color=border_color))
                        else:
                            if k == start_row_xls + len(section_df) + 1:
                                cell.border = Border(bottom=Side(border_style='thin', color=border_color),
                                                     left=Side(border_style='thin', color=border_color),
                                                     right=Side(border_style='thin', color=border_color))
                            else:
                                cell.border = Border(left=Side(border_style='thin', color=border_color),
                                                     right=Side(border_style='thin', color=border_color))
                        k = k + 1
                else:
                    # border on last column
                    if c == len(columns):
                        k = start_row_xls + 1
                        for cell in [worksheet.cell(row=r, column=c)
                                     for r in range(start_row_xls + 1, start_row_xls + 1 + len(section_df) + 1)]:
                            if k == four_border_row:
                                cell.border = Border(
                                    top=Side(border_style='thin', color=border_color),
                                    bottom=Side(border_style='thin', color=border_color),
                                    left=Side(border_style='dotted', color=border_color),
                                    right=Side(border_style='thin', color=border_color))
                            else:
                                if k == start_row_xls + len(section_df) + 1:
                                    cell.border = Border(bottom=Side(border_style='thin', color=border_color),
                                                         left=Side(border_style='dotted', color=border_color),
                                                         right=Side(border_style='thin', color=border_color))
                                else:
                                    cell.border = Border(left=Side(border_style='dotted', color=border_color),
                                                         right=Side(border_style='thin', color=border_color))
                            k = k + 1
                    else:
                        k = start_row_xls + 1
                        for cell in [worksheet.cell(row=r, column=c)
                                     for r in range(start_row_xls + 1, start_row_xls + 1 + len(section_df) + 1)]:
                            if four_border_row == k:
                                cell.border = Border(
                                    top=Side(border_style='thin', color=border_color),
                                    bottom=Side(border_style='thin', color=border_color),
                                    left=Side(border_style='dotted', color=border_color),
                                    right=Side(border_style='dotted', color=border_color))
                            else:
                                if k == start_row_xls + len(section_df) + 1:
                                    cell.border = Border(bottom=Side(border_style='thin', color=border_color),
                                                         left=Side(border_style='dotted', color=border_color),
                                                         right=Side(border_style='dotted', color=border_color))
                                else:
                                    cell.border = Border(left=Side(border_style='dotted', color=border_color),
                                                         right=Side(border_style='dotted', color=border_color))
                            k = k + 1

                            # right border for each parent column
                            if c in parent_last_columns:
                                k1 = start_row_xls + 1
                                for cell1 in [worksheet.cell(row=r, column=c)
                                              for r in range(start_row_xls + 1, start_row_xls + 1 + len(section_df) + 1)]:
                                    if k1 == four_border_row:
                                        cell1.border = Border(
                                            top=Side(border_style='thin', color=border_color),
                                            bottom=Side(border_style='thin', color=border_color),
                                            right=Side(border_style='thin', color=border_color))
                                    else:
                                        if k1 == start_row_xls + len(section_df) + 1:
                                            cell1.border = Border(
                                                left=Side(border_style='dotted', color=border_color),
                                                bottom=Side(border_style='thin', color=border_color),
                                                right=Side(border_style='thin', color=border_color))
                                        else:
                                            cell1.border = Border(right=Side(border_style='thin', color=border_color))
                                    k1 = k1 + 1

                # apply background color
                k = start_row_xls + 1
                for cell in [worksheet.cell(row=r, column=c)
                             for r in range(start_row_xls + 1, start_row_xls + 1 + len(section_df) + 1)]:
                    
                    # grab the variables to be in later iterations
                    if c == 1:
                        if cell.value in ['TOTAL (Excluding Internal)', 'TOTAL (Internal)']:
                            highlight_row = k
                        if cell.value == 'Subtotal':
                            subtotal_row = k

                    if k % 2 == 0:
                        cell.fill = PatternFill(start_color=even_row_background_color2,
                                                end_color=even_row_background_color2, fill_type="solid")

                    # highlight section name
                    if k == start_row_xls + 1:
                        cell.fill = PatternFill(start_color=highlight_background_color3,
                                                end_color=highlight_background_color3, fill_type="solid")
                    elif highlight_row == k:
                        cell.fill = PatternFill(start_color=highlight_background_color2,
                                                end_color=highlight_background_color2, fill_type="solid")

                    if subtotal_row == k:
                        cell.fill = PatternFill(start_color=white_color,
                                                end_color=white_color, fill_type="solid")

                    k = k + 1

                """
                apply bold font for header and row name
                this is for section 1, section 2 has no header
                """
                if i == 0:
                    worksheet.cell(row=start_row_xls - 1, column=c).font = Font(bold=True)
                    worksheet.cell(row=start_row_xls - 1, column=c).alignment = Alignment(horizontal="center",
                                                                                  vertical="center", wrap_text=True)
                    worksheet.cell(row=start_row_xls, column=c).font = Font(bold=True)
                    worksheet.cell(row=start_row_xls, column=c).alignment = Alignment(horizontal="center",
                                                                                      vertical="center", wrap_text=True)

                # set column width and row height
                column = str(chr(64 + c))
                if c == 1:
                    worksheet.column_dimensions[column].width = 40
                else:
                    worksheet.column_dimensions[column].width = 9
                k = start_row_xls - 1
                for _ in [worksheet.cell(row=r, column=c) for r in range(start_row_xls - 1, start_row_xls + 1 + len(section_df) + 1)]:
                    if i == 0:
                        if k == start_row_xls - 1:
                            worksheet.row_dimensions[k].height = 19.5
                        elif k == start_row_xls:
                            worksheet.row_dimensions[k].height = 32.25
                        else:
                            worksheet.row_dimensions[k].height = excel_row_height
                    else:
                        worksheet.row_dimensions[k].height = excel_row_height
                    k = k + 1

                # alignment
                if c == 1:
                    # first column
                    for cell in [worksheet.cell(row=r, column=1)
                                 for r in range(start_row_xls + 2, start_row_xls + 1 + len(section_df) + 1)]:
                        cell.alignment = Alignment(horizontal="left", vertical="center")
                else:
                    # data columns
                    for cell in [worksheet.cell(row=r, column=c)
                                 for r in range(start_row_xls + 2, start_row_xls + 1 + len(section_df) + 1)]:
                        cell.alignment = Alignment(horizontal="right", vertical="center")

                if c > 1:
                    # apply number format
                    if 'ARR' in col:
                        for cell in [worksheet.cell(row=r, column=c)
                                    for r in range(start_row_xls + 2, start_row_xls + 1 + len(section_df) + 1)]:
                            cell.number_format = " 0.00 "
                            if cell.value != "" and float(cell.value) < 0:
                                cell.value = (-1)*(float(cell.value))
                                cell.number_format = "(0.00)"
                    else:
                        for cell in [worksheet.cell(row=r, column=c)
                                    for r in range(start_row_xls + 2, start_row_xls + 1 + len(section_df) + 1)]:
                            cell.number_format = " #,##0 "
                            if cell.value != "" and float(cell.value) < 0:
                                cell.value = (-1)*(float(cell.value))
                                cell.number_format = "(#,##0)"

                    # replace NULL with -
                    k = start_row_xls + 2
                    for _ in [worksheet.cell(row=r, column=c)
                            for r in range(start_row_xls + 2, start_row_xls + 1 + len(section_df) + 1)]:
                        cell = worksheet.cell(row=k, column=c)
                        if cell.value == "":
                            cell.value = " - "
                        k = k + 1

            """
            subsequent section has no header
            """
            if i > 0:
                worksheet.delete_rows(start_row_xls - 1, 2)

            # increment start_row_xls for next section
            start_row_xls = start_row_xls + 1 + len(section_df) + (i + 1) * header_row_count

        """
        apply bold font to some particular rows
        """
        logger.debug("applying bold font")
        for r, row in enumerate(worksheet.iter_rows()):
            r = r + 1
            if row[0].value in ['Subtotal', 'TOTAL (Excluding Internal)', 'TOTAL (Internal)']:
                for c, col in enumerate(columns):
                    c = c + 1
                    cell = worksheet.cell(row=r, column=c)
                    cell.font = Font(bold=True)

    except:
        raise
    finally:
        if excel_writer is not None:
            excel_writer.close()


def create_excel_detail_fb(structure_df: pd.DataFrame, section_dfs: list, report_date: datetime.datetime,
                           excel_file: str, mode: str):
    """
    Create an Excel file report for the F&B

    @param structure_df - the structure dataframe
    @param section_dfs - a list of dataframe for detail fb sheet
    @param report_date - report date
    @param excel_file - the path of the output Excel file
    @param mode - append or new
    """
    logger.debug(f"create excel for detail fb >>> for report_date={report_date}, "
                f"excel_file={excel_file}, mode={mode}")

    if structure_df is None:
        raise ValueError("structure_df is required")

    if section_dfs is None:
        raise ValueError("section_dfs is required")

    if report_date is None:
        raise ValueError("report_date is required")

    if excel_file is None or len(excel_file) == 0:
        raise ValueError("excel_file is required")
    
    if mode is None:
        raise ValueError("mode is required")
    
    if mode not in ["append", "new"]:
        raise ValueError("mode must be either append or new")

    sheet = "Detail F&B"

    create_file_mode = 'a'
    if_sheet_exists = 'overlay'
    if mode == "new":
        excel_writer = pd.ExcelWriter(excel_file, engine="openpyxl")
    else:
        excel_writer = pd.ExcelWriter(excel_file, engine="openpyxl", 
                                      mode=create_file_mode, if_sheet_exists=if_sheet_exists)

    logger.debug(f"create excel file={excel_file}, mode={create_file_mode}, if_sheet_exists={if_sheet_exists}")

    border_all = Border(left=Side(border_style='thin', color=border_color),
                        right=Side(border_style='thin', color=border_color),
                        top=Side(border_style='thin', color=border_color),
                        bottom=Side(border_style='thin', color=border_color))

    logger.debug("structure data")
    logger.debug(structure_df)

    try:
        """
        must start from 3 because we leave 3 blank rows at the top
        1- first row for report header line 1
        2- second row for report header line 2
        3- third row for parent header
        since pandas row starts from 0, so the start_row is the fourth row in openpyxl.
        """
        start_row_xls = 4
        parent_last_columns = []
        worksheet = None
        columns = []
        for i, section_df in enumerate(section_dfs):
            section = section_df.columns.tolist()[0]
            section_df.to_excel(excel_writer, sheet_name=sheet, startrow=start_row_xls-1, index=False)
            worksheet = excel_writer.sheets[sheet]
            logger.debug(f"write dataframe to sheet={sheet} at startrow={start_row_xls-1}")

            prev_parent = ''

            # insert a new row for section
            worksheet.insert_rows(start_row_xls+1, amount=1)
            logger.debug(f"insert a new row before row={start_row_xls+1}")
            section_cell = worksheet.cell(row=start_row_xls + 1, column=1)
            section_cell.value = section
            section_cell.font = Font(bold=True)
            section_cell.alignment = Alignment(horizontal="center", vertical="center")
            section_cell.fill = PatternFill(start_color=white_color, end_color=white_color,
                                            fill_type="solid")

            """
            merge cells for parent and update those cell value
            this is for only first section
            """
            logger.debug("merge parent cells and update children cells")
            if i == 0:
                header_row_count = 2
                columns = section_df.columns

                # create report header
                create_excel_header(worksheet, columns, report_date)

                for c, col in enumerate(columns):
                    # enumerate starts from 0, but openpyxl starts from 1
                    c = c + 1

                    # put a section name at (row 1, col 1) and blank at (row 2, col 1)
                    if c == 1:
                        worksheet.cell(row=start_row_xls - 1, column=1, value="F&B Revenue")
                        worksheet.cell(row=start_row_xls, column=1, value='')
                        continue

                    # grab the column name out of the table
                    column_name = worksheet.cell(start_row_xls, c).value

                    # find parent and child
                    founds = structure_df.loc[(structure_df['SheetName'] == sheet)
                                              & (structure_df['SectionName'] == section)
                                              & (structure_df['ColumnName'] == column_name)
                                              ]
                    if len(founds) == 0:
                        continue

                    parent = founds.iloc[0]['ParentColumnName']
                    child = founds.iloc[0]['ChildColumnName']
                    logger.debug(f"column={column_name} is mapped to parent={parent}, child={child}")

                    # if there is no parent, we merge row 1 and row 2 of column c
                    if parent is None:
                        worksheet.merge_cells(start_row=start_row_xls - 1, start_column=c, end_row=start_row_xls, end_column=c)
                        cell = worksheet.cell(row=start_row_xls - 1, column=c)
                        cell.value = column_name
                        cell.alignment = Alignment(horizontal='center', vertical='center')
                        continue

                    # update child value if it has the same parent like the previous child
                    if parent == prev_parent:
                        child_cell = worksheet.cell(row=start_row_xls, column=c)
                        child_cell.value = child
                        child_cell.alignment = Alignment(horizontal='center', vertical='center')
                        continue

                    prev_parent = parent

                    # find the count of children of that parent
                    children_count_df = structure_df.loc[(structure_df['SheetName'] == sheet)
                                                         & (structure_df['SectionName'] == section)
                                                         & (structure_df['ParentColumnName'] == parent)
                                                         & (structure_df['HideColumn'] == 0)
                                                         & (structure_df['HideRow'] == 0)]

                    logger.debug(f"find all children of parent = {parent} from structure")
                    logger.debug(children_count_df)

                    group_by_row_name_df = (
                        children_count_df.groupby("RowName", sort=False)["ExcelRow"].apply(list)
                        .reset_index(name="ExcelRows"))

                    """
                    group_by_row_name_df looks like this:
    
                    Room Revenue/Day  [3.0, 3.0, 3.0]
                     F&B Revenue/Day  [4.0, 4.0, 4.0]
                External Occupancy %  [5.0, 5.0, 5.0]
        External Average Room Rate (ARR)  [6.0, 6.0, 6.0]
                     Hotel Revenue $  [8.0, 8.0, 8.0]
    
                    the purpose is to find the first number in the list of the first row
                    because each row has the same columns.
                    """
                    logger.debug("children count dataframe grouped by RowName")
                    logger.debug(group_by_row_name_df)
                    excel_row = group_by_row_name_df.iloc[0]['ExcelRows']

                    children = children_count_df.loc[(children_count_df['ExcelRow'] == excel_row[0])]

                    logger.debug(f"children count dataframe filtered by excelrow={excel_row[0]}")
                    logger.debug(children)

                    num_col_to_span = len(children.index)
                    parent_last_columns.append(c + num_col_to_span - 1)

                    # merge, align and update value in parent row
                    if num_col_to_span > 1:
                        worksheet.merge_cells(start_row=start_row_xls - 1, start_column=c, end_row=start_row_xls - 1,
                                          end_column=c + num_col_to_span - 1)
                    parent_cell = worksheet.cell(row=start_row_xls - 1, column=c)
                    parent_cell.value = parent
                    parent_cell.alignment = Alignment(horizontal='center', vertical='center')

                    # update children row
                    child_cell = worksheet.cell(row=start_row_xls, column=c)
                    child_cell.value = child
                    child_cell.alignment = Alignment(horizontal='center', vertical='center')
            else:
                header_row_count = 0

            """
            format and styling on data rows
            """
            logger.debug("formatting and styling")
            for c, col in enumerate(section_df.columns):
                c = c + 1

                """
                apply header border
                remove bottom border for some particular columns
                """
                parent_cell = worksheet.cell(row=start_row_xls - 1, column=c)
                child_cell = worksheet.cell(row=start_row_xls, column=c)
              
                parent_cell.border = border_all
                child_cell.border = border_all

                if c == 1:
                    # border on first column
                    k = start_row_xls + 1
                    for cell in [worksheet.cell(row=r, column=c)
                                 for r in range(start_row_xls + 1, start_row_xls + 1 + len(section_df) + 1)]:
                        if k == start_row_xls + 1:
                            cell.border = Border(top=Side(border_style='thin', color=border_color),
                                                 bottom=Side(border_style='thin', color=border_color),
                                                 left=Side(border_style='thin', color=border_color),
                                                 right=Side(border_style='thin', color=border_color))
                        elif k == start_row_xls + len(section_df) + 1:
                            cell.border = Border(bottom=Side(border_style='thin', color=border_color),
                                                 left=Side(border_style='thin', color=border_color),
                                                 right=Side(border_style='thin', color=border_color))
                        else:
                            cell.border = Border(left=Side(border_style='thin', color=border_color),
                                                 right=Side(border_style='thin', color=border_color))
                        k = k + 1
                else:
                    # border on last column
                    if c == len(columns):
                        k = start_row_xls + 1
                        for cell in [worksheet.cell(row=r, column=c)
                                     for r in range(start_row_xls + 1, start_row_xls + 1 + len(section_df) + 1)]:
                            if k == start_row_xls + 1:
                                cell.border = Border(top=Side(border_style='thin', color=border_color),
                                                     bottom=Side(border_style='thin', color=border_color),
                                                     left=Side(border_style='dotted', color=border_color),
                                                     right=Side(border_style='thin', color=border_color))
                            elif k == start_row_xls + len(section_df) + 1:
                                cell.border = Border(bottom=Side(border_style='thin', color=border_color),
                                                     left=Side(border_style='dotted', color=border_color),
                                                     right=Side(border_style='thin', color=border_color))
                            else:
                                cell.border = Border(left=Side(border_style='dotted', color=border_color),
                                                     right=Side(border_style='thin', color=border_color))
                            k = k + 1
                    else:
                        k = start_row_xls + 1
                        for cell in [worksheet.cell(row=r, column=c)
                                     for r in range(start_row_xls + 1, start_row_xls + 1 + len(section_df) + 1)]:
                            if k == start_row_xls + 1:
                                cell.border = Border(top=Side(border_style='thin', color=border_color),
                                                     bottom=Side(border_style='thin', color=border_color),
                                                     left=Side(border_style='dotted', color=border_color),
                                                     right=Side(border_style='dotted', color=border_color))
                            elif k == start_row_xls + len(section_df) + 1:
                                cell.border = Border(bottom=Side(border_style='thin', color=border_color),
                                                     left=Side(border_style='dotted', color=border_color),
                                                     right=Side(border_style='dotted', color=border_color))
                            else:
                                cell.border = Border(left=Side(border_style='dotted', color=border_color),
                                                     right=Side(border_style='dotted', color=border_color))
                            k = k + 1

                            # right border for each parent column
                            if c in parent_last_columns:
                                k1 = start_row_xls + 1
                                for cell1 in [worksheet.cell(row=r, column=c)
                                              for r in range(start_row_xls + 1, start_row_xls + 1 + len(section_df) + 1)]:
                                    if k1 == start_row_xls + 1:
                                        cell1.border = Border(
                                            bottom=Side(border_style='thin', color=border_color),
                                            right=Side(border_style='thin', color=border_color))
                                    if k1 == start_row_xls + len(section_df) + 1:
                                        cell1.border = Border(
                                            bottom=Side(border_style='thin', color=border_color),
                                            right=Side(border_style='thin', color=border_color))
                                    else:
                                        if k1 == start_row_xls + 2:
                                            cell1.border = Border(
                                                top=Side(border_style='thin', color=border_color),
                                                right=Side(border_style='thin', color=border_color))
                                        else:
                                            cell1.border = Border(right=Side(border_style='thin', color=border_color))
                                    k1 = k1 + 1

                # apply background color
                k = start_row_xls + 1
                for cell in [worksheet.cell(row=r, column=c)
                             for r in range(start_row_xls + 1, start_row_xls + 1 + len(section_df) + 1)]:
                    if k != start_row_xls + 1 and k % 2 == 0:
                        cell.fill = PatternFill(start_color=even_row_background_color2,
                                                end_color=even_row_background_color2, fill_type="solid")
                    k = k + 1

                """
                apply bold font for header and row name
                this is for section 1, section 2 has no header
                """
                if i == 0:
                    worksheet.cell(row=start_row_xls - 1, column=c).font = Font(bold=True)
                    worksheet.cell(row=start_row_xls - 1, column=c).alignment = Alignment(horizontal="center",
                                                                                  vertical="center", wrap_text=True)
                    worksheet.cell(row=start_row_xls, column=c).font = Font(bold=True)
                    worksheet.cell(row=start_row_xls, column=c).alignment = Alignment(horizontal="center",
                                                                                      vertical="center", wrap_text=True)

                # set column width and row height
                column = str(chr(64 + c))
                if c == 1:
                    worksheet.column_dimensions[column].width = 30
                else:
                    worksheet.column_dimensions[column].width = 10
                k = start_row_xls - 1
                for _ in [worksheet.cell(row=r, column=c) for r in range(start_row_xls - 1, start_row_xls + 1 + len(section_df) + 1)]:
                    if i == 0:
                        if k == start_row_xls - 1:
                            worksheet.row_dimensions[k].height = 18
                        elif k == start_row_xls:
                            worksheet.row_dimensions[k].height = 25.25
                        else:
                            worksheet.row_dimensions[k].height = excel_row_height
                    else:
                        worksheet.row_dimensions[k].height = excel_row_height
                    k = k + 1

                # alignment
                if c == 1:
                    # first column
                    for cell in [worksheet.cell(row=r, column=1)
                                 for r in range(start_row_xls + 2, start_row_xls + 1 + len(section_df) + 1)]:
                        cell.alignment = Alignment(horizontal="left", vertical="center")
                else:
                    # data columns
                    for cell in [worksheet.cell(row=r, column=c)
                                 for r in range(start_row_xls + 2, start_row_xls + 1 + len(section_df) + 1)]:
                        cell.alignment = Alignment(horizontal="right", vertical="center")

                if c > 1:
                    # apply number format  
                    for cell in [worksheet.cell(row=r, column=c)
                                for r in range(start_row_xls + 2, start_row_xls + 1 + len(section_df) + 1)]:
                        cell.number_format = " #,##0 "
                        if cell.value != "" and float(cell.value) < 0:
                            cell.value = (-1)*(float(cell.value))
                            cell.number_format = "(#,##0)"
                    
                    # replace NULL with -
                    k = start_row_xls + 2
                    for _ in [worksheet.cell(row=r, column=c)
                              for r in range(start_row_xls + 2, start_row_xls + 1 + len(section_df) + 1)]:
                        cell = worksheet.cell(row=k, column=c)
                        if cell.value == "":
                            cell.value = " - "
                        k = k + 1

            # second section does not have header
            if i == 1:
                worksheet.delete_rows(start_row_xls - 1, 2)

            # increment start_row
            start_row_xls = start_row_xls + 1 + len(section_df) + (i + 1) * header_row_count

        
        # apply bold font and background color to some particular rows
        logger.debug("applying bold font and background color")
        for r, row in enumerate(worksheet.iter_rows()):
            if 'Total' in row[0].value:
                for c, col in enumerate(columns):
                    worksheet.cell(row=r + 1, column=c + 1).font = Font(bold=True)
                    worksheet.cell(row=r + 1, column=c + 1).fill = PatternFill(start_color=highlight_background_color2,
                                                                               end_color=highlight_background_color2,
                                                                               fill_type="solid")
    except:
        raise
    finally:
        if excel_writer is not None:
            excel_writer.close()


def create_excel(structure_df: pd.DataFrame, sheet_dict: dict, report_date: datetime.datetime,
                 excel_file: str):
    """
    Create excel report

    @param structure_df - the structure dataframe
    @param sheet_dict - a dictionary of data
    @param report_date - report date
    @param excel_file - the path of the output Excel file
    """
    logger.debug(f"create excel >>> report_date={report_date}, excel_file={excel_file}")

    if structure_df is None:
        raise ValueError("structure_df is required")

    if sheet_dict is None:
        raise ValueError("sheet_dict is required")

    if report_date is None:
        raise ValueError("report_date is required")

    if excel_file is None or len(excel_file) == 0:
        raise ValueError("excel_file is required")

    for sheet, dfs in sheet_dict.items():
        match sheet:
            case "Summary":
                create_excel_summary(structure_df, dfs, report_date, excel_file, "new")
            case "Detail Room":
                create_excel_detail_room(structure_df, dfs, report_date, excel_file, "append")
            case "Detail F&B":
                create_excel_detail_fb(structure_df, dfs, report_date, excel_file, "append")
            case "Executive Summary":
                create_excel_executive_summary(structure_df, dfs, excel_file, "append")
            case _:
                pass
