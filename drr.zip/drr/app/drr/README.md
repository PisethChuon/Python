### Specification

```sh

odbcinst -q -d

```

Update environment variables ```.env```

### How to develop

Install python packages and run application

```sh
# active environment
python -m venv .venv
source ./.venv/bin/activate 

# install packages
pip install -r requirements.txt

# clear and reset app
python -m drr.command_listener run
python -m drr.command_listener clear

# start app
python -m drr.report

```