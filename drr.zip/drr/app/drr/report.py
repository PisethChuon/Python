"""
Report module is the main module of the scripts.

Author: Phann Malinka
"""
import logging
import sys
import os
import time
import datetime
from zipfile import ZipFile
from drr import config_reader
from drr import db, email, html
from drr.email import get_email_account
from drr.excel import create_excel
from drr.pdf import create_pdf
from drr.my_logger import logger
from drr.error import MissingEmailError, StatusFailError, ScriptBusyError, SyncDataError
from drr.util import *
from drr.util_config import *


config = config_reader.get()
report_dir = config[REPORT_DIR]


def get_log_attachment_data():
    """
    get log attachment data
    """
    
     # attach log file to email
    attachment_data = []

    # zip the file
    now = datetime.datetime.now()
    file_name = f"drr-{now.strftime('%Y%m%d')}"
    log_file = os.path.join(config[LOG_DIR], f"{file_name}.log")
    zip_file = os.path.join(config[LOG_DIR], f"{file_name}.zip")
    with ZipFile(zip_file, 'w') as myzip:
        myzip.write(log_file)

    with open(zip_file, "rb") as f:
        content = f.read()
        attachment_data.append((f"{file_name}.zip", content))
    
    return attachment_data


def send_report(report_date: datetime.datetime):
    """
    Send the report

    @param report_date - the datetime of the report
    """

    if report_date is None:
        raise ValueError('report_date is required')
    
    report_date_for_file = report_date.strftime("%d%m%y")
    report_date_for_subject = report_date.strftime("%d %B %Y")
    logger.debug(f"report date for query = {report_date}")

    """
    Report File Name
    """
    report_file_name = f"{config[REPORT_NAME]} {report_date_for_file}"
    subject = f"{config[REPORT_NAME]} {report_date_for_subject}"
    pdf_file = os.path.join(report_dir, f"{report_file_name}.pdf")
    excel_file = os.path.join(report_dir, f"{report_file_name}.xlsx")

    logger.debug(f"report file name={report_file_name}, "
                f"pdf file={pdf_file}, excel file={excel_file}")

    """
    SSC
    """
    ssc_subject = config[SSC_SUBJECT]
    ssc_sender = config[SSC_SENDER]
    ssc_search = config[SSC_SEARCH]

    recipient_group1 = read_recipients(config[MAIL_DRR_RECIPIENTS_GROUP1])
    logger.debug(f"group1 recipients={recipient_group1}")

    # email search date is one day after report date, and starts from midnight to midnight
    search_from_date = datetime.datetime(year=report_date.year, 
                                 month=report_date.month, 
                                 day=report_date.day) + datetime.timedelta(days=1)
    
    search_to_date = datetime.datetime(year=report_date.year, 
                                 month=report_date.month, 
                                 day=report_date.day,
                                 hour=23,
                                 minute=59,
                                 second=59) + datetime.timedelta(days=1)

    email_account = get_email_account(0)

    """
    1. search the 3 successful emails from SSC sender
    """
    filtered_by_sender = email.search_emails_by_subject_sender(email_account=email_account, 
                                 subject=ssc_subject, 
                                 sender=ssc_sender,
                                 search_from=search_from_date,
                                 search_to=search_to_date)
    
    if logger.level == logging.DEBUG:
        for e in filtered_by_sender:
            datetime_received = e.datetime_received.astimezone(email_account.default_timezone)
            logger.debug(f"datetime received: {datetime_received}")
            logger.debug(f"sender: {e.sender}")
            logger.debug(f"subject: {e.subject}")

    if len(filtered_by_sender) < 3:
        raise MissingEmailError(subject=config[MAIL_NOTIFY_FAIL1_SUBJECT],
                                body=config[MAIL_NOTIFY_FAIL1_BODY],
                                message=f"{len(filtered_by_sender)} emails received from "
                                f"ssc sender={ssc_sender}, subject={ssc_subject}, "
                                f"from={search_from_date}, to={search_to_date}")

    filter_by_keyword = [e for e in filtered_by_sender if ssc_search in e.body]
    if len(filter_by_keyword) < 3:
        raise StatusFailError(subject=config[MAIL_NOTIFY_FAIL2_SUBJECT],
                              body=config[MAIL_NOTIFY_FAIL2_BODY],
                              message=f"{len(filter_by_keyword)} emails received from "
                              f"ssc sender={ssc_sender}, subject={ssc_subject}, keyword={ssc_search}, "
                              f"from={search_from_date}, to={search_to_date}")
    
    logger.debug(f"SSC email check: found {len(filter_by_keyword)} emails sent from sender={ssc_sender}, " 
                f"subject={ssc_subject}, keyword={ssc_search}, from={search_from_date}, to={search_to_date}")

    """
    2. sync data
    """
    logger.debug(f"Sync data starts ...")
    try:
        db.sync_data()
    except Exception as e:
        subject = config[MAIL_NOTIFY_FAIL3_SUBJECT]
        body = config[MAIL_NOTIFY_FAIL3_BODY]
        log = "sync fail"
        raise SyncDataError(subject=subject, body=body, message=log)
    logger.debug(f"Sync data done")

    sheet_dict = {}
    # query for data only if there are no data file
    structure_df = db.get_structure()
    sheet_dict = db.get_sheets_data(structure_df, report_date)
    create_excel(structure_df, sheet_dict, report_date, excel_file)
    create_pdf(sheet_dict, report_date, pdf_file)
    
    # check if report files exist
    if not os.path.isfile(pdf_file):
        raise IOError(f"pdf file = {pdf_file} does not exist")

    if not os.path.isfile(excel_file):
        raise IOError(f"excel file = {excel_file} does not exist")

    # read files to be attached byte by byte and add them all to attachement_data
    attachment_data = []
    
    with open(pdf_file, "rb") as f:
        content = f.read()
    attachment_data.append((f"{report_file_name}.pdf", content))

    with open(excel_file, "rb") as f:
        content = f.read()
    attachment_data.append((f"{report_file_name}.xlsx", content))

    # create email body
    if "Executive Summary" in sheet_dict:
        html_str = html.create_html(sheet_dict["Executive Summary"], subject)
        with open(os.path.join(report_dir,"es.html"), "w") as text_file:
            text_file.write(html_str)
    else:
        html_str = None

    # send email to recipient group1
    for g in recipient_group1:
        email.send_email(email_account=email_account,
                        subject=subject,
                        to_recipients=g['to'],
                        cc_recipients=g['cc'],
                        bcc_recipients=g['bcc'],
                        body=html_str,
                        attachments=attachment_data)

        # log status success message
        logger.info(f"sent report with {len(attachment_data)} attachments, subject: {subject}, to: {g['to']}, cc: {g['cc']}, bcc: {g['bcc']}")

    """
    send email to recipient group2
    only send the pdf file
    """
    time.sleep(10)

    recipient_group2 = read_recipients(config[MAIL_DRR_RECIPIENTS_GROUP2])
    pdf_attachment_data = []
    with open(pdf_file, "rb") as f:
        content = f.read()
    pdf_attachment_data.append((f"{report_file_name}.pdf", content))
    for g in recipient_group2:
        email.send_email(email_account=email_account,
            subject=subject,
            to_recipients=g['to'],
            cc_recipients=g['cc'],
            bcc_recipients=g['bcc'],
            body=html_str,
            attachments=pdf_attachment_data)
        
        # log status success message
        logger.info(f"sent report with {len(pdf_attachment_data)} attachments, subject: {subject}, to: {g['to']}, cc: {g['cc']}, bcc: {g['bcc']}")
    

def run_report(report_date: datetime.datetime, log_level: str, command: str, run_by: str, receive_dt: str, caller: str):
    """
    run it

    @param report_date - the report date
    @param log_level - the log level
    @param command - the given command
    @param run_by - the command run by
    @param receive_dt - the date time the command is received either through email 
                        or command line
    @param caller - who calls this function
    """

    # turn off annoying INFO log from exchange lib
    logging.getLogger('exchangelib.fields').setLevel(logging.WARNING)

    logger.setLevel(log_level)

    logger.debug(f"run with report date={report_date}, log level={log_level}, command={command}, "
                f"run by={run_by}, receive dt={receive_dt}, caller={caller}")

    try:
        email_account = get_email_account(0)

        """
        Check the running status to see if anyone is running the script.
        The script can only run once at a time.
        """
        script_running_status_df = db.get_latest_running_log()
        logger.debug(f"[{caller}]: script running status dataframe")
        logger.debug(script_running_status_df)
        start_dt = None
        stop_dt = None
        status = None
        if len(script_running_status_df) == 1:
            start_dt = script_running_status_df.iloc[0]["start_dt"]
            stop_dt = script_running_status_df.iloc[0]["stop_dt"]
            status = script_running_status_df.iloc[0]["status"]
        else:
            logger.debug(f"[{caller}]: script was never run before")

        if start_dt != None and stop_dt == None and status == None:
                logger.debug(f"[{caller}]: script is busy, it was started since {start_dt}")
                run_by = script_running_status_df.iloc[0]["run_by"]
                start_dt = script_running_status_df.iloc[0]["start_dt"]
                subject = config[MAIL_NOTIFY_FAIL6_SUBJECT]
                log_message = config[MAIL_NOTIFY_FAIL6_BODY].format(run_by, start_dt)
                raise ScriptBusyError(subject=subject, body=log_message, message=log_message)
        
        start_dt = datetime.datetime.now().strftime(DB_DT_FORMAT)

        # insert a new running log
        db.insert_and_start_log(command=command, run_by=run_by, receive_dt=receive_dt, start_dt=start_dt)
        logger.debug(f"[{caller}]: insert new running status log: run_by={run_by}, receive_dt={receive_dt}, start_dt={start_dt}")
    
        # work on sending the report email
        logger.info(f"[{caller}]: Generate DRR Report for {report_date} begin -----------------------")
        send_report(report_date)

        """
        to make sure the success notification email is sent after the drr is, 
        we need to sleep for a little while.
        """
        time.sleep(10)

        # work on sending the success notification email
        recipient_groups = read_recipients(config[MAIL_NOTIFY_SUCCESS_RECIPIENTS])
        for g in recipient_groups:
            email.send_email(email_account=email_account, 
                        subject=config[MAIL_NOTIFY_SUCCESS_SUBJECT], 
                        to_recipients=g["to"],
                        cc_recipients=g["cc"],
                        bcc_recipients=g["bcc"],
                        body=None)
            
        logger.debug(f"[{caller}]: Generate DRR Report for {report_date} end -----------------------")

        db.log_status(receive_dt=receive_dt, status=ScriptStatusEnum.SUCCESS.name)

    except ScriptBusyError as e:
        """
        Script is being run by someone else, please wait
        """
        logger.error(f"[{caller}]: ScriptBusyError: {e}")
        db.log_status(receive_dt=receive_dt, status=ScriptStatusEnum.FAIL.name)
        recipient_groups = read_recipients(config[MAIL_NOTIFY_FAIL6_RECIPIENTS])

        for g in recipient_groups:
            email.send_email(email_account=email_account, 
                         subject=e.subject,
                         body=e.body,
                         to_recipients=g["to"],
                         cc_recipients=g["cc"],
                         bcc_recipients=g["bcc"],
                         # send attachment because this email is sent to Jegan, Samaune, and me
                         attachments=get_log_attachment_data())
    except SyncDataError as e:
        """
        Sync fail
        """
        logger.error(f"[{caller}]: SyncDataError: {e}")
        db.log_status(receive_dt=receive_dt, status=ScriptStatusEnum.FAIL.name)
        recipient_groups = read_recipients(config[MAIL_NOTIFY_FAIL_RECIPIENTS])
        for g in recipient_groups:
            email.send_email(email_account=email_account, 
                         subject=e.subject,
                         body=e.body,
                         to_recipients=g["to"],
                         cc_recipients=g["cc"],
                         bcc_recipients=g["bcc"])
    except MissingEmailError as e:
        """
        There must be 3 SSC Notification emails. 
        If not, we send a notification email.
        """
        logger.error(f"[{caller}]: MissingEmailError: {e}")
        db.log_status(receive_dt=receive_dt, status=ScriptStatusEnum.FAIL.name)
        recipient_groups = read_recipients(config[MAIL_NOTIFY_FAIL_RECIPIENTS])
        for g in recipient_groups:
            email.send_email(email_account=email_account, 
                         subject=e.subject, 
                         body=e.body,
                         to_recipients=g["to"],
                         cc_recipients=g["cc"],
                         bcc_recipients=g["bcc"])
    except StatusFailError as e:
        """
        All the 3 SSC Notification emails must contain the successful status message.
        If not, we send a notification email.
        """
        logger.error(f"[{caller}]: StatusFailError: {e}")
        db.log_status(receive_dt=receive_dt, status=ScriptStatusEnum.FAIL.name)
        recipient_groups = read_recipients(config[MAIL_NOTIFY_FAIL_RECIPIENTS])
        for g in recipient_groups:
            email.send_email(email_account=email_account, 
                         subject=e.subject,
                         body=e.body, 
                         to_recipients=g["to"],
                         cc_recipients=g["cc"],
                         bcc_recipients=g["bcc"])

    except Exception as e:
        """
        All other errors will be caught here, 
        and a notification email will also be sent.
        """
        logger.error(f"[{caller}]: DRRError: {str(e)}")
        db.log_status(receive_dt=receive_dt, status=ScriptStatusEnum.FAIL.name)
        subject = config[MAIL_NOTIFY_FAIL4_SUBJECT]
        body = config[MAIL_NOTIFY_FAIL4_BODY]
        recipient_groups = read_recipients(config[MAIL_NOTIFY_FAIL_RECIPIENTS])
        for g in recipient_groups:
            email.send_email(email_account=email_account, 
                         subject=subject, 
                         body=body,
                         to_recipients=g["to"],
                         cc_recipients=g["cc"],
                         bcc_recipients=g["bcc"])
    finally:
        # release the lock
        db.log_status_when_stop(receive_dt=receive_dt, stop_dt=datetime.datetime.now().strftime(DB_DT_FORMAT))


def run():
    """
    To be called by scheduler
    """
    today = datetime.datetime.now()
    yesterday = today - datetime.timedelta(days=1)
    report_date = yesterday
    debug_level = logging.INFO
    command = 'python -m drr.report'
    receive_dt_db = today.strftime(DB_DT_FORMAT)
    try:
        run_report(report_date=report_date, log_level=debug_level, command=command, run_by=SCHEDULER_NAME, receive_dt=receive_dt_db, caller='Report')
    except:
        """
        to tell logger it is time to send the log to all handlers.
        """
        if logger.level == logging.DEBUG:
            logger.debug("\n")
        elif logger.level == logging.INFO:
            logger.info("\n")
        elif logger.level == logging.WARNING:
            logger.warning("\n")
        elif logger.level == logging.ERROR:
            logger.error("\n")
        elif logger.level == logging.CRITICAL:
            logger.critical("\n")


if __name__ == "__main__":
    """
    Support these commands
    - python -m drr.report
    - python -m drr.report info 2024-08-22
    - python -m drr.report debug 2024-08-22
    """
    today = datetime.datetime.now()
    yesterday = today - datetime.timedelta(days=1)
    report_date = yesterday
    debug_level = logging.INFO
    args = sys.argv[1:]
    command = 'python -m drr.report'
    if len(args) != 0 and len(args) != 2:
        logger.error("Command Syntax")
        logger.error("python -m drr.report")
        logger.error("python -m drr.report info <report_date>")
        logger.error("python -m drr.report debug <report_date>")
        exit(0)
    if len(args) == 2:
        debug_level = args[0].upper()
        report_date_str = args[1]
        report_date = datetime.datetime.strptime(report_date_str, "%Y-%m-%d")
        command = f"{command} {args[0]} {args[1]}"

    receive_dt_db = today.strftime(DB_DT_FORMAT)

    try:
        run_report(report_date=report_date, log_level=debug_level, command=command, run_by=SCHEDULER_NAME, receive_dt=receive_dt_db, caller='Report')
    except Exception as e:
        """
        this block is not supposed to run; but if it is, it means something goes wrong with send_email method.
        """
        logger.error(str(e))
    finally:
        """
        to tell logger it is time to send the log to all handlers.
        """
        if logger.level == logging.DEBUG:
            logger.debug("\n")
        elif logger.level == logging.INFO:
            logger.info("\n")
        elif logger.level == logging.WARNING:
            logger.warning("\n")
        elif logger.level == logging.ERROR:
            logger.error("\n")
        elif logger.level == logging.CRITICAL:
            logger.critical("\n")
