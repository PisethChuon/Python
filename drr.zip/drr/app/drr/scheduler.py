"""
This is the scheduler for DRR.
It basically runs 3 jobs on schduler.
- execute command listener clear
- execute command listener run
- execute report

"""
import schedule
import time
from drr import config_reader
from drr.util_config import *
from drr import command_listener
from drr import report


config = config_reader.get()
cmd_run_every = int(config[CMD_RUN_EVERY])
report_run_at = config[REPORT_RUN_AT]

def run_cmd_listener_clear():
    command_listener.clear()

def run_cmd_listener_run():
    command_listener.run()

def run_report():
    report.run()

schedule.every(cmd_run_every).seconds.do(run_cmd_listener_clear)
schedule.every(cmd_run_every).seconds.do(run_cmd_listener_run)
schedule.every().day.at(report_run_at).do(run_report)

"""
schedule.every().hour.do(job)
schedule.every().day.at("10:30").do(job)
schedule.every().monday.do(job)
schedule.every().wednesday.at("13:15").do(job)
schedule.every().day.at("12:42", "Europe/Amsterdam").do(job)
schedule.every().minute.at(":17").do(job)
"""

while True:
    schedule.run_pending()
    time.sleep(1)