"""
HTML module is to take care of generating HTML script.

Author: Phann Malinka
"""
from bs4 import BeautifulSoup as bs
import pandas as pd
from drr.my_logger import logger
from drr.util import html_font_name, html_font_size


def print_html(html: str):
    soup = bs(html, features="lxml")
    prettyHTML = soup.prettify()
    logger.debug(prettyHTML)


def create_html_nagaworld(data_df: pd.DataFrame) -> str:
    """
    create html string for nagaworld

    @param data_df - the dataframe
    @return html string for nagaworld section
    """
    
    if data_df is None:
        raise ValueError("data_df is required")
    
    if len(data_df.columns.tolist()) == 0:
        raise ValueError("data_df has no columns")
    
    section = data_df.columns.tolist()[0]

    html = f"""
    <tr>
        <td rowspan=2 colspan=2 style='border:1px solid black;text-align:center'>{section}</td>
        <td colspan=3 style='border:1px solid black;text-align:center'>Today Actual</td>
        <td colspan=3 style='border:1px solid black;text-align:center'>MTD Actual</td>
        <td colspan=3 style='border:1px solid black;text-align:center'>YTD Actual</td>
    </tr>
    <tr>
        <td style='border:1px solid black;text-align:center'>Naga 1</td>
        <td style='border:1px solid black;text-align:center'>Naga 2</td>
        <td style='border:1px solid black;text-align:center'>Total</td>
        <td style='border:1px solid black;text-align:center'>Naga 1</td>
        <td style='border:1px solid black;text-align:center'>Naga 2</td>
        <td style='border:1px solid black;text-align:center'>Total</td>
        <td style='border:1px solid black;text-align:center'>Naga 1</td>
        <td style='border:1px solid black;text-align:center'>Naga 2</td>
        <td style='border:1px solid black;text-align:center'>Total</td>
    </tr>
    """

    for r, row in data_df.iterrows():
        tr = "<tr>" if row[section] != "Hotel Revenue $" else \
            """
            <tr style='height: 10px'>
                <td colspan=2 style='border:1px solid black;'></td>
                <td style='border:1px solid black;'></td>
                <td style='border:1px solid black;'></td>
                <td style='border:1px solid black;'></td>
                <td style='border:1px solid black;'></td>
                <td style='border:1px solid black;'></td>
                <td style='border:1px solid black;'></td>
                <td style='border:1px solid black;'></td>
                <td style='border:1px solid black;'></td>
                <td style='border:1px solid black;'></td>
            </tr>
            <tr>
            """
        for c, col in enumerate(data_df.columns):
            if c == 0:
                value = row[col]
            elif row[section] == 'External Occupancy %':
                value = f"{row[col]:.1%}"
            elif row[section] == 'External Average Room Rate (ARR)':
                value = f"{row[col]:,.2f}"
            else:
                value = f"{row[col]:,.0f}"

            td = f"""
                <td colspan=2 style='border:1px solid black;width:250px;'>{value}</td>""" if c == 0 \
                else f"<td style='border:1px solid black;text-align:center''>{value}</td>"
            tr = tr + td
        tr = tr + "</tr>"
        html = html + tr

    return html


def create_html_mtd(data_df: pd.DataFrame) -> str:
    """
    create html for mtd section

    @param data_df - the dataframe
    @return html string
    """

    if data_df is None:
        raise ValueError("data_df is required")
    
    if len(data_df.columns.tolist()) == 0:
        raise ValueError("data_df has no columns")

    section = data_df.columns.tolist()[0]
    html = f"<tr><td colspan=5 style='min-width:600px'><h4>{section}</h4><td></tr>"

    for r, row in data_df.iterrows():
        tr = f"""
        <tr>
            <td style='width:10px'>•</td>
            <td colspan=10 style='text-align:left'>{row[section]}</td>
        </tr>
        """
        html = html + tr

    return html


def create_html_key_data(data_df: pd.DataFrame) -> str:
    """
    create html for key data section

    @param data_df - the dataframe
    @return html string
    """

    if data_df is None:
        raise ValueError("data_df is required")
    
    if len(data_df.columns.tolist()) == 0:
        raise ValueError("data_df has no columns")

    section = data_df.columns.tolist()[0]
    html = f"<tr><td colspan=3><h4>{section}</h4></td></tr>"

    for r, row in data_df.iterrows():
        tr = f"""
        <tr>
            <td>•</td>
            <td colspan=4 style='text-align:left'>{row[section]}</td>
            <td colspan=5 style='text-align:left'>{row['SegmentValue']}</td>
        </tr>
        """ if r < 2 else f"""
        <tr>
            <td></td>
            <td colspan=4 style='text-align:left'>{row[section]}</td>
            <td colspan=5 style='text-align:left'>{row['SegmentValue']}</td>
        </tr>
        """
        html = html + tr
    
    return html


def create_html(data_dfs: list, email_subject: str):
    
    # starting html str
    html = f"""
    <style type="text/css">
        td {{
             font-family: {html_font_name};
             font-size: {html_font_size};
        }}
        table {{
            border-collapse: collapse;
            table-layout: fixed;
        }}
    </style>
    <table cellspacing=0 cellpadding=5 border=0>
        <tr>
            <td colspan=11 style='text-align:left'>Dear All,</td>
        </tr>
        <tr>
            <td colspan=11 style='text-align:left'>I attach the {email_subject} for your reference.</td>
        </tr>
    """

    for i, df in enumerate(data_dfs):
            section = df.columns.tolist()[0]
            match section:
                case "NAGAWORLD":
                    html = html + create_html_nagaworld(df) + "<tr style='height:10px;'></tr>"
                case "MTD External Rooms Occupancy % (Market Segments)":
                    html = html + create_html_mtd(df) + "<tr style='height:10px;'></tr>"
                case "Key Data F&B":
                    html = html + create_html_key_data(df)
                case _:
                    pass

    html = html + """
            <tr>
                <td colspan=11 style='text-align:left'>Thanks and best regards,</td>
            </tr>
            <tr>
                <td colspan=11 style='text-align:left;'>
                    <p>
                        <span style='font-weight: bold'>Hotel Finance</span><br/>
                        <span>NagaWorld Limited</span><br/>
                        <span>Samdach Techo Hun Sen Park | Phnom Penh Kingdom of Cambodia.</span><br/>
                        <span>P.O. Box 1099 Phnom Penh</span><br/>
                        <span>FAX: +855 23 225 888</span></br>
                    </p>
                </td>
            </tr>
        </table>"""

    return html

    



