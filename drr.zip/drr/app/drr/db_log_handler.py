import logging
from sqlalchemy import text
from sqlalchemy import create_engine
from drr.util_config import *
from drr import config_reader

config = config_reader.get()

def get_engine():
    """
    Get database engine
    """
    params = (f"DRIVER={config[DB_DRIVER]};"
                         f"SERVER={config[DB_SERVER]};"
                         f"DATABASE={config[DB_DATABASE]};"
                         f"UID={config[DB_USERNAME]};"
                         f"PWD={config[DB_PASSWORD]};")
    return create_engine(f"mssql+pyodbc:///?odbc_connect={params}", future=True, pool_size=50, 
                         max_overflow=0)

class DbLogHandler(logging.Handler):
    """
    This handle is reponsible for writing log to database

    """
    def __init__(self):
        logging.Handler.__init__(self)
        self.total_log = ""

    def emit(self, record):
        log = format(record.message)
        if log != "\n":
            log = log.strip()
            log = log.replace('\"', '\'')
            # accumulate all the log
            json_log = '{"timestamp": "%s","log": "%s"}' % (record.asctime, log)
            self.total_log = json_log if self.total_log == "" else self.total_log + "," + json_log
        else:
            # time to send the log to database
            self.total_log = '[%s]' % self.total_log
            try:
                with get_engine().connect() as conn:
                    sql = text("""
                        INSERT INTO dbo.Log (module, level, log) 
                        VALUES (:module,:level,:log)
                        """)
                    conn.execute(sql, {'module': record.module, 'level': record.levelname, 'log': self.total_log})
                    conn.commit()
            except Exception as e:
                print(str(e))