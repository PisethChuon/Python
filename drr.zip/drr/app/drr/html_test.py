"""
HTML test module is to test html module

Author: Phann Malinka
"""
import datetime
from drr import db, html
from drr.util import get_sheets_data

def test_html():
    today = datetime.datetime.now()
    yesterday = today - datetime.timedelta(days=1)
    report_date = yesterday.strftime("%d%m%y")
    structure_df = db.get_structure()
    sheet_dict = get_sheets_data(structure_df, yesterday)
    es_dfs = sheet_dict["Executive Summary"]
    data_df = es_dfs[0]
    html_str = html.create_html(es_dfs)
    with open("tmp/es1.html", "w") as text_file:
        text_file.write(html_str)



if __name__ == '__main__':
    test_html()