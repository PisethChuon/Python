"""
DB module is the module that talks to the database.

Author: Phann Malinka
"""
import datetime
from drr.util import drop_cols, drop_rows, replace_excel_column_names
from drr.my_logger import logger
from sqlalchemy import text
import pandas as pd
from drr.util_config import *
from sqlalchemy import create_engine
from drr.error import DatabaseConnectionError
from drr import config_reader
from drr.my_logger import logger
import time


config = config_reader.get()

def get_engine():
    """
    Get database engine
    """
    params = (f"DRIVER={config[DB_DRIVER]};"
                         f"SERVER={config[DB_SERVER]};"
                         f"DATABASE={config[DB_DATABASE]};"
                         f"UID={config[DB_USERNAME]};"
                         f"PWD={config[DB_PASSWORD]};")
    return create_engine(f"mssql+pyodbc:///?odbc_connect={params}", future=True, pool_size=50, 
                         max_overflow=0)


def get_connection(retry: int):
    """
    get db connection

    @param retry - number of retries
    """
    
    try:
        return get_engine().connect()
    except Exception as e:
        if retry == 0:
            logger.error(f"=== DB CONNECTION INFO ===")
            logger.error(f"server: {config[DB_SERVER]}")
            logger.error(f"database: {config[DB_DATABASE]}")
            logger.error(f"username: {config[DB_USERNAME]}")
        logger.error(str(e))
        retry = retry + 1
        if (retry <= int(config[CONNECTION_RETRY])):
            logger.error(f"sleep for {config[RETRY_INTERVAL]} seconds")
            time.sleep(int(config[RETRY_INTERVAL]))
            logger.error(f"db connection retry: {retry}")
            return get_connection(retry)
        else:
            raise DatabaseConnectionError(str(e))


def get_structure():
    """
    Get structure for building template
    """
    logger.debug("get structure data")
    
    with get_connection(0) as conn:
        sql = text("""
            SELECT SheetName, SheetOrder, SectionName, RowName, 
            ColumnName, ParentColumnName, ChildColumnName, ExcelColumn, ExcelRow, 
            HideColumn, HideRow FROM [dbo].[Config] 
            GROUP BY SheetName, SheetOrder, SectionName, SectionOrder, RowName, 
            ColumnName, ParentColumnName, ChildColumnName, ExcelColumn, ExcelRow, HideColumn, HideRow 
            ORDER BY SheetOrder ASC,SectionOrder ASC,ExcelRow ASC,ExcelColumn ASC
            """)
        result = conn.execute(sql)
        df = pd.DataFrame(result)
        return df


def get_data(report_date: datetime.datetime, sheet: str, section: str):
    """
    Get data

    @param report_date - the report date
    @param sheet the - the sheet name
    @param section - the section in the sheet
    """
    logger.debug(f"get data for report_date={report_date}, sheet={sheet}, section={section}")

    if report_date is None:
        raise ValueError("report_date is required")

    if sheet is None or len(sheet) == 0:
        raise ValueError("sheet is required")

    report_date_for_db = report_date.strftime('%Y-%m-%d')

    with get_connection(0) as conn:
        sql = text("""
            SET NOCOUNT ON; 
            exec [DRR].[dbo].[GetReport] @inputDate=:inputDate, @sheet=:sheet, @section=:section""")
        values = {'inputDate': report_date_for_db, 'sheet': sheet, 'section': section}
        result = conn.execute(sql, values)
        df = pd.DataFrame(result)
        conn.commit()
        return df


def get_sheet_data(structure_df: pd.DataFrame, report_date: datetime.datetime, sheet: str) -> list:
    """
    Get data for a particular sheet. The data will be grouped into section.
    The header mapping must be done as well because the raw data has no friendly header name.

    @param structure_df - the structure dataframe
    @param report_date - the date of the report in format "YYYY-MM-DD"
    @param sheet - the sheet name
    @return a list of report dataframe
    """
    logger.debug(f"get sheet data >>> report_date = {report_date}, sheet = {sheet}")

    if structure_df is None:
        raise ValueError("structure_df is required")

    if report_date is None:
        raise ValueError("report_date is required")

    if sheet is None or len(sheet) == 0:
        raise ValueError("sheet is required")


    """
    Get sections from the given structure
    group_by_section_df will look like this:

        SectionName                                          ExcelRows
    0     Revenue  [12.0, 12.0, 12.0, 12.0, 12.0, 12.0, 12.0, 12....
    1  Statistics  [43.0, 43.0, 43.0, 43.0, 43.0, 43.0, 43.0, 43....
    """
    group_by_section_df = (
        structure_df.groupby("SheetName",
                                sort=False).get_group(sheet).groupby("SectionName", sort=False)["ExcelRow"]
        .apply(list).reset_index(name="ExcelRows"))

    logger.debug(f"sections in sheet = {sheet}")
    logger.debug(group_by_section_df)

    section_dfs = []

    for i, row in group_by_section_df.iterrows():

        section = row["SectionName"]

        """
        if i > 1:
            break
        """

        logger.debug(f"getting data for sheet={sheet}, section={section}, "
                    f"report_date={report_date}")
        section_data_df = get_data(report_date, sheet, section)
        logger.debug(section_data_df)
        logger.debug(f"sheet={sheet}, section={section}, has {len(section_data_df.index)} rows")

        section_data_df = drop_rows(section_data_df, "HideRow")

        if section in ["MTD External Rooms Occupancy % (Market Segments)", "Key Data F&B"]:
            # rename column SegmentName to Section Name
            section_data_df.rename(columns={'SegmentName': section}, inplace=True)
        else:
            section_data_df = drop_cols(structure_df, section_data_df, sheet, "HideColumn")
            section_data_df = replace_excel_column_names(structure_df, group_by_section_df,
                                                            section_data_df, sheet, section)

        logger.debug(f"after column name replacing, here is data")
        logger.debug(section_data_df)

        section_dfs.append(section_data_df)

    return section_dfs


def get_sheets_data(structure_df: pd.DataFrame, report_date: datetime.datetime) -> dict:
    """
    Get all sheet daa

    @param structure_df - the structure dataframe
    @param report_date - report date
    @return a dictionary of sheet data, and sheet data
    is a list of dataframes
    """
    logger.debug(f'get sheets data >>> report date = {report_date}')

    if structure_df is None:
        raise ValueError("structure_df is required")

    if report_date is None:
        raise ValueError("report_date is required")

    logger.debug('get_sheets_data: structure data')
    logger.debug(structure_df)

    sheets = (structure_df.groupby(["SheetName"],
                                   sort=False).apply(list)
              #.reset_index(name="SheetHeaders"))
              .reset_index())
    logger.debug('structure data grouped by SheetName')
    logger.debug(sheets)

    sheet_dict = {}

    for i, row in sheets.iterrows():
        sheet = row["SheetName"]

        """
        if sheet != "Summary":
            continue
        """
        
        section_dfs = get_sheet_data(structure_df, report_date, sheet)
        sheet_dict[sheet] = section_dfs

    return sheet_dict


def insert_log(command: str, run_by: str, receive_dt: str):
    """
    create new log

    @param command - the command
    @param run_by - the command issuer
    @param receive_dt - the date time when the command is received
    """
    logger.debug(f"log status when receive command >>> command={command}, run by={run_by}, receive at={receive_dt}")

    if command is None or len(command) == 0:
        raise ValueError("command is required")

    if run_by is None or len(run_by) == 0:
        raise ValueError("run_by is required")

    if receive_dt is None or len(receive_dt) == 0:
        raise ValueError("receive_dt is required")
    
    with get_connection(0) as conn:
        sql = text("""
            INSERT INTO [DRR].[dbo].[Script_Running_Status](command,run_by,receive_dt)
            VALUES (:command,:run_by,:receive_dt)
        """)
        conn.execute(sql, {'command': command,'run_by': run_by, 'receive_dt': receive_dt})
        conn.commit()


def insert_fail_log(command: str, run_by: str, receive_dt: str):
    """
    create new log and set fail status

    @param command - the command
    @param run_by - the command issuer
    @param receive_dt - the date time when the command is received
    """
    logger.debug(f"log status when receive command >>> command={command}, run by={run_by}, receive at={receive_dt}")

    if command is None or len(command) == 0:
        raise ValueError("command is required")

    if run_by is None or len(run_by) == 0:
        raise ValueError("run_by is required")

    if receive_dt is None or len(receive_dt) == 0:
        raise ValueError("receive_dt is required")
    
    with get_connection(0) as conn:
        sql = text("""
            INSERT INTO [DRR].[dbo].[Script_Running_Status](command,run_by,receive_dt,status)
            VALUES (:command,:run_by,:receive_dt,:status)
        """)
        conn.execute(sql, {'command': command,'run_by': run_by, 'receive_dt': receive_dt, 'status': 'FAIL'})
        conn.commit()


def insert_and_start_log(command: str, run_by: str, receive_dt: str, start_dt: str):
    """
    create new log with start_dt

    @param command - the command
    @param run_by - the command issuer
    @param receive_dt - the date time when the command is received
    @param start_dt - the date time when the command started
    """
    logger.debug(f"log status when receive command >>> command={command}, run by={run_by}, receive at={receive_dt}, start at={start_dt}")

    if command is None or len(command) == 0:
        raise ValueError("command is required")

    if run_by is None or len(run_by) == 0:
        raise ValueError("run_by is required")
    
    if receive_dt is None or len(receive_dt) == 0:
        raise ValueError("receive_dt is required")
    
    if start_dt is None or len(start_dt) == 0:
        raise ValueError("start_dt is required")
    
    with get_connection(0) as conn:
        sql = text("""
            INSERT INTO [DRR].[dbo].[Script_Running_Status](command,run_by,receive_dt,start_dt)
            VALUES (:command,:run_by,:receive_dt,:start_dt)
        """)
        conn.execute(sql, {'command': command,'run_by': run_by, 'receive_dt': receive_dt, 'start_dt': start_dt})
        conn.commit()


def log_status_when_start(receive_dt: str, start_dt: str):
    """
    log script running status when start command

    @param receive_dt - the date time when the command is received
    @param start_dt - the date time when the command running starts
    """
    logger.debug(f"log status when start command >>> receive at={receive_dt}, start at={start_dt}")

    if receive_dt is None or len(receive_dt) == 0:
        raise ValueError("receive_dt is required")
    
    if start_dt is None or len(start_dt) == 0:
        raise ValueError("start_dt is required")

    with get_connection(0) as conn:
        sql = text("""
            UPDATE [DRR].[dbo].[Script_Running_Status]
            SET start_dt = :start_dt
            WHERE receive_dt = :receive_dt
        """)
        conn.execute(sql, {'start_dt': start_dt, 'receive_dt': receive_dt})
        conn.commit()


def log_status_when_stop(receive_dt: str, stop_dt: str):
    """
    log script running status when command finishes running

    @param receive_dt - the date time when the command is received
    @param stop_dt - the date time when the command done executing
    """
    logger.debug(f"log status when command done >>> receive at={receive_dt}, stop at={stop_dt}")

    if receive_dt is None or len(receive_dt) == 0:
        raise ValueError("receive_dt is required")
    
    if stop_dt is None or len(stop_dt) == 0:
        raise ValueError("start_dt is required")

    with get_connection(0) as conn:
        sql = text("""
            UPDATE [DRR].[dbo].[Script_Running_Status]
            SET stop_dt = :stop_dt
            WHERE receive_dt = :receive_dt
        """)
        conn.execute(sql, {'stop_dt': stop_dt, 'receive_dt': receive_dt})
        conn.commit()


def log_status(receive_dt: str, status: str):
    """
    log script running status

    @param receive_dt - the date time when the command is received
    @param status - the status
    """
    logger.debug(f"log status >>> receive at={receive_dt}, status={status}")

    if receive_dt is None or len(receive_dt) == 0:
        raise ValueError("receive_dt is required")
    
    if status is None or len(status) == 0:
        raise ValueError("status is required")
    
    if status not in ['SUCCESS', 'FAIL']:
        raise ValueError("status must be either SUCCESS or FAIL")

    with get_connection(0) as conn:
        sql = text("""
            UPDATE [DRR].[dbo].[Script_Running_Status]
            SET status = :status
            WHERE receive_dt = :receive_dt
        """)
        conn.execute(sql, {'status': status, 'receive_dt': receive_dt})
        conn.commit()


def get_latest_running_log():
    """
    get the latest log script running status
    """
    logger.debug("get latest log running status")

    with get_connection(0) as conn:
        sql = text("""
            SELECT TOP(1) * FROM [DRR].[dbo].[Script_Running_Status]
            ORDER BY start_dt DESC
            """)
        result = conn.execute(sql)
        return pd.DataFrame(result)


def find_running_logs(receive_dt: str):
    """
    find running logs by receive_dt
    """
    logger.debug(f"find running logs by receive_dt={receive_dt}")

    with get_connection(0) as conn:
        sql = text("""
            SELECT * FROM [DRR].[dbo].[Script_Running_Status]
            WHERE receive_dt = :receive_dt
            """)
        result = conn.execute(sql, {'receive_dt': receive_dt})
        return pd.DataFrame(result)


def force_fail(timeout: int):
    """
    for the commands to have fail status if they are taking too long

    @param timeout - the timeout to set the fail status
    """
    with get_connection(0) as conn:
        sql = text("""
            UPDATE [DRR].[dbo].[Script_Running_Status]
            SET status = :status 
            WHERE start_dt IS NOT NULL AND stop_dt IS NULL 
            AND status IS NULL
            AND DATEDIFF(minute, start_dt, GETDATE()) > :timeout
            """)
        conn.execute(sql, {'status': 'FAIL', 'timeout': timeout})
        conn.commit()


def sync_data():
    """
    Sync data
    """
    with get_connection(0) as conn:
        sql = text("""
            SET NOCOUNT ON; 
            exec [DRR].[dbo].[DRR_sync_data]""")
        conn.execute(sql)
        conn.commit()
