"""
Error module is where all the custom error classes are defined.

Author: Phann Malinka
"""
class MissingEmailError(Exception):
    def __init__(self, subject, body, message):
        super().__init__(message)
        self.subject = subject
        self.body = body

class StatusFailError(Exception):
    def __init__(self, subject, body, message):
        super().__init__(message)
        self.subject = subject
        self.body = body

class ScriptBusyError(Exception):
    def __init__(self, subject, body, message):
        super().__init__(message)
        self.subject = subject
        self.body = body

class SyncDataError(Exception):
    def __init__(self, subject, body, message):
        super().__init__(message)
        self.subject = subject
        self.body = body

class DatabaseConnectionError(Exception):
    def __init__(self, message):
        super().__init__(message)

class MailConnectionError(Exception):
    def __init__(self, message):
        super().__init__(message)