"""
Get config values

Author: Phann Malinka
"""
import os
from dotenv import dotenv_values
from drr.util_config import *


def is_config_in_os() -> bool:
    """
    check if all config values are store in os environment
    """
    return os.getenv(REPORT_DIR) != None and \
        os.getenv(REPORT_NAME) != None and \
        os.getenv(LOG_DIR) != None and \
        os.getenv(REPORT_TITLE_LINE1) != None and \
        os.getenv(REPORT_TITLE_LINE2) != None and \
        os.getenv(DB_DRIVER) != None and \
        os.getenv(DB_SERVER) != None and \
        os.getenv(DB_DATABASE) != None and \
        os.getenv(DB_USERNAME) != None and \
        os.getenv(DB_PASSWORD) != None and \
        os.getenv(MAIL_SERVER) != None and \
        os.getenv(MAIL_USER) != None and \
        os.getenv(MAIL_PASSWORD) != None and \
        os.getenv(MAIL_DRR_RECIPIENTS_GROUP1) != None and \
        os.getenv(MAIL_DRR_RECIPIENTS_GROUP2) != None and \
        os.getenv(MAIL_DRR_RECIPIENTS_GROUP3) != None and \
        os.getenv(MAIL_NOTIFY_FAIL1_SUBJECT) != None and \
        os.getenv(MAIL_NOTIFY_FAIL1_BODY) != None and \
        os.getenv(MAIL_NOTIFY_FAIL2_SUBJECT) != None and \
        os.getenv(MAIL_NOTIFY_FAIL2_BODY) != None and \
        os.getenv(MAIL_NOTIFY_FAIL3_SUBJECT) != None and \
        os.getenv(MAIL_NOTIFY_FAIL3_BODY) != None and \
        os.getenv(MAIL_NOTIFY_FAIL4_SUBJECT) != None and \
        os.getenv(MAIL_NOTIFY_FAIL4_BODY) != None and \
        os.getenv(MAIL_NOTIFY_FAIL5_SUBJECT) != None and \
        os.getenv(MAIL_NOTIFY_FAIL5_RECIPIENTS) != None and \
        os.getenv(MAIL_NOTIFY_FAIL_RECIPIENTS) != None and \
        os.getenv(MAIL_NOTIFY_SUCCESS_SUBJECT) != None and \
        os.getenv(MAIL_NOTIFY_SUCCESS_RECIPIENTS) != None and \
        os.getenv(MAIL_NOTIFY_FAIL6_SUBJECT) != None and \
        os.getenv(MAIL_NOTIFY_FAIL6_BODY) != None and \
        os.getenv(MAIL_NOTIFY_FAIL6_RECIPIENTS) != None and \
        os.getenv(SSC_SENDER) != None and \
        os.getenv(SSC_SUBJECT) != None and \
        os.getenv(SSC_SEARCH) != None and \
        os.getenv(COMMAND_ISSUERS) != None and \
        os.getenv(CLEAR_TIMEOUT) != None and \
        os.getenv(CMD_RUN_EVERY) != None and \
        os.getenv(REPORT_RUN_AT) != None


def get() -> dict:
    """
    get all config values from the system.
    if not exists, get from .env file

    """

    # initialize all config values to empty
    config = {
        REPORT_DIR: '',
        REPORT_NAME: '',
        LOG_DIR: '',
        REPORT_TITLE_LINE1: '',
        REPORT_TITLE_LINE2: '',
        DB_DRIVER: '',
        DB_SERVER: '',
        DB_DATABASE: '',
        DB_USERNAME: '',
        DB_PASSWORD: '',
        MAIL_SERVER: '',
        MAIL_USER: '',
        MAIL_PASSWORD: '',
        MAIL_DRR_RECIPIENTS_GROUP1: '',
        MAIL_DRR_RECIPIENTS_GROUP2: '',
        MAIL_DRR_RECIPIENTS_GROUP3: '',
        MAIL_NOTIFY_FAIL1_SUBJECT: '',
        MAIL_NOTIFY_FAIL1_BODY: '',
        MAIL_NOTIFY_FAIL2_SUBJECT: '',
        MAIL_NOTIFY_FAIL2_BODY: '',
        MAIL_NOTIFY_FAIL3_SUBJECT: '',
        MAIL_NOTIFY_FAIL3_BODY: '',
        MAIL_NOTIFY_FAIL4_SUBJECT: '',
        MAIL_NOTIFY_FAIL4_BODY: '',
        MAIL_NOTIFY_FAIL5_SUBJECT: '',
        MAIL_NOTIFY_FAIL5_RECIPIENTS: '',
        MAIL_NOTIFY_FAIL_RECIPIENTS: '',
        MAIL_NOTIFY_SUCCESS_SUBJECT: '',
        MAIL_NOTIFY_SUCCESS_RECIPIENTS: '',
        MAIL_NOTIFY_FAIL6_SUBJECT: '',
        MAIL_NOTIFY_FAIL6_BODY: '',
        MAIL_NOTIFY_FAIL6_RECIPIENTS: '',
        SSC_SENDER: '',
        SSC_SUBJECT: '',
        SSC_SEARCH: '',
        COMMAND_ISSUERS: '',
        CLEAR_TIMEOUT: '',
        CMD_RUN_EVERY: '',
        REPORT_RUN_AT: ''
    }

    # try to get the config values from os first
    if is_config_in_os():
        config = {
            REPORT_DIR: os.getenv(REPORT_DIR),
            REPORT_NAME: os.getenv(REPORT_NAME),
            LOG_DIR: os.getenv(LOG_DIR),
            REPORT_TITLE_LINE1: os.getenv(REPORT_TITLE_LINE1),
            REPORT_TITLE_LINE2: os.getenv(REPORT_TITLE_LINE2),
            DB_DRIVER: os.getenv(DB_DRIVER),
            DB_SERVER: os.getenv(DB_SERVER),
            DB_DATABASE: os.getenv(DB_DATABASE),
            DB_USERNAME: os.getenv(DB_USERNAME),
            DB_PASSWORD: os.getenv(DB_PASSWORD),
            MAIL_SERVER: os.getenv(MAIL_SERVER),
            MAIL_USER: os.getenv(MAIL_USER),
            MAIL_PASSWORD: os.getenv(MAIL_PASSWORD),
            MAIL_DRR_RECIPIENTS_GROUP1: os.getenv(MAIL_DRR_RECIPIENTS_GROUP1),
            MAIL_DRR_RECIPIENTS_GROUP2: os.getenv(MAIL_DRR_RECIPIENTS_GROUP2),
            MAIL_DRR_RECIPIENTS_GROUP3: os.getenv(MAIL_DRR_RECIPIENTS_GROUP3),
            MAIL_NOTIFY_FAIL1_SUBJECT: os.getenv(MAIL_NOTIFY_FAIL1_SUBJECT),
            MAIL_NOTIFY_FAIL1_BODY: os.getenv(MAIL_NOTIFY_FAIL1_BODY),
            MAIL_NOTIFY_FAIL2_SUBJECT: os.getenv(MAIL_NOTIFY_FAIL2_SUBJECT),
            MAIL_NOTIFY_FAIL2_BODY: os.getenv(MAIL_NOTIFY_FAIL2_BODY),
            MAIL_NOTIFY_FAIL3_SUBJECT: os.getenv(MAIL_NOTIFY_FAIL3_SUBJECT),
            MAIL_NOTIFY_FAIL3_BODY: os.getenv(MAIL_NOTIFY_FAIL3_BODY),
            MAIL_NOTIFY_FAIL4_SUBJECT: os.getenv(MAIL_NOTIFY_FAIL4_SUBJECT),
            MAIL_NOTIFY_FAIL4_BODY: os.getenv(MAIL_NOTIFY_FAIL4_BODY),
            MAIL_NOTIFY_FAIL5_SUBJECT: os.getenv(MAIL_NOTIFY_FAIL5_SUBJECT),
            MAIL_NOTIFY_FAIL5_RECIPIENTS: os.getenv(MAIL_NOTIFY_FAIL5_RECIPIENTS),
            MAIL_NOTIFY_FAIL_RECIPIENTS: os.getenv(MAIL_NOTIFY_FAIL_RECIPIENTS),
            MAIL_NOTIFY_SUCCESS_SUBJECT: os.getenv(MAIL_NOTIFY_SUCCESS_SUBJECT),
            MAIL_NOTIFY_SUCCESS_RECIPIENTS: os.getenv(MAIL_NOTIFY_SUCCESS_RECIPIENTS),
            MAIL_NOTIFY_FAIL6_SUBJECT: os.getenv(MAIL_NOTIFY_FAIL6_SUBJECT),
            MAIL_NOTIFY_FAIL6_BODY: os.getenv(MAIL_NOTIFY_FAIL6_BODY),
            MAIL_NOTIFY_FAIL6_RECIPIENTS: os.getenv(MAIL_NOTIFY_FAIL6_RECIPIENTS),
            SSC_SENDER: os.getenv(SSC_SENDER),
            SSC_SUBJECT: os.getenv(SSC_SUBJECT),
            SSC_SEARCH: os.getenv(SSC_SEARCH),
            COMMAND_ISSUERS: os.getenv(COMMAND_ISSUERS),
            CLEAR_TIMEOUT: os.getenv(CLEAR_TIMEOUT),
            CMD_RUN_EVERY: os.getenv(CMD_RUN_EVERY),
            REPORT_RUN_AT: os.getenv(REPORT_RUN_AT),
        }
        return config
    
    # os has no config values, so now let get them from .env file
    if os.path.isfile(".env"):
        return dotenv_values(".env")
    
    return config
