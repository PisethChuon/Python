"""
Utility module is the helper providing the utility functions.

Author: Phann Malinka
"""
import pandas as pd
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
import enum
from drr.my_logger import logger


border_color = "000000"
border_size_2 = 0.25
border_size_1 = 0.07
even_row_background_color1 = "F2F2F2"
even_row_background_color2 = "CCFFFF"
highlight_background_color1 = "DEDEDE"
highlight_background_color2 = "00CCFF"
highlight_background_color3 = "C0C0C0"
white_color = "FFFFFF"
pdf_header_row_height = 0.2 * inch
report_header_font_size = 13.0
pdf_font_size = 6.7
html_font_name = "Calibri"
html_font_size = 15

"""
excel_row_height is in point
pdf_summary_row_height is in inch

row height:
72 point = 1 inch
so 15 points = 17/72 = 0.236 inch
"""
excel_row_height = 17
pdf_data_row_height = 0.169 * inch


"""
Keys of dictionary
"""
ROOMS_INTERNAL = "rooms_internal"
ROOMS_EXTERNAL = "rooms_external"
ROOMS_TOTAL = "rooms_total"
FB_REVENUE = "fb_revenue"
OTHERS_REVENUE = "others_revenue"
TOTAL_HOTEL_REVENUE = "total_hotel_revenue"
OCCUPANCY_EXTERNAL = "occupancy_external"
INTERNAL_ROOMS = "internal_rooms"
SLEEPER_DENSITY = "sleeper_density"
AVERAGE_ROOM_RATE_EXTERNAL = "average_room_rate_external"
HOUSE_USE_ROOMS = "house_use_rooms"
ROOM_ARRIVALS = "room_arrivals"
ROOM_YIELD = "room_yield"


"""
Columns formatted as percentage
"""
PERCENTAGE_COLUMNS = [
    "MTD Budget ('000s) Var.",
    "YTD Budget ('000s) Var.",
    "Last Year ('000s) MTD Var.",
    "Last Year ('000s) YTD Var.",
    "MTD Budget Var.",
    "YTD Budget Var.",
    "Last Year MTD Var.",
    "Last Year YTD Var."]


""""
global style
"""
sample_styles = getSampleStyleSheet()

style_header = ParagraphStyle(
    name="Style Header",
    parent=sample_styles["Normal"],
    alignment=TA_CENTER,
    fontSize=pdf_font_size
)

style_data = ParagraphStyle(
    name="Style Data",
    parent=sample_styles["Normal"],
    alignment=TA_RIGHT,
    fontSize=pdf_font_size
)

style_data_percentage = ParagraphStyle(
    name="Style Data",
    parent=sample_styles["Normal"],
    alignment=TA_CENTER,
    fontSize=pdf_font_size
)

style_row_name = ParagraphStyle(
    name="Style Row Name",
    parent=sample_styles["Normal"],
    alignment=TA_LEFT,
    fontSize=pdf_font_size
)

style_section = ParagraphStyle(
    name="Style Header",
    parent=sample_styles["Normal"],
    alignment=TA_CENTER,
    fontSize=pdf_font_size
)

class ScriptStatusEnum(enum.Enum):
    FAIL = 1
    SUCCESS = 2


SCHEDULER_NAME = "the scheduler"

DB_DT_FORMAT = '%Y-%m-%d %H:%M:%S'

COMMAND_LISTENER_RUN = "Command Listener Run"
COMMAND_LISTENER_CLEAR = "Command Listener Clear"

SQLITE_FILE = "status.db"

def drop_rows(data_df: pd.DataFrame, col: str) -> pd.DataFrame:
    """
    Drop those rows of which col is True
    In data_df, there are rows need to be deleted.

    @param data_df - a data frame
    @param col - a column name to look for
    @return a data frame where all matched rows are deleted
    """
    logger.debug(f"drop rows >>> where {col} is True")

    if data_df is None:
        raise ValueError("data_df is required")

    if col is None or len(col) == 0:
        raise ValueError("col is required")

    if col in data_df:
        logger.debug(data_df.loc[(data_df[col] == 1)])
        data_df.drop(data_df[data_df[col] == 1].index, inplace=True)

    return data_df


def drop_cols(structure_df: pd.DataFrame, data_df: pd.DataFrame, sheet: str, col: str) -> pd.DataFrame:
    """
    Drop those columns of which col is True
    There is no such col in data_df, that's why we need to cross-reference with the structure_df.

    There are two column types to drop
    1. Any column that is not to be shown in the report such as SheetName, ExcelRow, HideRow
    2. Any column that has HideColumn = True
    """
    logger.debug(f"drop columns >>> either because {col} is True or those columns are excluded in the result")

    if structure_df is None:
        raise ValueError("structure_df is required")

    if data_df is None:
        raise ValueError("data_df is required")

    if col is None or len(col) == 0:
        raise ValueError("col is required")

    cols_to_drop = ["SheetName", "SectionName", "ExcelRow", "HideRow"]
    columns = data_df.columns.tolist()
    for i, col in enumerate(columns):
        """
        skip first column because it is a section name
        """
        if i == 0:
            continue

        to_delete_founds = structure_df.loc[(structure_df["SheetName"] == sheet)
                                            & (structure_df["ExcelColumn"] == col)
                                            & (structure_df["HideColumn"] == 1)]
        if len(to_delete_founds) > 0:
            logger.debug("drop_cols: found columns to drop")
            logger.debug(to_delete_founds)
            cols_to_drop.append(col)

    if len(cols_to_drop) > 0:
        for i, c in enumerate(cols_to_drop):
            if c in columns:
                columns.remove(c)
                logger.debug(f"drop_cols: column = {c} is removed")

        data_df.drop(cols_to_drop, axis=1, inplace=True)
        data_df.columns = columns

    return data_df


def replace_excel_column_names(structure_df: pd.DataFrame, group_by_section_df: pd.DataFrame,
                               data_df: pd.DataFrame, sheet: str, section: str) -> pd.DataFrame:
    """
    Replace excel column name with the correct column name

    @param structure_df - the structure dataframe
    @param group_by_section_df - structure dataframe grouped by section of a particular sheet
    @param data_df - data dataframe
    @param sheet - sheet to work on
    @param section - section to work on
    @return an updated dataframe
    """
    logger.debug(f"replace column names >>> sheet={sheet}, section={section}")

    if structure_df is None:
        raise ValueError("structure_df is required")

    if group_by_section_df is None:
        raise ValueError("group_by_section_df is required")

    if data_df is None:
        raise ValueError("data_df is required")

    if sheet is None or len(sheet) == 0:
        raise ValueError("sheet is required")

    if section is None or len(section) == 0:
        raise ValueError("section is required")

    columns = data_df.columns.tolist()
    logger.debug(f"original columns before rename: {columns}")

    for i, col in enumerate(columns):
        # find the correct Excel row
        found_excel_rows = group_by_section_df.loc[(group_by_section_df["SectionName"] == section)]
        if len(found_excel_rows.index) == 0:
            raise ValueError(f"there is no section = {section} in sheet = {sheet}")

        logger.debug(f"structure dataframe grouped by section = {section}")
        logger.debug(found_excel_rows)

        """
        found_excel_rows looks like this:

        SectionName   ExcelRows
        --------------------------
        Revenue       [12, 13, 14]

        The purpose is to get 12
        """
        excel_rows = found_excel_rows.iloc[0]["ExcelRows"]
        if len(excel_rows) == 0:
            raise ValueError(f"there is no excel rows for section = {section}")

        excel_row = excel_rows[0]

        """
        data looks like this:

        SheetName     RowName        ExcelRow     B   C    D
        ------------------------------------------------------
        Summary       Rooms(Total)   12          100  100  100

        We need to replace B C D with the real column names

        B = Actual Today N1
        C = Actual Today N2
        D = Actual Today Total
        """

        col_founds = structure_df.loc[(structure_df["SheetName"] == sheet)
                                      & (structure_df["SectionName"] == section)
                                      & (structure_df["ExcelColumn"] == col) & (
                                              structure_df["ExcelRow"] == excel_row)]
        logger.debug(f"look up columns that has SheetName = {sheet}, SectionName = "
                     f"{section}, ExcelColumn = {col}, ExcelRow = {excel_row}")
        logger.debug(col_founds)
        if len(col_founds.index) == 0:
            continue

        new_col = col_founds.iloc[0]["ColumnName"]

        if new_col != col:
            logger.debug(f"column = {col} is changed to {new_col}")
            columns[i] = new_col

    data_df.columns = columns

    """
    rename column RowName to its section name
    """
    data_df.rename(columns={'RowName': section}, inplace=True)

    return data_df


def get_special_rows(section_df: pd.DataFrame):
    """
    Get the particular row numbers

    @param section_df - a dataframe
    """
    special_row = {
        ROOMS_INTERNAL: -1,
        ROOMS_EXTERNAL: -1,
        ROOMS_TOTAL: -1,
        FB_REVENUE: -1,
        OTHERS_REVENUE: -1,
        TOTAL_HOTEL_REVENUE: -1,
        OCCUPANCY_EXTERNAL: -1,
        HOUSE_USE_ROOMS: -1,
        SLEEPER_DENSITY: -1,
        AVERAGE_ROOM_RATE_EXTERNAL: -1,
        ROOM_YIELD: -1,
        ROOM_ARRIVALS: -1
    }

    k = 0
    for r, row in section_df.iterrows():
        for c, col in enumerate(section_df.columns):
            if c == 0:
                match row[col]:
                    case "Rooms (Internal)":
                        special_row[ROOMS_INTERNAL] = k
                    case "Rooms (External)":
                        special_row[ROOMS_EXTERNAL] = k
                    case "Rooms (Total)":
                        special_row[ROOMS_TOTAL] = k
                    case "F&B Revenue":
                        special_row[FB_REVENUE] = k
                    case "Others Revenue":
                        special_row[OTHERS_REVENUE] = k
                    case "TOTAL HOTEL REVENUE":
                        special_row[TOTAL_HOTEL_REVENUE] = k
                    case "Occupancy % (External)":
                        special_row[OCCUPANCY_EXTERNAL] = k
                    case "House Use Rooms":
                        special_row[HOUSE_USE_ROOMS] = k
                    case "Sleeper Density":
                        special_row[SLEEPER_DENSITY] = k
                    case "Average Room Rate (External)":
                        special_row[AVERAGE_ROOM_RATE_EXTERNAL] = k
                    case "Room Yield (External Revenues/Physical Rooms)":
                        special_row[ROOM_YIELD] = k
                    case "Room Arrivals":
                        special_row[ROOM_ARRIVALS] = k
                break
        k = k + 1
    return special_row


def get_row_number(worksheet, row_name: str):
    """
    find row number of a row name
    """
    found_row = 0
    for r, row in enumerate(worksheet.iter_rows()):
        r = r + 1
        if row[0].value == row_name:
            found_row = r
            break
    return found_row


def read_recipients(recipient_str: str) -> list:
    """
    Read mail_tocc string and return a list

    How to read mail recipient string?

    a,b,c!d,e,f!x|g,h!i,j!y

    This means:

    1- there are two groups of recipients; they are separated by |
    2- a, b, c are TO; d e, f are CC; x is BCC in group1
    3- g, h are TO; i, j are CC; y is BCC in group2

    TO is mandatory but CC and BCC are not.

    @param recipient_str - the recipient string
    @return a list of groups of recipients
    """

    if recipient_str is None or len(recipient_str) == 0:
        raise ValueError("recipient_str is required")
    
    mail_tocc = recipient_str.split("|")

    recipients = []
    for g in mail_tocc:
        splitted_group = g.split("!")
        if len(splitted_group) == 0:
            raise ValueError("recipient string is invalid in config file")
        to = splitted_group[0]
        if to == "":
            raise ValueError("TO is missing in config file")
        cc = None
        bcc = None
        if len(splitted_group) >= 2:
            cc = splitted_group[1]
        if len(splitted_group) >= 3:
            bcc = splitted_group[2]
        group = {
            "to": to.split(","),
            "cc": cc.split(",") if cc != None else None,
            "bcc": bcc.split(",") if bcc != None else None
        }
        recipients.append(group)

    return recipients
