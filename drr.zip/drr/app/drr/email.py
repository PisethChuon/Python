"""
Email module is to take care of sending and searching for emails.

Author: Phann Malinka
"""
import logging
import time
from drr.error import MailConnectionError
from drr.my_logger import logger
from drr import config_reader
from exchangelib import DELEGATE, Account, Credentials, Configuration, EWSDateTime, Message, HTMLBody, \
    FileAttachment
from datetime import datetime
from drr.html import print_html
from drr.util_config import *


config = config_reader.get()

def get_email_account(retry: int) -> Account:
    """
    Get email account

    @param retry - number of retries
    @return email account
    """
    logger.debug("get email account")

    try:
        credentials = Credentials(
            username=config[MAIL_USER],
            password=config[MAIL_PASSWORD]
        )
        mail_config = Configuration(server=config[MAIL_SERVER], credentials=credentials)
        email_account = Account(
            primary_smtp_address=config[MAIL_USER],
            config=mail_config,
            autodiscover=False,
            access_type=DELEGATE
        )
        logger.debug("retrieved email account")
        logger.debug(email_account)

        return email_account
    except Exception as e:
        logger.error(str(e))
        if retry == 0:
            logger.error(f"=== MAIL CONNECTION INFO ===")
            logger.error(f"server: {config[MAIL_SERVER]}")
            logger.error(f"username: {config[MAIL_USER]}")
        logger.error(e)
        retry = retry + 1
        if (retry <= int(config[CONNECTION_RETRY])):
            logger.error(f"sleep for {config[RETRY_INTERVAL]} seconds")
            time.sleep(int(config[RETRY_INTERVAL]))
            logger.error(f"mail connection retry: {retry}")
            return get_email_account(retry)
        else:
            raise MailConnectionError(str(e))


def get_ews_datetime(email_account: Account, dt: datetime) -> EWSDateTime:
    """
    get ews datetime with the email account's default timezone
    start_hour is the start hour of the day

    @param email_account - email account
    @return ews datetime
    """
    logger.debug(f"get ews date time from the given datetime = {dt}")

    if email_account is None:
        raise ValueError("email_account is required")

    if dt is None:
        raise ValueError("dt is required")

    tz = email_account.default_timezone
    since = EWSDateTime.from_datetime(dt).astimezone(tz)

    logger.debug(f"ews datetime = {since}")

    return since


def search_emails_by_subject(email_account, subject: str, search_from: datetime, search_to: datetime):
    """
    search for emails for the particular subject

    @param email_account - the email account
    @param subject - the subject of the emails to search for
    @param search_from - search from when?
    @param search_to - search until when?
    @return a list of emails
    """
    logger.debug(f"search_emails_by_subject: search emails with the following params: subject={subject}, "
                f"search from={search_from}, search to={search_to}")

    if email_account is None:
        raise ValueError("email_account is required")

    if subject is None or len(subject) == 0:
        raise ValueError("subject is required")

    if search_from is None:
        raise ValueError("sent_from is required")
    
    if search_to is None:
        raise ValueError("sent_to is required")
    
    emails = (email_account.inbox
              .filter(datetime_received__gte=get_ews_datetime(email_account, search_from),
                      datetime_received__lte=get_ews_datetime(email_account, search_to),
                      subject__icontains=subject)
              # sort in desc order
              .order_by('-datetime_received'))
    return emails


def search_unread_emails_by_subject(email_account, subject: str, search_from: datetime, search_to: datetime):
    """
    search for unread emails for the particular subject

    @param email_account - the email account
    @param subject - the subject of the emails to search for
    @param search_from - search from when?
    @param search_to - search until when?
    @return a list of emails
    """
    logger.debug(f"search_unread_emails_by_subject: search emails with the following params: subject={subject}, "
                f"search from={search_from}, search to={search_to}")

    if email_account is None:
        raise ValueError("email_account is required")

    if subject is None or len(subject) == 0:
        raise ValueError("subject is required")

    if search_from is None:
        raise ValueError("sent_from is required")
    
    if search_to is None:
        raise ValueError("sent_to is required")
    
    emails = (email_account.inbox
              .filter(datetime_received__gte=get_ews_datetime(email_account, search_from),
                      datetime_received__lte=get_ews_datetime(email_account, search_to),
                      subject__icontains=subject,
                      is_read=False)
              # sort in desc order
              .order_by('-datetime_received'))
    return emails


def search_emails_by_subject_sender(email_account, subject: str, sender: str, search_from: datetime, search_to: datetime):
    """
    search for emails by the particular subject and sender

    @param email_account - the email account
    @param subject - the subject of the emails to search for
    @param sender - sent from whom?
    @param search_from - search from when?
    @param search_to - search until when?
    @return a list of emails
    """
    logger.debug(f"search_emails: search emails with the following params: subject={subject}, "
                f"sender={sender}, search from={search_from}, search to={search_to}")

    if email_account is None:
        raise ValueError("email_account is required")

    if subject is None or len(subject) == 0:
        raise ValueError("subject is required")

    if sender is None or len(sender) == 0:
        raise ValueError("sender is required")

    if search_from is None:
        raise ValueError("sent_from is required")
    
    if search_to is None:
        raise ValueError("sent_to is required")
    
    """
    How to filter emails?
    
    1. emails that came in by datetime = dt
    2. emails that has the subject we want
    3. emails that were sent from a particular sender
    
    Only first and second conditions can be put together. The 3rd condition 
    is to be manually processed outside of this function.
    """
    emails = (email_account.inbox
              .filter(datetime_received__gte=get_ews_datetime(email_account, search_from),
                      datetime_received__lte=get_ews_datetime(email_account, search_to),
                      subject__icontains=subject)
              # sort in desc order
              .order_by('-datetime_received'))
    filter_by_sender = [e for e in emails if e.sender == sender]

    return filter_by_sender


def send_email(email_account: Account, subject: str, to_recipients: list, body: str,
               cc_recipients: list = None, bcc_recipients: list = None, attachments: list = None):
    """
    send an email

    @param email_account - the email account
    @param subject - the subject of the email
    @param to_recipients - to
    @param cc_recipients - cc
    @param bcc_recipients - bcc
    @param body - the body of the email without header and footer
    @param attachments - the attachments
    """
    logger.debug(f"send email with the following params: subject={subject}, "
                f"to={to_recipients}, cc={cc_recipients}, bcc={bcc_recipients}, body=hidden, "
                f"attachments={len(attachments) if attachments is not None else '0'}")

    if email_account is None:
        raise ValueError("email_account is required")

    if subject is None or len(subject) == 0:
        raise ValueError("subject is required")

    if to_recipients is None or len(to_recipients) == 0:
        raise ValueError("to_recipients must not be empty")

    body_html = HTMLBody(
        f"<html><head>"
        f"<meta name='viewport' content='width=device-width, initial-scale=1'>"
        f"<style>body{{font-family: Calibri}}</style>"
        f"</head>"
        f"<body>{body}</body>"
        f"</html>") if body is not None else None

    if logger.level == logging.DEBUG and body_html is not None:
        print_html(body_html)

    email = Message(
        account=email_account,
        subject=subject,
        body=body_html,
        to_recipients=to_recipients,
        cc_recipients=cc_recipients,
        bcc_recipients=bcc_recipients
    )

    for attachment_name, attachment_content in attachments or []:
        logger.debug(f"attach file = {attachment_name} to email")
        file = FileAttachment(name=attachment_name, content=attachment_content)
        email.attach(file)

    status = email.send_and_save()
    logger.debug(f"{'email is sent' if status is True else 'email is not sent'}")
    return status
