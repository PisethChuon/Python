# Software Design Document

This is the software design document for the report automation script. 

This report automation script is to be called as DRR script from this point onwards.

## Revision History

| Revision  | Date       | Author        |  Description  |
|-----------|------------|---------------|---------------|
| 1.0       | 27/12/2023 | Phann Malinka |  Creation     |
| 2.0       | 11/07/2023 | Phann Malinka |  Update       |
| 3.0       | 11/07/2024 | Phann Malinka |  Update       |


## Table of Content
| Section                                                                                 | 
|-----------------------------------------------------------------------------------------|
| [1 Requirements](#1-requirements)                                                       |
| [1.1 Detailed Requirements](#11-detailed-requirements)                                  |
| [1.1.1 command listener fail](#111-command-listener-fail)                               |
| [1.1.2 clear long-running commands](#112-clear-long-running-commands)                   |
| [1.1.3 listen for new command](#113-listen-for-new-command)                             |
| [1.1.3.1 command already handled](#1131-command-already-handled)                        |
| [1.1.4 generate and send the report](#114-generate-and-send-the-report)                 |
| [1.1.4.1 check if the script is busy](#1141-check-if-the-script-is-busy)                |
| [1.1.4.2 search emails from SSC](#1142-search-emails-from-ssc)                          |
| [1.1.4.3 sync data](#1143-sync-data)                                                    |
| [1.1.4.4 generate the report files](#1144-generate-the-report-files)                    |
| [1.1.4.5 email the report](#1145-email-the-report)                                      |
| [1.1.4.5.1 email the report for group1](#11451-email-the-report-for-group1)             |
| [1.1.4.5.2 email the report for group2](#11452-email-the-report-for-group2)             |
| [1.1.4.5.3 email the report for group3](#11453-email-the-report-for-group3)             |
| [1.1.4.5.4 email drr success](#11454-email-drr-success)                                 |
| [2 Architecture Design](#2-architecture-design)                                         |
| [3 Detail Design](#3-detail-design)                                                     |
| [3.1 Database Design](#31-database-design)                                              |
| [3.1.1 NGG_A_SALFLDG Table Design ([dbo].[NGG_A_SALFLDG])](#311-ngg_a_salfldg-table-design-dbongg_a_salfldg) |
| [3.1.2 NGG_A_ACNT_ANL_CAT Table Design ([dbo].[NGG_A_ACNT_ANL_CAT])](#312-ngg_a_acnt_anl_cat-table-design-dbongg_a_acnt_anl_cat) |
| [3.1.3 NGG_B_SALFLDG Table Design ([dbo].[NGG_B_SALFLDG])](#313-ngg_b_salfldg-table-design-dbongg_b_salfldg)  |
| [3.1.4 Config Table Design ([dbo].[Config])](#314-config-table-design-dboconfig) |
| [3.1.5 Script Running Status Table Design ([dbo].[Script_Running_Status])](#315-script-running-status-table-design-dboscript_running_status) |
| [3.1.6 Summary Raw Table Design ([Staging].[Summary_raw])](#316-summary-raw-table-design-stagingsummary_raw) |
| [3.1.7 Summary Table Design ([Staging].[Summary])](#317-summary-table-design-stagingsummary)                 |
| [3.1.8 Summary Revenue Result Table Design ([Staging].[Summary_Revenue_Result])](#318-summary-revenue-result-table-design-stagingsummary_revenue_result) |
| [3.1.9 Detail Room Raw Table Design ([Staging].[Detail_Room_raw])](#319-detail-room-raw-table-design-stagingdetail_room_raw) |
| [3.1.10 Detail Room Table Design ([Staging].[Detail_Room])](#3110-detail-room-table-design-stagingdetail_room) |
| [3.1.11 Detail F&B Raw Table Design ([Staging].[Detail_FB_raw])](#3111-detail-fb-raw-table-design-stagingdetail_fb_raw) |
| [3.1.12 Detail F&B Table Design ([Staging].[Detail_FB])](#3112-detail-fb-table-design-stagingdetail_fb) |
| [3.1.13 Executive Summary MTD Table Design ([Staging].[Executive_Summary_MTD])](#3113-executive-summary-mtd-table-design-stagingexecutive_summary_mtd) |
| [3.1.14 Executive Summary Key Data Table Design ([Staging].[Executive_Summary_KeyData])](#3114-executive-summary-key-data-table-design-stagingexecutive_summary_keydata) |
| [3.1.15 Get Report Procedure Design ([dbo].[GetReport])](#3115-get-report-procedure-design-dbogetreport) |
| [3.1.16 Sync Data Procedure Design ([dbo].[Drr_sync_data])](#3116-sync-data-procedure-design-dbodrr_sync_data) |
| [3.2 Configuration](#32-configuration) |
| [3.3 Config Reader Module (``config_reader.py``)](#33-config-reader-module-config_readerpy) |
| [3.4 My Logger Module (``my_logger.py``)](#34-my-logger-module-my_loggerpy) |
| [3.5 Util Module (``util.py``)](#35-util-module-utilpy) |
| [3.6 Util Config Module (``util_config.py``)](#36-util-config-module-util_configpy) |
| [3.7 Error Module (``error.py``)](#37-error-module-errorpy) |
| [3.8 DB Module (``db.py``)](#38-db-module-dbpy) |
| [3.9 Email Module (``email.py``)](#39-email-module-emailpy) |
| [3.10 Excel Module (``excel.py``)](#310-excel-module-excelpy) |
| [3.11 PDF Module (``pdf.py``)](#311-pdf-module-pdfpy) |
| [3.12 HTML Module (``html.py``)](#312-html-module-htmlpy) |
| [3.13 Command Listener Module (``command_listener.py``)](#313-command-listener-module-command_listenerpy) |
| [3.14 Report Module (``report.py``)](#314-report-module-reportpy) |
| [4 Deployment Design](#4-deployment-design) |
| [4.1 Airflow's DAG file](#41-airflows-dag-file) |

## 1 Requirements

| id | Description                                                     |
|----|-----------------------------------------------------------------|
| 1  | generate and send the report on daily basis                     |
| 2  | execute the DRR script through the command sent through email   |


### 1.1 Detailed Requirements

![use-cases](use-cases.svg)

### The 7 actors

| Actors                       | Roles                                         | Email Addresses                                                                   |
|------------------------------|-----------------------------------------------|-----------------------------------------------------------------------------------|
| Scheduler                    | The script needs to run on a daily basis       |                                                                                   |
| Programming Team             | The selected people in the Programming Team   | rajajeganramesh@nagaworld.com,YimSamaune@nagaworld.com,phannmalinka@nagaworld.com |
| Finance Team                 | The people in the Finance Team                | vannydavyneth@nagaworld.com,naryukyden@nagaworld.com,sandrafernandes@nagaworld.com,<br/>alvinsow@nagaworld.com |
| IT Service Desk Team         | Everyone in IT Service Desk Team              | chanthathora@nagaworld.com,chhemkimchhorn@nagaworld.com,deabdavy@nagaworld.com,<br/>hengmengthong@nagaworld.com,lychhay@nagaworld.com,mokchanda@nagaworld.com,<br/>phalchamraeun@nagaworld.com,rethdaparrot@nagaworld.com,rolayheng@nagaworld.com,<br/>sangsovireak@nagaworld.com,sengchanchetra@nagaworld.com,sonraksa@nagaworld.com,<br/>suyvannsis@nagaworld.com,thaingsovanrith@nagaworld.com,torngtepy@nagaworld.com,<br/>yeanseyha@nagaworld.com,yoeunsovandara@nagaworld.com,douchsamey@nagaworld.com,<br/>lengsopheak@nagaworld.com,nemsaody@nagaworld.com,promseyla@nagaworld.com,<br/>hophoyming@nagaworld.com,meangpheany@nagaworld.com,itservicedesk@nagaworld.com |
| Hotel IT Support Team        | Everyone in Hotel IT Support Team             | hotel-it-support@nagaworld.com |
| HOD Team                     | The selected HODs                             | irenekoh@nagaworld.com,nousavuth@nagaworld.com,suysophy@nagaworld.com,<br/>kheamrachny@nagaworld.com,davidthomas@nagaworld.com,edmundpak@nagaworld.com,<br/>michelletham@nagaworld.com,ongjorenmariscotes@nagaworld.com,christopher@nagaworld.com,<br/>rogerperez@nagaworld.com,rornsophea@nagaworld.com,sandrafernandes@nagaworld.com,<br/>sopheaseang@nagaworld.com,hengcheatun@nagaworld.com,nuonvisal@nagaworld.com,<br/>alvinsow@nagaworld.com,vannydavyneth@nagaworld.com,limjithuiterence@nagaworld.com,<br/>naryukyden@nagaworld.com |
| Top Management Team          | The Top Meanagement people                    |

### 1.1.1 command listener fail

This is about handling the situation when the command listener fails to do its job.

It will send a notification email to the following teams.

- [Programming Team](#the-7-actors)

### 1.1.2 clear long-running commands
  
This is about clearing those commands that were taking too long to finish. 
The scheduler interacts with this use-case by executing the below command.
  
```
python -m drr.command_listener clear
```

If something wrong happens there, the [command listener fail](#111-command-listener-fail) user-case is to be invoked.

### 1.1.3 listen for new command

This is about listening to any new command given through email. 
The scheduler interacts with this use-case by executing the below command.

```
python -m drr.command_listener run
```

If something wrong happens there, the [command listener fail](#111-command-listener-fail) use-case is to be invoked.

If the command was already handled before, the [command already handled](#1131-command-already-handled) use-case is to be invoked.
  
If a new command is found in the inbox and is sent from the authorized email address, the [generate and send the report](#113-generate-and-send-the-report) use-case is to be invoked.

### 1.1.3.1 command already handled

This is about handle the already-handled command. The log is to be written in this case. No need to send any notification email.

### 1.1.4 generate and send the report

This is about generating the excel file and the pdf file; and send all of them later to the relevent people.
The scheduler interacts with this use-case by executing the below command.

```
python -m drr.report
```
  
Here are the use-cases it needs to call in chronological order.

  1. [check if the script is busy](#3-deployment-design)
  2. [search emails from SSC](#3-deployment-design)
  3. [sync data](#3-deployment-design)
  4. [generate the report files](#3-deployment-design)
  5. [email the reports](#3-deployment-design)

### 1.1.4.1 check if the script is busy

This is about checking if the script is currently busy. Only one actor can execute the ``python -m drr.report`` at a time.
  
If the script is currently busy, the [Programming Team](#the-7-actors) is to be notified by email.

If the script is not currently busy, the [search emails from SSC](#1132-search-emails-from-ssc) use-case is to be invoked.

### 1.1.4.2 search emails from SSC

This is about searching for the 3 good-status emails from SSC. The search is to be performed from 00:00:00 till 23:59:59.
  
There are 2 fail cases.

  - one or more SSC Notification emails are missing.
  - the number of good-status emails is not 3.

If any of the above case happens, the following teams are to be notified by email.

  - [Programming Team](#the-7-actors)
  - [IT Service Desk Team](#the-7-actors)
  - [Hotel IT Support Team](#the-7-actors)
  - [Finance Team](#the-7-actors)

If none of the above case happens, that means there are 3 good-status emails from SSC.
Then the [sync data](#sync-data) use-case is to be invoked.

### 1.1.4.3 sync data
  
This is about syncing data from the portal server to the production database server for DRR project.

If something wrong happens there, the [Programming Team](#the-7-actors) is to be notified by email.

### 1.1.4.4 generate the report files

This is about generating the excel report file and pdf report file.

The data is to be fetched from the stored procedure and put in the repot file.

If something wrong happens there, the following teams are to be notified by email.

  - [Programming Team](#the-7-actors)
  - [IT Service Desk Team](#the-7-actors)
  - [Hotel IT Support Team](#the-7-actors)
  - [Finance Team](#the-7-actors)

### 1.1.4.5 email the report

This is about emailing the report to the relevant people. There are 3 separated emails need to be sent in order.

- [email the report for group1](#email-the-report-for-group1)
- [email the report for group2](#email-the-report-for-group2)
- [email the report for group3](#email-the-report-for-group3)

### 1.1.4.5.1 email the report for group1

This is about emailing the report for group1.

Group1 here refers to the following teams.

- [Programming Team](#the-7-actors)
- [Finance Team](#the-7-actors)

If something wrong happens there, the following teams are to be notified by email.

  - [Programming Team](#the-7-actors)
  - [IT Service Desk Team](#the-7-actors)
  - [Hotel IT Support Team](#the-7-actors)
  - [Finance Team](#the-7-actors)

### 1.1.4.5.2 email the report for group2

This is about emailing the report for group2.

Group2 here refers to the following teams.

- [HOD Team](#the-7-actors)

If something wrong happens there, the following teams are to be notified by email.

  - [Programming Team](#the-7-actors)
  - [IT Service Desk Team](#the-7-actors)
  - [Hotel IT Support Team](#the-7-actors)
  - [Finance Team](#the-7-actors)

### 1.1.4.5.3 email the report for group3

This is about emailing the report for group3.

Group3 here refers to the following teams.

- [Top Management Team](#the-7-actors)

If something wrong happens there, the following teams are to be notified by email.

  - [Programming Team](#the-7-actors)
  - [IT Service Desk Team](#the-7-actors)
  - [Hotel IT Support Team](#the-7-actors)
  - [Finance Team](#the-7-actors)

### 1.1.4.5.4 email drr success

This is about emailing the status success to all the following teams.

  - [Programming Team](#the-7-actors)
  - [IT Service Desk Team](#the-7-actors)
    
    Everyone except itservicedesk@nagaworld.com because every email received by ``itservicedesk@nagaworld.com`` is a new ticket that must be resolved by somoeone there.

    Since this is the success status, so there is no need to send an email to ``itservicedesk@nagaworld.com``.

  - [Hotel IT Support Team](#the-7-actors)
  - [Finance Team](#the-7-actors)

## 2 Architecture Design

![architecture](architecture.svg)

- Command Listener Module takes care of listening and clearing the command sent through email.
- Report Module takes care of generating and sending the report.
- Util Module Group is a group of utility modules such as logging, error, config reading.
- Email Module takes care of sending and searching for emails.
- Excel Module takes care of creating Excel document.
- PDF Module takes care of creating PDF document.
- HTML Module takes care of creating HTML document.
- DB Module takes care of communicating with a database server.
- Config Reader Module takes care of reading the configuration from the system or the .env file.
- My Logger Module takes care of configuring the logging.

## 3 Detail Design

### 3.1 Database Design

### 3.1.1 NGG_A_SALFLDG Table Design ([dbo].[NGG_A_SALFLDG])

This is copied from the portal server. Its data is synced from there.

### 3.1.2 NGG_A_ACNT_ANL_CAT Table Design ([dbo].[NGG_A_ACNT_ANL_CAT])

This is copied from the portal server.  Its data is synced from there.

### 3.1.3 NGG_B_SALFLDG Table Design ([dbo].[NGG_B_SALFLDG])

This is copied from the portal server.  Its data is synced from there.

### 3.1.4 Config Table Design ([dbo].[Config])

![config tabe design](config_table_design.svg)

All the meta deta (structure data such as column name, row name, excel row number, excel column name....etc) of the DRR excel file is to be inserted into a config table.

The stored procedure will select data from this table following the correct conditions and build the SQL queries on the fly.
Each generated SQL query is to be executed and the result is stored in the staging table.
The result is the value that matches to the one stored in the DRR excel file.

### 3.1.5 Script Running Status Table Design ([dbo].[Script_Running_Status])

This table stores the status of the running command. The DRR script can only run once at a time.

### 3.1.6 Summary Raw Table Design ([Staging].[Summary_raw])

This table stores the raw values of all the cells in ``Summary Sheet``.

### 3.1.7 Summary Table Design ([Staging].[Summary])

This table stores the rounded values of all the cells in  ``Summary Sheet``.

### 3.1.8 Summary Revenue Result Table Design ([Staging].[Summary_Revenue_Result])

This table stores the values of all the cells in ``REVENUE Section`` of the ``Summary Sheet``.

We fetch data for a sheet, section by section; and ``STATISTICS Section`` depends on ``REVENUE Section``. 

So we need to store the values of all the cells in ``REVENUE Section`` so that later it can be used to calculate the values of some cells in ``STATISTICS Section``.

This table stored the raw values of all the cells in ``REVENUE Section`` of the Summary sheet.

### 3.1.9 Detail Room Raw Table Design ([Staging].[Detail_Room_raw])

This table stores the raw values of all the cells in detail room sheet.

### 3.1.10 Detail Room Table Design ([Staging].[Detail_Room])

This table stores the rounded values of all the cells in detail room sheet.

### 3.1.11 Detail F&B Raw Table Design ([Staging].[Detail_FB_raw])

This table stores the raw values of all the cells in detail f&b sheet.

### 3.1.12 Detail F&B Table Design ([Staging].[Detail_FB])

This table stores the rounded values of all the cells in detail f&b sheet.

### 3.1.13 Executive Summary MTD Table Design ([Staging].[Executive_Summary_MTD])

This table stores the rounded values of all the cells in MTD section of executive summary sheet.

### 3.1.14 Executive Summary Key Data Table Design ([Staging].[Executive_Summary_KeyData])

This table stores the rounded values of all the cells in Key Data section of executive summary sheet.

### 3.1.15 Get Report Procedure Design ([dbo].[GetReport])

This stored procedure is to calculate the report data for a particular section of a particular sheet for a particular day.

![stored procedure](./stored-procedure.svg)

- Block1

  This is where all the necessary variables are defined. Its purpose is to do the following.
  - build an SQL query for a particular cell on the fly by giving the necessary parameters from the [dbo].[Config]
  - execute that SQL query and put the result into @resultTable along with other necessary values.

- Block2
  
  This is about getting the report data for the ``Summary Sheet``.

  There are 3 sub-blocks here.

  - Calculate the values based on ``row`` and ``columns``
  - Round the values

- Block3

  This is about getting the report data for the ``Detail Room Sheet``.

  There are 3 sub-blocks here.

  - Calculate the values based on ``row`` and ``columns``
  - Round the values

- Block4

  This is about getting the report data for the ``Detail F&B Sheet``.

  There are 3 sub-blocks here.

  - Calculate the values based on ``row`` and ``columns``
  - Round the values

- Block5

  This is about getting the report data for the ``Executive Summary Sheet``.

  There are 3 sub-blocks here.

  - section ``NAGAWORLD``
  - section ``MTD External Rooms Occupancy % (Market Segments)``
  - section ``Key Data F&B``

[Here is the SQL script](/sql/sp_get_report.sql)

### 3.1.16 Sync Data Procedure Design ([dbo].[Drr_sync_data])

This is to sync data from the portal server to the production database server.

The data is synced to the below tables.

- [3.1.1 NGG_A_SALFLDG Table Design ([dbo].[NGG_A_SALFLDG])](#311-ngg_a_salfldg-table-design-dbongg_a_salfldg)
- [3.1.2 NGG_A_ACNT_ANL_CAT Table Design ([dbo].[NGG_A_ACNT_ANL_CAT])](#312-ngg_a_acnt_anl_cat-table-design-dbongg_a_acnt_anl_cat)
- [3.1.3 NGG_B_SALFLDG Table Design ([dbo].[NGG_B_SALFLDG])](#313-ngg_b_salfldg-table-design-dbongg_b_salfldg)

[Here is the SQL script](/sql/sp_sync_data.sql)

### 3.2 Configuration

The configuaration can be given through .env file or the system's environment variables.
Here is the loading priority order of the configuration.

```
system's environment variables > .env file
```

If they are available in the system, the .env file is ignored.


| Key                                         | Description                                                             |
|---------------------------------------------|-------------------------------------------------------------------------|
| REPORT_DIR                                  | the directory to store the report files                                 |
| REPORT_NAME                                 | the report prefix name                                                  |
| LOG_DIR                                     | the directory to store the log files                                    |
| REPORT_TITLE_LINE1                          | the first-line title that is positioned at the top left corner          |
| REPORT_TITLE_LINE2                          | the second-line title that is positioned at the top left corner         |
| DB_DRIVER                                   | the database driver name supported by the machine                       |
| DB_SERVER                                   | the database server hostname or ip                                      |
| DB_USERNAME                                 | the database username                                                   |
| DB_PASSWORD                                 | the database password                                                   |
| MAIL_SERVER                                 | the mail server hostname or ip                                          |
| MAIL_USER                                   | the mail user's email address                                           |
| MAIL_PASSWORD                               | the password of that mail user                                          |
| MAIL_DRR_RECIPIENTS_GROUP1                  | the recipients' email addresses in group1                               |
| MAIL_DRR_RECIPIENTS_GROUP2                  | the recipients' email addresses in group2                               |
| MAIL_DRR_RECIPIENTS_GROUP3                  | the recipients' email addresses in group3                               |
| MAIL_NOTIFY_FAIL1_SUBJECT                   | the subject of the notification email in fail scenario 1                |
| MAIL_NOTIFY_FAIL1_BODY                      | the body of the notification email in fail scenario 1                   |
| MAIL_NOTIFY_FAIL2_SUBJECT                   | the subject of the notification email in fail scenario 2                |
| MAIL_NOTIFY_FAIL2_BODY                      | the body of the notification email in fail scenario 2                   |
| MAIL_NOTIFY_FAIL3_SUBJECT                   | the subject of the notification email in fail scenario 3                |
| MAIL_NOTIFY_FAIL3_BODY                      | the body of the notification email in fail scenario 3                   |
| MAIL_NOTIFY_FAIL4_SUBJECT                   | the subject of the notification email in fail scenario 4                |
| MAIL_NOTIFY_FAIL4_BODY                      | the body of the notification email in fail scenario 4                   |
| MAIL_NOTIFY_FAIL5_SUBJECT                   | the subject of the notification email in fail scenario 5                |
| MAIL_NOTIFY_FAIL5_RECIPIENTS                | the recipients of the notification email in fail scenario 5             |
| MAIL_NOTIFY_FAIL6_SUBJECT                   | the subject of the notification email in fail scenario 6                |
| MAIL_NOTIFY_FAIL6_BODY                      | the body of the notification email in fail scenario 6                   |
| MAIL_NOTIFY_FAIL6_RECIPIENTS                | the recipients of the notification email in fail scenario 6             |
| MAIL_NOTIFY_FAIL_RECIPIENTS                 | the recipients of the notification email in any fail scenario except fail scenario 6 |
| MAIL_NOTIFY_SUCCESS_SUBJECT                 | the subject of the notification email in success scenario               |
| MAIL_NOTIFY_SUCCESS_RECIPIENTS              | the recipients of the notification email in success scenario            |
| SSC_SENDER                                  | the email address of the SSC Notification email's sender                |
| SSC_SUBJECT                                 | the subject of the the SSC Notification email                           |
| SSC_SEARCH                                  | the sentence or the phase that means to tell that SSC is in good status |
| COMMAND_ISSUERS                             | the email addresses to whom the command listener listen to              |
| CLEAR_TIMEOUT                               | the timeout duration in minute in which any command can run             |


MAIL_DRR_RECIPIENTS_GROUP1 is the list of recipients to receive a report email attaching both Excel document and PDF document.

They are:
- [Finance Team](#the-7-actors)
- [Programming Team](#the-7-actors)

MAIL_DRR_RECIPIENTS_GROUP2 is the list of recipients to receive a report email attaching only PDF document.

They are:
- [HOD Team](#the-7-actors)

MAIL_DRR_RECIPIENTS_GROUP3 is the list of recipients to receive a report email attaching only PDF document.

They are:
- [Top Management Team](#the-7-actors)


Here are all the fail scenarios.

- Fail Scenario 1
  
  When one or some SSC emails are missing.

- Fail Scendario 2

  When the good-status sentence is not found in 3 SSC emails.

- Fail Scenario 3

  When the data synchronization fails.

- Fail Scenario 4

  When the DRR automation fails.

- Fail Scenario 5

  When the invalid command was sent to the command listener module.

- Fail Scenario 6

  When trying to run the DRR script while it is busy.

All the recipients' fields have the particular syntax.

For Example:

MAIL_DRR_RECIPIENTS_GROUP1=``a@a.com``!``b@b.com``,``c@c.com``!``d@d.com``,``e@e.com``,``f@f.com``|``g@g.com``,``h@h.com``|``m@m.com``

| Sub-groups      | TO                     | CC                     | BCC                                |
|-----------------|------------------------|------------------------|------------------------------------|
| 1               | a@a.com                 | b@b.com<br/>c@c.com    | d@d.com<br/>e@e.com</br>f@f.com   |
| 2               | g@g.com<br/>h@h.com    |                        |                                    |
| 3               | m@m.com                |                        |                                    |


That means, the same email (with the same attachements) are to be sent to 3 sub-groups of recipients.


### 3.3 Config Reader Module (``config_reader.py``)

It reads the configuration from the system or the .env file.

If the configuration is found in the system, the .env file is ignore.

### 3.4 My Logger Module (``my_logger.py``)

It wraps the python's logging module and customizes some settings such as:

- output the logging to both console and file
- create a new log file once a day
- 5M for each log file
- specify the log file path
- set log format

If any log file's size is greater than 5m, the new log file will be created like this.

```
drr-20240806.log
drr-20240806.log1
drr-20240806.log2
```

### 3.5 Util Module (``util.py``)

This is where all the constants, the enumerations, and the utility functions are all defined.

### 3.6 Util Config Module (``util_config.py``)

It provides the constants for the configuration keys.

### 3.7 Error Module (``error.py``)

This is where the custom error classes are defined.

### 3.8 DB Module (``db.py``)

This is the only module that communicate directly with database. 

Currently it only supports Microsoft SQL Server.

In order to support other DBMS, the stored procedures will need to be rewritten; 
and this DB Module will need to be updated as well

### 3.9 Email Module (``email.py``)

![Email Module](./email-module.svg)

This module communicates with EWS through [Exchangelib](https://ecederstrand.github.io/exchangelib/).

The Command Listener Module and the Report Module require the below functionalities.

- search for emails
  
  ![search for emails](search-emails.svg)

  [Exchangelib](https://github.com/ecederstrand/exchangelib)'s searching is modeled after the Django QuerySet Api that is lazy.
  So it does not fetch anything before the QuerySet is iterated. 
  
  Moreover, the search conditions can be chained as well.
  With [Exchangelib](https://github.com/ecederstrand/exchangelib), the emails can be searched using these keywords only

  ```
  parent_folder_id
  item_class
  subject
  sensitivity
  text_body
  body
  attachments
  datetime_received
  size, categories
  importance
  in_reply_to 
  is_submitted
  is_draft
  is_from_me
  is_resend
  is_unmodified
  headers
  datetime_sent
  datetime_created
  response_objects
  reminder_is_set
  reminder_minutes_before_start
  display_cc
  display_to
  has_attachments
  effective_rights
  last_modified_name
  last_modified_time
  is_associated
  web_client_read_form_query_string
  web_client_edit_form_query_string
  conversation_id
  unique_body
  sender
  is_read_receipt_requested
  is_delivery_receipt_requested
  conversation_t
  opic
  author
  message_id
  is_read
  is_response_requested
  references
  received_by
  received_representing
  reminder_message_data
  ```

  Reference is here

  [Exchangelib Email Searching](https://ecederstrand.github.io/exchangelib/#searching)


  #### Algorithm to filter emails

  1. emails that came in today (from 00:00:00 till 23:59:59)
  2. emails that has the subject we want
  3. emails that were sent from a particular sender

  Only first and second conditions can be chained together. The 3rd condition is to be manually processed.


- send an email

  ![send email](send-email.svg)


### 3.10 Excel Module (``excel.py``)

![Excel Module](./excel-module.svg)

It provides a funcitonality.

- create excel document

The Report Module requires this functionality.

### 3.11 PDF Module (``pdf.py``)

![PDF Module](./pdf-module.svg)

It provides a functionality.

- create pdf document

The Report Module requires this functionality.

### 3.12 HTML Module (``html.py``)

![HTML Module](./html-module.svg)

It provides a functionality.

- create html document

The Report Module requires this functionality.

```
Why do we need this module?
```

The report email must contains the executive summary report as its body.

In order to put the executive summary data in that email's body, we need to put the raw report data inside an HTML file; 
and then copy the html content inside that file to the email's body.

### 3.13 Command Listener Module (``command_listener.py``)

![Command Listener Module](./command-listener-module.svg)

It listens periodically for any new command given through email by the command issuers.

The command issuers is the list of email addresses, and can be configured as ``COMMAND_ISSUERS``.

The command issuer puts the command in an email's subject and sends it to ``itdbanotification@nagaworld.com``.

This module will search for the latest email received from that command issuer.

If there is one, it parses that command and call the Report Module to proceed.

This module supports the following commands.

| Commands                  | Description                                                                                    |
|---------------------------|------------------------------------------------------------------------------------------------|
| das run info 2024-08-07   | request for the DRR report for the 7th of August, 20224; and generate the log in info level    |
| das run debug 2024-08-07  | request for the DRR report for the 7th of August, 20224; and generate the log in debug level   |
| das run                   | request for the DRR report for yesterday; and generate the log in info level                       |

das stands for ``DRR Automation Script``.

### 3.14 Report Module (``report.py``)

![Report Module](./report-module.svg)

This module requires some functionalities below.

- ``send email and search for email`` provided by [Email Module](#39-email-module-emailpy)
- ``create excel document`` provided by [Excel Module](#310-excel-module-excelpy)
- ``create pdf document`` provided by [PDF Module](#311-pdf-module-pdfpy)
- ``create html document`` provided by [HTML Module](#312-html-module-htmlpy)

## 4. Deployment Design (Docker)

![docker deployment](docker-deployment.svg)

We use [Airflow](https://airflow.apache.org/) to schedule and run the script.

Airflow runs inside a container, and the DRR script will run in another. Airflow container will execute the command provided from the DRR script through a ``/var/run/docker.sock``.

DRR script is a python project that should run inside its own environment. So putting it inside a docker container is a good choice.

### 4.1 Airflow's DAG file

In Airflow, the task is created through a DAG file where the python code is written.
In that DAG file, we can do lots of things such as:
- name the task we want to run
- schedule it
- call the respective docker container to execute a command

Here is how it sends the command to a docker container

```python
t1 = DockerOperator(
  dag=dag,
  task_id="drr_command_listener_clear",
  image="naga/drr:1.0.0",
  env_file=".env",
  auto_remove=True,
  mount_tmp_dir=False,
  docker_url="unix://var/run/docker.sock",
  command="python -m drr.report",
  mounts=[
    Mount(source='/home/malinka/projects/drr/deploy/drr/logs',
          target='/app/logs',
          type='bind'),
    Mount(source='/home/malinka/projects/drr/deploy/drr/reports',
          target='/app/reports',
          type='bind'),
  ],
)
```
This mean, Airflow will send the command ``python -m drr.report`` to a docker container that uses image ``naga/drr:1.0;0``.

The Airflow also passes the environment variables found in .env file (located in the same parent directory of this DAG file), to that docker container. This will nulify all other .env files.

The application running inside the docker container has two mounted volumes

- /app/logs

  this is where to store the log files inside the docker container

- /app/reports

  this is where store the report files inside the docker container

The Airflow needs mount the above two directories from inside the docker container to the host's directories respectively.

- /app/logs ---> /home/malinka/projects/drr/deploy/drr/logs

- /app/reports ---> /home/malinka/projects/drr/deploy/drr/reports


Therefore, we can have access to both log files and report files in the host machine.

