# User Guide

This is the user guide for DRR script project.

## Revision History

| Revision  | Date       | Author        |  Description  |
|-----------|------------|---------------|---------------|
| 1.0       | 07/08/2024 | Phann Malinka |  Creation     |
| 2.0       | 08/08/2024 | Phann Malinka |  Update       |


### 2.7 How to refresh data on DRR spreadsheet?

TO BE ADDED LATER

### 2.7 How to remote to itdbanotification's machine?

TO BE ADDED LATER

### 2.8 How to hide row or column?

TO BE ADDED LATER

### 2.9 How to verify the [dbo].[Config] against the DRR spreedsheet?

TO BE ADDED LATER

### 2.10 How to trace the issue?

TO BE ADDED LATER


## 1 Development Environment

### 1.1 Install microsoft odbc driver

on Debian,

```bash
app/scripts/install_pyodbc_debian.sh
```

on Ubuntu,

```bash
app/scripts/install_pyodbc_ubuntu.sh
```

Otherwise, you can follow the instructions in this original source.

 [microsoft odbc driver for linux](https://learn.microsoft.com/en-us/sql/connect/odbc/linux-mac/installing-the-microsoft-odbc-driver-for-sql-server?view=sql-server-ver16&redirectedfrom=MSDN&tabs=ubuntu18-install%2Cubuntu17-install%2Cdebian8-install%2Credhat7-13-install%2Crhel7-offline#17)


on Window, you just install the official ODBC driver from microsoft.

[microsoft odbc driver for window](https://learn.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server)

### 1.2 Configure Openssl to work with Microsoft SQL (only on Linux)

Copy [openssl.cnf](../../deploy/drr/openssl.cnf) and replace in ``/etc/ssl/`` in Ubuntu or Debian.

Otherwise, you need to manually edit the file as below.

  in ``/etc/ssl/openssl.cnf``, change
    
  ```
  openssl_conf = openssl_init
  ```
  to 
  
  ```
  openssl_conf = default_conf
  ```

  add these lines if they are not there.

  ```
  [default_conf]
  ssl_conf = ssl_sect

  [ssl_sect]
  system_default = system_default_sect

  [system_default_sect]
  MinProtocol = TLSv1.2
  CipherString = DEFAULT@SECLEVEL=0
  ```

### 1.3 Virtual environment and dependencies

Create a virtual environment and install those dependencies inside it.

```
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 1.4 .env File

- rename ``.env_test`` to ``.env`` and put inside ``app`` directory
- update values in ``.env`` as you see fit

### 1.5 Run


```bash
cd app
```

There are 3 supported commands.

|                Commands               |                        Detail                                                       |
| --------------------------------------|-------------------------------------------------------------------------------------|
| python -m drr.command_listener clear  | to set status = FAIL to any long-running commands                                   |
| python -m drr.command_listener run    | to listen to any new command                                                        |
| python -m drr.report                  | to genereate the report for yesterday; send it to the relevant people and write log in info level |
| python -m drr.report info 2024-08-07  | to genereate the report for 7th of August, 2024; send it to the relevant people and write log in info level |
| python -m drr.report debug 2024-08-07  | to genereate the report for 7th of August, 2024; send it to the relevant people and write log in debug level |

### 1.6 Where is the log file?

The log file is in ``logs/``

The log files are created once a day.

```
drr-20240806.log
drr-20240807.log
drr-20240808.log
```

If any log file's size is greater than 5m, the new log file will be created like this.

```
drr-20240806.log
drr-20240806.log1
drr-20240806.log2
```

### 1.7 Where is the report file?

The report files (excel and pdf) are physically stored inside ``reports/``

### 1.8 How to schedule the cronjobs?

In development environment on Linux, we use crontab as the scheduler.

On window, we can also use window scheduler.

- list all cronjobs created under the current linux user

  ```bash
  crontab -l
  ```

- remove all cronjobs created under the current linux user

  ```bash
  crontab -r
  ```

- create cronjobs under the current linux user

  ```bash
  crontab scripts/drr_cronjob.ini
  ```
  
  ``scripts/drr_cronjob.ini`` creates 3 jobs.


## 2 Production Environment (Docker)

### 2.1 Deploy DRR

Make sure ``.env`` file is in ``deploy/drr``. This ``.env`` file will be ignored.
It is just there to prevent any warning logs.

```bash
cd deploy/drr
docker-compose up -d
```
If it is successful, a container name ``naga-drr`` is created from the docker image ``naga/drr:1.0.0``.

### 2.2 Deploy Airflow

```
cd deploy/airflow
```

Make sure ``.env`` file is in deploy/airflow.

If this is the first Airflow deployment, run the below command.

```
echo -e "AIRFLOW_UID=$(id -u)" >> .env
```

Then up the containers
```bash
docker-compose up -d
```

### 2.3 Environment Variables

The only ``.env`` file that matters is in ``deploy/airflow/dags/drr/``.

We can change values in there at anytime without restarting any container or even rebuilding docker image; because we pass the environment variables through docker-compose.yaml.

When the task starts to run, it will pick up the latest values from ``deploy/airflow/dags/drr/.env``

### 2.4 Where are the log file and the report file?

Let look at this Docker Operator defined within ``deploy/airflow/dags/drr/drr_report.py``

```python
t1 = DockerOperator(
        dag=dag,
        task_id="drr_report",
        image="naga/drr:1.0.0",
        env_file=".env",
        auto_remove=True,
        mount_tmp_dir=False,
        docker_url="unix://var/run/docker.sock",
        command="python -m drr.report",
        mounts=[
            Mount(source='/home/malinka/projects/drr/deploy/drr/logs',
              target='/app/logs',
              type='bind'),
            Mount(source='/home/malinka/projects/drr/deploy/drr/reports',
              target='/app/reports',
              type='bind'),
        ],
    )
```

- ``/app/logs`` is the directory inside the container and mounted to ``/home/malinka/projects/drr/deploy/drr/logs`` in host machine.
- ``/app/reports`` is the directory inside the container and mounted to ``/home/malinka/projects/drr/deploy/drr/reports`` in host machine.

### 2.5 How to send command to itdbanotification@nagaworld.com?

In ``.env`` file, make sure to edit the ``COMMAND_ISSUERS``

```
COMMAND_ISSUERS=rajajeganramesh@nagaworld.com
```

This mean, the script will only listen to ``rajajeganramesh@nagaworld.com``.

Let Mr. ``rajajeganramesh@nagaworld.com`` sends an email whose subject = ``das run`` to ``itdbanotification@nagaworld.com``.
The script will generate the report for yesterday and send it to those people configured in .env file.

For more details on the supported commands, please check here
[Command Listener Module](../sdd/sdd.md#313-command-listener-module-command_listenerpy)


### 2.6 How to schedule a project to run periodically in Airflow?

- Run that project as a docker container.

- Create a dag file for that project and put it here ``deploy/airflow/dags/PROJECT_NAME/PROJECT_DAG_FILE.py``

  Please check the examples in 
  - ``deploy/airflow/dags/drr/drr_report``
  - ``deploy/airflow/dags/drr/drr_command_listener_clear.py``
  - ``deploy/airflow/dags/drr/drr_command_listener_run.py``

  If there are multiple tasks to run, make sure those DAG file names are preceded by the same word. 
  This will make them located closed to each other in the Airflow's page.






