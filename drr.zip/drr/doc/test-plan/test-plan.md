# Test Plan Document

This is the Test Plan document for DRR Automation Script project.

There are 7 scenarios to test.

## Pre Test

This is about preparing the testing environment in advance.

Make sure you run the script in ``Ubuntu``.

Install the dependencies:

```
cd app
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## 1 Test Fail Scenario 1

It happens when one or some SSC emails are missing.

### 1.1 Pre-Conditions

- Make sure the ``.env_test`` is renamed to ``.env`` in directory ``app`` and change the value of ``MAIL_NOTIFY_FAIL_RECIPIENTS`` accordingly.

- Make sure there are 3 SSC Notification emails received with good status by today.

### 1.2 Steps

- Move one SSC Notification email to the ``Deleted Items``.

  ![move file](./move-email.png)

- Run the script
  ```bash
  python -m drr.report
  ```
 
### 1.3 What happens?

In ``app/logs/drr.log``, these logs are stamped.

```
2024-08-06 15:58:55,846 [report.py:245:command_listener_run()] INFO: [Report]: Generate DRR Report for 2024-08-05 15:58:55.489878 begin -----------------------
2024-08-06 15:58:55,846 [report.py:39:send_report()] INFO: report date for query = 2024-08-05 15:58:55.489878
2024-08-06 15:58:55,846 [report.py:49:send_report()] INFO: report file name=Daily Revenue Report - Hotel 050824, pdf file=reports/Daily Revenue Report - Hotel 050824.pdf, excel file=reports/Daily Revenue Report - Hotel 050824.xlsx
2024-08-06 15:58:55,846 [report.py:60:send_report()] INFO: group1 recipients=[{'to': ['phannmalinka@nagaworld.com'], 'cc': None, 'bcc': None}]
2024-08-06 15:58:55,846 [email.py:112:search_emails_by_subject_sender()] INFO: search_emails: search emails with the following params: subject=SSC Notification, sender=nwgeneralopera@nagaworld.com, search from=2024-08-06 00:00:00, search to=2024-08-06 23:59:59
2024-08-06 15:58:56,102 [report.py:301:command_listener_run()] ERROR: [Report]: MissingEmailError: 2 emails received from ssc sender=nwgeneralopera@nagaworld.com, subject=SSC Notification, from=2024-08-06 00:00:00, to=2024-08-06 23:59:59
2024-08-06 15:58:56,102 [db.py:340:log_status()] INFO: log status >>> receive at=2024-08-06 15:58:55, status=FAIL
2024-08-06 15:58:56,153 [email.py:164:send_email()] INFO: send email with the following params: subject=SSC Notification Mails not Received, to=['phannmalinka@nagaworld.com'], cc=None, bcc=None, body=hidden, attachments=0
2024-08-06 15:58:56,348 [email.py:203:send_email()] INFO: email is sent
2024-08-06 15:58:56,348 [db.py:315:log_status_when_stop()] INFO: log status when command done >>> receive at=2024-08-06 15:58:55, stop at=2024-08-06 15:58:56
```

The recipients will receive a new email.
- Subject = SSC Notification Mails not Received
- Body = One or few SSC Notification mails not received

## 2 Test Fail Scenario 2

It happens when the good-status sentence is not found in one or some of today's SSC Notification emails.

### 2.1 Pre-Conditions

- Make sure the ``.env_test`` is renamed to ``.env`` in directory ``app`` and change the value of ``MAIL_NOTIFY_FAIL_RECIPIENTS`` accordingly.

- Make sure there are 3 SSC Notification emails received with good status by today.

### 2.2 Steps

- Edit one of the SSC Notification email and change the following phrase.

  ```
  The following profiles have been completed
  ```

  to 

  ```
  The following profiles have been failed
  ```

  ``It can be removed or changed to anything.``

  ![edit-email](./edit-email.png)


  Save that email.

- Run the script

  ```
  python -m drr.report
  ```

### 2.3 What happens?

In ``app/logs/drr.log``, these logs are stamped.

```
2024-08-06 16:14:26,391 [report.py:245:command_listener_run()] INFO: [Report]: Generate DRR Report for 2024-08-05 16:14:26.045500 begin -----------------------
2024-08-06 16:14:26,392 [report.py:39:send_report()] INFO: report date for query = 2024-08-05 16:14:26.045500
2024-08-06 16:14:26,392 [report.py:49:send_report()] INFO: report file name=Daily Revenue Report - Hotel 050824, pdf file=reports/Daily Revenue Report - Hotel 050824.pdf, excel file=reports/Daily Revenue Report - Hotel 050824.xlsx
2024-08-06 16:14:26,392 [report.py:60:send_report()] INFO: group1 recipients=[{'to': ['phannmalinka@nagaworld.com'], 'cc': None, 'bcc': None}]
2024-08-06 16:14:26,392 [email.py:112:search_emails_by_subject_sender()] INFO: search_emails: search emails with the following params: subject=SSC Notification, sender=nwgeneralopera@nagaworld.com, search from=2024-08-06 00:00:00, search to=2024-08-06 23:59:59
2024-08-06 16:14:26,743 [report.py:316:command_listener_run()] ERROR: [Report]: StatusFailError: 2 emails received from ssc sender=nwgeneralopera@nagaworld.com, subject=SSC Notification, keyword=The following profiles have been completed, from=2024-08-06 00:00:00, to=2024-08-06 23:59:59
2024-08-06 16:14:26,743 [db.py:340:log_status()] INFO: log status >>> receive at=2024-08-06 16:14:26, status=FAIL
2024-08-06 16:14:26,766 [email.py:164:send_email()] INFO: send email with the following params: subject=SSC Notification Mails received with failure, to=['phannmalinka@nagaworld.com'], cc=None, bcc=None, body=hidden, attachments=0
2024-08-06 16:14:26,962 [email.py:203:send_email()] INFO: email is sent
2024-08-06 16:14:26,962 [db.py:315:log_status_when_stop()] INFO: log status when command done >>> receive at=2024-08-06 16:14:26, stop at=2024-08-06 16:14:26
```

The recipients will receive a new email.
- Subject = SSC Notification Mails received with failure
- Body = Kindly check for failure during SSC File Import process

## 3 Test Fail Scenario 3

It happens when the data synchronization fails.

### 3.1 Pre-Conditions

- Make sure the ``.env_test`` is renamed to ``.env`` in directory ``app`` and change the value of ``MAIL_NOTIFY_FAIL_RECIPIENTS`` accordingly.

- Make sure there are 3 SSC Notification emails received with good status by today.

### 3.2 Steps

- Run the script

  ```
  python -m drr.report
  ```

- When it shows ``Sync data starts ...`` for 2 seconds, click CTRL + C to exit the script.

### 3.3 What happens?

In ``app/logs/drr.log``, these logs are stamped.

```
2024-08-06 16:25:39,512 [report.py:245:command_listener_run()] INFO: [Report]: Generate DRR Report for 2024-08-05 16:25:39.124491 begin -----------------------
2024-08-06 16:25:39,513 [report.py:39:send_report()] INFO: report date for query = 2024-08-05 16:25:39.124491
2024-08-06 16:25:39,513 [report.py:49:send_report()] INFO: report file name=Daily Revenue Report - Hotel 050824, pdf file=reports/Daily Revenue Report - Hotel 050824.pdf, excel file=reports/Daily Revenue Report - Hotel 050824.xlsx
2024-08-06 16:25:39,513 [report.py:60:send_report()] INFO: group1 recipients=[{'to': ['phannmalinka@nagaworld.com'], 'cc': None, 'bcc': None}]
2024-08-06 16:25:39,513 [email.py:112:search_emails_by_subject_sender()] INFO: search_emails: search emails with the following params: subject=SSC Notification, sender=nwgeneralopera@nagaworld.com, search from=2024-08-06 00:00:00, search to=2024-08-06 23:59:59
2024-08-06 16:25:39,819 [report.py:107:send_report()] INFO: SSC email check: found 3 emails sent from sender=nwgeneralopera@nagaworld.com, subject=SSC Notification, keyword=The following profiles have been completed, from=2024-08-06 00:00:00, to=2024-08-06 23:59:59
2024-08-06 16:25:39,819 [report.py:113:send_report()] INFO: Sync data starts ...
2024-08-06 16:25:42,924 [report.py:286:command_listener_run()] ERROR: [Report]: SyncDataError: sync fail
2024-08-06 16:25:42,924 [db.py:340:log_status()] INFO: log status >>> receive at=2024-08-06 16:25:39, status=FAIL
2024-08-06 16:25:42,956 [email.py:164:send_email()] INFO: send email with the following params: subject=DRR Synchronization failure, to=['phannmalinka@nagaworld.com'], cc=None, bcc=None, body=hidden, attachments=0
2024-08-06 16:25:43,144 [email.py:203:send_email()] INFO: email is sent
2024-08-06 16:25:43,144 [db.py:315:log_status_when_stop()] INFO: log status when command done >>> receive at=2024-08-06 16:25:39, stop at=2024-08-06 16:25:43
```

The recipients will receive a new email.
- Subject = DRR Synchronization failure
- Body = Kindly check for failure during DRR Synchronization process

## 4 Test Fail Scenario 4

It happens when something goes wrong in DRR script beside the 5 fail scenarios.

### 4.1 Pre-Conditions

- Make sure the ``.env_test`` is renamed to ``.env`` in directory ``app`` and change the value of ``MAIL_NOTIFY_FAIL_RECIPIENTS`` accordingly.

- Make sure there are 3 SSC Notification emails received with good status by today.

### 4.2 Steps

- Run the script

  ```
  python -m drr.report
  ```

-  After it shows ``Sync data done` for a 2 seconds, click CTRL + C to exit the script.

### 4.3 What happens?

In ``app/logs/drr.log``, these logs are stamped.

```
2024-08-06 16:36:43,543 [report.py:245:command_listener_run()] INFO: [Report]: Generate DRR Report for 2024-08-05 16:36:43.187058 begin -----------------------
2024-08-06 16:36:43,543 [report.py:39:send_report()] INFO: report date for query = 2024-08-05 16:36:43.187058
2024-08-06 16:36:43,544 [report.py:49:send_report()] INFO: report file name=Daily Revenue Report - Hotel 050824, pdf file=reports/Daily Revenue Report - Hotel 050824.pdf, excel file=reports/Daily Revenue Report - Hotel 050824.xlsx
2024-08-06 16:36:43,544 [report.py:60:send_report()] INFO: group1 recipients=[{'to': ['phannmalinka@nagaworld.com'], 'cc': None, 'bcc': None}]
2024-08-06 16:36:43,544 [email.py:112:search_emails_by_subject_sender()] INFO: search_emails: search emails with the following params: subject=SSC Notification, sender=nwgeneralopera@nagaworld.com, search from=2024-08-06 00:00:00, search to=2024-08-06 23:59:59
2024-08-06 16:36:43,872 [report.py:107:send_report()] INFO: SSC email check: found 3 emails sent from sender=nwgeneralopera@nagaworld.com, subject=SSC Notification, keyword=The following profiles have been completed, from=2024-08-06 00:00:00, to=2024-08-06 23:59:59
2024-08-06 16:36:43,872 [report.py:113:send_report()] INFO: Sync data starts ...
2024-08-06 16:37:15,998 [report.py:121:send_report()] INFO: Sync data done
2024-08-06 16:37:16,045 [db.py:161:get_sheets_data()] INFO: get sheets data >>> report date = 2024-08-05 16:36:43.187058
2024-08-06 16:37:16,048 [db.py:176:get_sheets_data()] INFO: structure data grouped by SheetName
2024-08-06 16:37:16,048 [db.py:177:get_sheets_data()] INFO:            SheetName                                                  0
0            Summary  [SheetName, SheetOrder, SectionName, RowName, ...
1        Detail Room  [SheetName, SheetOrder, SectionName, RowName, ...
2         Detail F&B  [SheetName, SheetOrder, SectionName, RowName, ...
3  Executive Summary  [SheetName, SheetOrder, SectionName, RowName, ...
2024-08-06 16:37:16,054 [db.py:89:get_sheet_data()] INFO: get sheet data >>> report_date = 2024-08-05 16:36:43.187058, sheet = Summary
2024-08-06 16:37:16,055 [db.py:114:get_sheet_data()] INFO: sections in sheet = Summary
2024-08-06 16:37:16,055 [db.py:115:get_sheet_data()] INFO:   SectionName                                          ExcelRows
0     REVENUE  [12.0, 12.0, 12.0, 12.0, 12.0, 12.0, 12.0, 12....
1  STATISTICS  [43.0, 43.0, 43.0, 43.0, 43.0, 43.0, 43.0, 43....
2024-08-06 16:37:20,402 [report.py:332:command_listener_run()] ERROR: [Report]: DRRError: Traceback (most recent call last):
  File "/usr/lib/python3.10/encodings/utf_16_le.py", line 15, in decode
    def decode(input, errors='strict'):
KeyboardInterrupt

The above exception was the direct cause of the following exception:

KeyboardInterrupt: decoding with 'utf-16le' codec failed (KeyboardInterrupt: )

The above exception was the direct cause of the following exception:

Traceback (most recent call last):
  File "/home/malinka/projects/drr/app/drr/db.py", line 73, in get_data
    result = conn.execute(sql, values)
  File "/home/malinka/projects/drr/app/.venv/lib/python3.10/site-packages/sqlalchemy/future/engine.py", line 286, in execute
    return self._execute_20(
  File "/home/malinka/projects/drr/app/.venv/lib/python3.10/site-packages/sqlalchemy/engine/base.py", line 1710, in _execute_20
    return meth(self, args_10style, kwargs_10style, execution_options)
  File "/home/malinka/projects/drr/app/.venv/lib/python3.10/site-packages/sqlalchemy/sql/elements.py", line 334, in _execute_on_connection
    return connection._execute_clauseelement(
  File "/home/malinka/projects/drr/app/.venv/lib/python3.10/site-packages/sqlalchemy/engine/base.py", line 1577, in _execute_clauseelement
    ret = self._execute_context(
  File "/home/malinka/projects/drr/app/.venv/lib/python3.10/site-packages/sqlalchemy/engine/base.py", line 1953, in _execute_context
    self._handle_dbapi_exception(
  File "/home/malinka/projects/drr/app/.venv/lib/python3.10/site-packages/sqlalchemy/engine/base.py", line 2138, in _handle_dbapi_exception
    util.raise_(exc_info[1], with_traceback=exc_info[2])
  File "/home/malinka/projects/drr/app/.venv/lib/python3.10/site-packages/sqlalchemy/util/compat.py", line 211, in raise_
    raise exception
  File "/home/malinka/projects/drr/app/.venv/lib/python3.10/site-packages/sqlalchemy/engine/base.py", line 1910, in _execute_context
    self.dialect.do_execute(
  File "/home/malinka/projects/drr/app/.venv/lib/python3.10/site-packages/sqlalchemy/engine/default.py", line 736, in do_execute
    cursor.execute(statement, parameters)
SystemError: <class 'pyodbc.Error'> returned a result with an exception set

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "/home/malinka/projects/drr/app/.venv/lib/python3.10/site-packages/sqlalchemy/engine/base.py", line 1062, in _rollback_impl
    self.engine.dialect.do_rollback(self.connection)
  File "/home/malinka/projects/drr/app/.venv/lib/python3.10/site-packages/sqlalchemy/dialects/mssql/base.py", line 2845, in do_rollback
    super(MSDialect, self).do_rollback(dbapi_connection)
  File "/home/malinka/projects/drr/app/.venv/lib/python3.10/site-packages/sqlalchemy/engine/default.py", line 683, in do_rollback
    dbapi_connection.rollback()
pyodbc.OperationalError: ('08S01', '[08S01] [Microsoft][ODBC Driver 17 for SQL Server]Communication link failure (0) (SQLEndTran)')

The above exception was the direct cause of the following exception:

Traceback (most recent call last):
  File "/home/malinka/projects/drr/app/drr/report.py", line 246, in command_listener_run
    send_report(report_date)
  File "/home/malinka/projects/drr/app/drr/report.py", line 126, in send_report
    sheet_dict = db.get_sheets_data(structure_df, report_date)
  File "/home/malinka/projects/drr/app/drr/db.py", line 189, in get_sheets_data
    section_dfs = get_sheet_data(structure_df, report_date, sheet)
  File "/home/malinka/projects/drr/app/drr/db.py", line 130, in get_sheet_data
    section_data_df = get_data(report_date, sheet, section)
  File "/home/malinka/projects/drr/app/drr/db.py", line 68, in get_data
    with get_engine().connect() as conn:
  File "/home/malinka/projects/drr/app/.venv/lib/python3.10/site-packages/sqlalchemy/engine/base.py", line 219, in __exit__
    self.close()
  File "/home/malinka/projects/drr/app/.venv/lib/python3.10/site-packages/sqlalchemy/future/engine.py", line 252, in close
    super(Connection, self).close()
  File "/home/malinka/projects/drr/app/.venv/lib/python3.10/site-packages/sqlalchemy/engine/base.py", line 1238, in close
    self._transaction.close()
  File "/home/malinka/projects/drr/app/.venv/lib/python3.10/site-packages/sqlalchemy/engine/base.py", line 2426, in close
    self._do_close()
  File "/home/malinka/projects/drr/app/.venv/lib/python3.10/site-packages/sqlalchemy/engine/base.py", line 2649, in _do_close
    self._close_impl()
  File "/home/malinka/projects/drr/app/.venv/lib/python3.10/site-packages/sqlalchemy/engine/base.py", line 2635, in _close_impl
    self._connection_rollback_impl()
  File "/home/malinka/projects/drr/app/.venv/lib/python3.10/site-packages/sqlalchemy/engine/base.py", line 2627, in _connection_rollback_impl
    self.connection._rollback_impl()
  File "/home/malinka/projects/drr/app/.venv/lib/python3.10/site-packages/sqlalchemy/engine/base.py", line 1064, in _rollback_impl
    self._handle_dbapi_exception(e, None, None, None, None)
  File "/home/malinka/projects/drr/app/.venv/lib/python3.10/site-packages/sqlalchemy/engine/base.py", line 2134, in _handle_dbapi_exception
    util.raise_(
  File "/home/malinka/projects/drr/app/.venv/lib/python3.10/site-packages/sqlalchemy/util/compat.py", line 211, in raise_
    raise exception
  File "/home/malinka/projects/drr/app/.venv/lib/python3.10/site-packages/sqlalchemy/engine/base.py", line 1062, in _rollback_impl
    self.engine.dialect.do_rollback(self.connection)
  File "/home/malinka/projects/drr/app/.venv/lib/python3.10/site-packages/sqlalchemy/dialects/mssql/base.py", line 2845, in do_rollback
    super(MSDialect, self).do_rollback(dbapi_connection)
  File "/home/malinka/projects/drr/app/.venv/lib/python3.10/site-packages/sqlalchemy/engine/default.py", line 683, in do_rollback
    dbapi_connection.rollback()
sqlalchemy.exc.OperationalError: (pyodbc.OperationalError) ('08S01', '[08S01] [Microsoft][ODBC Driver 17 for SQL Server]Communication link failure (0) (SQLEndTran)')
(Background on this error at: https://sqlalche.me/e/14/e3q8)

2024-08-06 16:37:20,402 [db.py:340:log_status()] INFO: log status >>> receive at=2024-08-06 16:36:43, status=FAIL
2024-08-06 16:37:20,421 [email.py:164:send_email()] INFO: send email with the following params: subject=DRR Automation job failure, to=['phannmalinka@nagaworld.com'], cc=None, bcc=None, body=hidden, attachments=0
2024-08-06 16:37:20,612 [email.py:203:send_email()] INFO: email is sent
2024-08-06 16:37:20,612 [db.py:315:log_status_when_stop()] INFO: log status when command done >>> receive at=2024-08-06 16:36:43, stop at=2024-08-06 16:37:20
```

The recipients will receive a new email.
- Subject = DRR Automation job failure
- Body = Rerun DRR Automation Script

## 5 Test Fail Scenario 5

It happens when the invalid command was sent to ``itdbanotification@nagaworld.com``.

### 5.1 Pre-Conditions

- Make sure the ``.env_test`` is renamed to ``.env`` in directory ``app`` and change the value of ``MAIL_NOTIFY_FAIL5_RECIPIENTS`` accordingly.

- Make sure to change the value of ``COMMAND_ISSUERS``

- Make sure there are 3 SSC Notification emails received with good status by today.

### 5.2 Steps

- Add cronjobs to crontab

  ```
  cd scripts/
  crontab drr_cronjob.ini
  crontab -l
  ```
  All the 3 jobs are shown there.
  
  The ``command listener run`` and the ``command listener clear`` are scheduled to run every minute.

- Send an invalid command to ``itdbanotification@nagaworld.com``

  ![input invalid command](./input-invalid-cmd.png)
  

### 5.3 What happens?

In ``app/logs/drr.log``, these logs are stamped.

```
2024-08-06 16:58:01,792 [command_listener.py:79:<module>()] INFO: [CommandListenerRun]: starts
2024-08-06 16:58:01,831 [command_listener.py:75:<module>()] INFO: [CommandListenerClear]: set status = FAIL for those commands that not yet finished within 5 minutes
2024-08-06 16:58:02,051 [email.py:77:search_emails_by_subject()] INFO: search_emails: search emails with the following params: subject=das, search from=2024-08-06 00:00:00, search to=2024-08-06 23:59:59
2024-08-06 16:58:02,573 [command_listener.py:107:<module>()] INFO: Found 1 accepted emails from phannmalinka@nagaworld.com
2024-08-06 16:58:02,574 [command_listener.py:126:<module>()] INFO: [CommandListenerRun]: Receive command: das from phannmalinka@nagaworld.com at 2024-08-06 16:52:23
2024-08-06 16:58:02,574 [db.py:380:find_running_logs()] INFO: find running logs by receive_dt=2024-08-06 16:52:23
2024-08-06 16:58:02,606 [command_listener.py:147:<module>()] INFO: [CommandListenerRun]: Invalid command received: das
2024-08-06 16:58:02,607 [db.py:231:insert_fail_log()] INFO: log status when receive command >>> command=das, run by=phannmalinka@nagaworld.com, receive at=2024-08-06 16:52:23
2024-08-06 16:58:02,625 [email.py:164:send_email()] INFO: send email with the following params: subject=DRR Command Listener failure, to=['phannmalinka@nagaworld.com'], cc=None, bcc=None, body=hidden, attachments=0
2024-08-06 16:58:02,817 [email.py:203:send_email()] INFO: email is sent
```

The recipients will receive a new email.
- Subject = DRR Command Listener failure
- Body
  ```
  DateTime Received: 2024-08-06 16:52:23
  Command Issuer: phannmalinka@nagaworld.com
  Received Command: das
  Status: INVALID
  Detail: das run or das run info/debug report_date
  ```

## 6 Test Fail Scenario 6

It happens when someone tries to run the DRR script while it is busy.

### 6.1 Pre-Conditions

- Make sure the ``.env_test`` is renamed to ``.env`` in directory ``app`` and change the value of ``MAIL_NOTIFY_FAIL6_RECIPIENTS`` accordingly.

- Make sure there are 3 SSC Notification emails received with good status by today.

- Update the latest record in [dbo].[Script_Running_Status] to have ``stop_dt = NULL`` and ``status = NULL``
  
  ```
  UPDATE [dbo].[Script_Running_Status] SET stop_dt = NULL, status = NULL
  WHERE receive_dt = (SELECT TOP(1) receive_dt FROM [dbo].[Script_Running_Status] ORDER BY receive_dt DESC)
  ```

### 6.2 Steps

- Run the script

  ```
  python -m drr.report
  ```

### 6.3 What happens?

In ``app/logs/drr.log``, these logs are stamped.

```
2024-08-06 17:13:19,500 [report.py:207:command_listener_run()] INFO: run with report date=2024-08-05 17:13:19.500194, log level=20, command=python -m drr.report, run by=the scheduler, receive dt=2024-08-06 17:13:19, caller=Report
2024-08-06 17:13:19,782 [db.py:365:get_latest_running_log()] INFO: get latest log running status
2024-08-06 17:13:19,814 [report.py:231:command_listener_run()] INFO: [Report]: script is busy, it was started since 2024-08-06 16:36:43
2024-08-06 17:13:19,814 [report.py:272:command_listener_run()] ERROR: [Report]: ScriptBusyError: Automation Script is being run by the scheduler on 2024-08-06 16:36:43
2024-08-06 17:13:19,814 [db.py:340:log_status()] INFO: log status >>> receive at=2024-08-06 17:13:19, status=FAIL
2024-08-06 17:13:19,829 [email.py:164:send_email()] INFO: send email with the following params: subject=Automation Script is currently busy, to=['phannmalinka@nagaworld.com'], cc=None, bcc=None, body=hidden, attachments=0
2024-08-06 17:13:20,001 [email.py:203:send_email()] INFO: email is sent
2024-08-06 17:13:20,002 [db.py:315:log_status_when_stop()] INFO: log status when command done >>> receive at=2024-08-06 17:13:19, stop at=2024-08-06 17:13:20
```

The recipients will receive a new email.
- Subject = Automation Script is currently busy

## 7 Test Success Scenario

It happens when everything is fine and good to go.

### 7.1 Pre-Conditions

- Make sure the ``.env_test`` is renamed to ``.env`` in directory ``app`` and change the value of ``MAIL_NOTIFY_FAIL6_RECIPIENTS`` accordingly.

- Make sure there are 3 SSC Notification emails received with good status by today.

- Delete the latest record in [dbo].[Script_Running_Status] that have ``stop_dt = NULL`` and ``status = NULL``
  
  ```
  DELETE FROM [dbo].[Script_Running_Status]
  WHERE receive_dt = (SELECT TOP(1) receive_dt FROM [dbo].[Script_Running_Status] ORDER BY receive_dt DESC)
  ```

### 7.2 Steps

- Run the script

  ```
  python -m drr.report
  ```

### 7.3 What happens?

In ``app/logs/drr.log``, these logs are stamped.

```
2024-08-06 17:20:56,943 [report.py:245:command_listener_run()] INFO: [Report]: Generate DRR Report for 2024-08-05 17:20:56.290086 begin -----------------------
2024-08-06 17:20:56,943 [report.py:39:send_report()] INFO: report date for query = 2024-08-05 17:20:56.290086
2024-08-06 17:20:56,943 [report.py:49:send_report()] INFO: report file name=Daily Revenue Report - Hotel 050824, pdf file=reports/Daily Revenue Report - Hotel 050824.pdf, excel file=reports/Daily Revenue Report - Hotel 050824.xlsx
2024-08-06 17:20:56,943 [report.py:60:send_report()] INFO: group1 recipients=[{'to': ['phannmalinka@nagaworld.com'], 'cc': None, 'bcc': None}]
2024-08-06 17:20:56,944 [email.py:112:search_emails_by_subject_sender()] INFO: search_emails: search emails with the following params: subject=SSC Notification, sender=nwgeneralopera@nagaworld.com, search from=2024-08-06 00:00:00, search to=2024-08-06 23:59:59
2024-08-06 17:20:57,284 [report.py:107:send_report()] INFO: SSC email check: found 3 emails sent from sender=nwgeneralopera@nagaworld.com, subject=SSC Notification, keyword=The following profiles have been completed, from=2024-08-06 00:00:00, to=2024-08-06 23:59:59
2024-08-06 17:20:57,284 [report.py:113:send_report()] INFO: Sync data starts ...
2024-08-06 17:21:25,154 [report.py:121:send_report()] INFO: Sync data done
2024-08-06 17:21:25,191 [db.py:161:get_sheets_data()] INFO: get sheets data >>> report date = 2024-08-05 17:20:56.290086
2024-08-06 17:21:25,194 [db.py:176:get_sheets_data()] INFO: structure data grouped by SheetName
2024-08-06 17:21:25,194 [db.py:177:get_sheets_data()] INFO:            SheetName                                                  0
0            Summary  [SheetName, SheetOrder, SectionName, RowName, ...
1        Detail Room  [SheetName, SheetOrder, SectionName, RowName, ...
2         Detail F&B  [SheetName, SheetOrder, SectionName, RowName, ...
3  Executive Summary  [SheetName, SheetOrder, SectionName, RowName, ...
2024-08-06 17:21:25,200 [db.py:89:get_sheet_data()] INFO: get sheet data >>> report_date = 2024-08-05 17:20:56.290086, sheet = Summary
2024-08-06 17:21:25,201 [db.py:114:get_sheet_data()] INFO: sections in sheet = Summary
2024-08-06 17:21:25,201 [db.py:115:get_sheet_data()] INFO:   SectionName                                          ExcelRows
0     REVENUE  [12.0, 12.0, 12.0, 12.0, 12.0, 12.0, 12.0, 12....
1  STATISTICS  [43.0, 43.0, 43.0, 43.0, 43.0, 43.0, 43.0, 43....
2024-08-06 17:21:31,766 [db.py:132:get_sheet_data()] INFO: sheet=Summary, section=REVENUE, has 24 rows



A LONG LIST OF LOGS IN HERE


2024-08-06 17:22:02,091 [excel.py:1920:create_excel()] INFO: create excel >>> report_date=2024-08-05 17:20:56.290086, excel_file=reports/Daily Revenue Report - Hotel 050824.xlsx
2024-08-06 17:22:02,091 [excel.py:629:create_excel_summary()] INFO: create excel summary >>> report_date=2024-08-05 17:20:56.290086, excel_file=reports/Daily Revenue Report - Hotel 050824.xlsx, mode=new
2024-08-06 17:22:02,247 [excel.py:1138:create_excel_detail_room()] INFO: create excel for detail room >>>report_date=2024-08-05 17:20:56.290086, excel_file=reports/Daily Revenue Report - Hotel 050824.xlsx, mode=append
2024-08-06 17:22:02,478 [excel.py:1544:create_excel_detail_fb()] INFO: create excel for detail fb >>> for report_date=2024-08-05 17:20:56.290086, excel_file=reports/Daily Revenue Report - Hotel 050824.xlsx, mode=append
2024-08-06 17:22:02,582 [excel.py:587:create_excel_executive_summary()] INFO: create excel for executive summary >>> excel_file=reports/Daily Revenue Report - Hotel 050824.xlsx, mode=append
2024-08-06 17:22:02,583 [excel.py:133:create_excel_section_nagaworld()] INFO: create excel for section nagaworld >>> excel_file=reports/Daily Revenue Report - Hotel 050824.xlsx, sheet=Executive Summary, mode=append
2024-08-06 17:22:02,651 [excel.py:430:create_excel_section_occupancy()] INFO: create excel for section occupancy >>> excel_file=reports/Daily Revenue Report - Hotel 050824.xlsx, sheet=Executive Summary, start_row=9
2024-08-06 17:22:02,706 [excel.py:502:create_excel_section_keydata()] INFO: create excel for section key data >>> excel_file=reports/Daily Revenue Report - Hotel 050824.xlsx, sheet=Executive Summary, start_row=18
2024-08-06 17:22:02,796 [pdf.py:969:create_pdf()] INFO: create pdf >>> report_date=2024-08-05 17:20:56.290086, pdf_file=reports/Daily Revenue Report - Hotel 050824.pdf
2024-08-06 17:22:02,796 [pdf.py:286:create_pdf_summary()] INFO: create pdf for summary >>> report_date=2024-08-05 17:20:56.290086, pdf_file=reports/Daily Revenue Report - Hotel 050824.pdf
2024-08-06 17:22:02,820 [pdf.py:621:create_pdf_detail_room()] INFO: create pdf for detail room >>> report_date=2024-08-05 17:20:56.290086, pdf_file=reports/Daily Revenue Report - Hotel 050824.pdf
2024-08-06 17:22:02,837 [pdf.py:621:create_pdf_detail_room()] INFO: create pdf for detail room >>> report_date=2024-08-05 17:20:56.290086, pdf_file=reports/Daily Revenue Report - Hotel 050824.pdf
2024-08-06 17:22:02,854 [pdf.py:816:create_pdf_detail_fb_section()] INFO: create pdf for a section in detail fb >>> report_date=2024-08-05 17:20:56.290086, pdf_file=reports/Daily Revenue Report - Hotel 050824.pdf
2024-08-06 17:22:02,862 [pdf.py:816:create_pdf_detail_fb_section()] INFO: create pdf for a section in detail fb >>> report_date=2024-08-05 17:20:56.290086, pdf_file=reports/Daily Revenue Report - Hotel 050824.pdf
2024-08-06 17:22:02,991 [email.py:164:send_email()] INFO: send email with the following params: subject=Daily Revenue Report - Hotel 05 August 2024, to=['phannmalinka@nagaworld.com'], cc=None, bcc=None, body=hidden, attachments=2
2024-08-06 17:22:03,236 [email.py:203:send_email()] INFO: email is sent
2024-08-06 17:22:13,247 [email.py:164:send_email()] INFO: send email with the following params: subject=Daily Revenue Report - Hotel 05 August 2024, to=['phannmalinka@nagaworld.com'], cc=None, bcc=None, body=hidden, attachments=1
2024-08-06 17:22:13,326 [email.py:203:send_email()] INFO: email is sent
2024-08-06 17:22:23,337 [email.py:164:send_email()] INFO: send email with the following params: subject=DRR Automation Mails processed successfully, to=['phannmalinka@nagaworld.com'], cc=None, bcc=None, body=hidden, attachments=0
2024-08-06 17:22:23,533 [email.py:203:send_email()] INFO: email is sent
2024-08-06 17:22:23,533 [report.py:264:command_listener_run()] INFO: [Report]: Generate DRR Report for 2024-08-05 17:20:56.290086 end -----------------------
2024-08-06 17:22:23,533 [db.py:340:log_status()] INFO: log status >>> receive at=2024-08-06 17:20:56, status=SUCCESS
2024-08-06 17:22:23,553 [db.py:315:log_status_when_stop()] INFO: log status when command done >>> receive at=2024-08-06 17:20:56, stop at=2024-08-06 17:22:23
```

The recipients will receive at 3 emails.

- A report email with 2 attachments (Excel file and PDF file)
  
  Subject = Daily Revenue Report - Hotel ...
  
  Body:

  ```
  Dear All,
  I attach the Daily Revenue Report - Hotel ... for your reference.
  ...
  ```

- A report email with 1 attachement (PDF file)

  Subject = Daily Revenue Report - Hotel ...
  
  Body:

  ```
  Dear All,
  I attach the Daily Revenue Report - Hotel ... for your reference.
  ...
  ```

- a status-success email

  Subject = DRR Automation Mails processed successfully