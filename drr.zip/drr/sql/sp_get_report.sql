USE [DRR]
GO
/****** Object:  StoredProcedure [dbo].[GetReport]    Script Date: 07/08/2024 09:40:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


ALTER     
 PROCEDURE [dbo].[GetReport]
(
	-- input date
	@inputDate DATETIME = '',

	-- support three sheets
	-- 1. Summary
	-- 2. Detail Room
	-- 3. Detail F&B
	@sheet VARCHAR(20) = '',
	@section varchar(100) = ''
)
AS
BEGIN

	----- BLOCK1 BEGIN -----
	SET NOCOUNT ON;
	DECLARE @DateFrom varchar(10)
	DECLARE @DateTo varchar(10)
	DECLARE @MonthFrom varchar(10)
	DECLARE @MonthTo varchar(10)
	DECLARE @YearFrom varchar(10)
	DECLARE @YearTo varchar(10)

	-- Previous year MTD & YTD values
	DECLARE @pyMonthFrom varchar(10)
	DECLARE @pyMonthTo varchar(10)
	DECLARE @pyYearFrom varchar(10)
	DECLARE @pyYearTo varchar(10)
	DECLARE @pyMonthLastDayTo varchar(10)

	-- For both Day & Month
	DECLARE @PeriodFrom VARCHAR(10)
	DECLARE @PeriodTo VARCHAR(10)

	-- For Year values
	DECLARE @PeriodYearFrom VARCHAR(10)
	DECLARE @PeriodYearTo VARCHAR(10)
	DECLARE @PeriodYearToMinus1 VARCHAR(10)

	-- For Previous Year MTD values
	DECLARE @pyMTDPeriodFrom VARCHAR(10)
	DECLARE @pyMTDPeriodTo VARCHAR(10)

	-- For Year values
	DECLARE @pyYTDPeriodFrom VARCHAR(10)
	DECLARE @pyYTDPeriodTo VARCHAR(10)

	-- store results
	DECLARE @resultTable TABLE
	(
		SheetName VARCHAR(100),
		SectionName varchar(100),
		RowName VARCHAR(100),
		RowCode VARCHAR(100),
		ColumnName VARCHAR(100),
		ColumnCode VARCHAR(100),
		CalcType VARCHAR(20),
		Result FLOAT,
		CellValue varchar(200),
		ExcelColumn varchar(20),
		ExcelRow INT,
		HideRow bit,
		SQL VARCHAR(5000)
	)

	SET @DateFrom = CONVERT(varchar(10), @inputDate, 120)
	SET @DateTo = CONVERT(varchar(10), @inputDate, 120)

	SET @MonthFrom = CONVERT(varchar(10), DATEADD(MM, DATEDIFF(MM, 0, @inputDate), 0), 120)
	SET @MonthTo = CONVERT(varchar(10), @inputDate, 120)
	SET @YearFrom = CONVERT(varchar(10), DATEADD(YY, DATEDIFF(YY, 0, @inputDate), 0), 120)
	SET @YearTo = CONVERT(varchar(10), @inputDate, 120)
	SET @pyMonthFrom = CONVERT(varchar(10), DATEADD(MM, DATEDIFF(MM, 0, DATEADD(YY, -1, @inputDate)), 0), 120)
	SET @pyMonthTo = CONVERT(varchar(10), DATEADD(YY, -1, @inputDate), 120)
	SET @pyMonthLastDayTo = CONVERT(varchar(10), EOMONTH(DATEADD(YY, -1, @inputDate)), 120)

	SET @pyYearFrom = CONVERT(varchar(10), DATEADD(YY, DATEDIFF(YY, 0, DATEADD(YY, -1, @inputDate)), 0), 120)
	SET @pyYearTo = CONVERT(varchar(10), DATEADD(YY, -1, @inputDate), 120)

	SET @PeriodFrom = CAST(CAST(DATEPART(YYYY, @inputDate) as varchar(4)) + RIGHT(REPLICATE('0',3) + CAST(DATEPART(MM, @inputDate) as varchar(3)), 3) as INT)
	SET @PeriodTo = CAST(CAST(DATEPART(YYYY, @inputDate) as varchar(4)) + RIGHT(REPLICATE('0',3) + CAST(DATEPART(MM, @inputDate) as varchar(3)), 3) as INT)

	SET @PeriodYearFrom = CAST(CAST(DATEPART(YYYY, @inputDate) as varchar(4)) + '001' as INT)
	SET @PeriodYearTo = CAST(CAST(DATEPART(YYYY, @inputDate) as varchar(4)) + RIGHT(REPLICATE('0',3) + CAST(DATEPART(MM, @inputDate) as varchar(3)), 3) as INT)
	SET @PeriodYearToMinus1 = @PeriodYearTo - 1

	--SET @pyMTDPeriodFrom = CAST(DATEPART(YYYY, DATEADD(YY, -1, @inputDate)) as varchar(4)) + RIGHT(REPLICATE('0',3) + CAST(DATEPART(MM, DATEADD(YY, -1, @inputDate)) as varchar(3)), 3)
	-- As verified with Hieu, since it is used for Budget calculations we use it from beginning of Previous year beginning instead of Previous Year Month beginning
	SET @pyMTDPeriodFrom = CAST(CAST(DATEPART(YYYY, DATEADD(YY, -1, @inputDate)) as varchar(4)) + '001' as INT)
	SET @pyMTDPeriodTo = CAST(CAST(DATEPART(YYYY, DATEADD(YY, -1, @inputDate)) as varchar(4)) + RIGHT(REPLICATE('0',3) + CAST(DATEPART(MM, DATEADD(YY, -1, @inputDate)) as varchar(3)), 3) as INT)
	SET @pyYTDPeriodFrom = CAST(CAST(DATEPART(YYYY, DATEADD(YY, -1, @inputDate)) as varchar(4)) + '001' as INT)
	SET @pyYTDPeriodTo = CAST(CAST(DATEPART(YYYY, DATEADD(YY, -1, @inputDate)) as varchar(4)) + RIGHT(REPLICATE('0',3) + CAST(DATEPART(MM, DATEADD(YY, -1, @inputDate)) as varchar(3)), 3) as INT)

	DECLARE @sql NVARCHAR(4000)
	DECLARE @sql_param NVARCHAR(1000)
	DECLARE @Calctype varchar(100)
	DECLARE @start_period varchar(100)
	DECLARE @end_period varchar(100)
	DECLARE @start_date varchar(100)
	DECLARE @end_date varchar(100)
	DECLARE @sheetName VARCHAR(100)
	DECLARE @sectionName VARCHAR(100)
	DECLARE @RowName VARCHAR(100)
	DECLARE @CellValue varchar(100)
	DECLARE @columnName VARCHAR(100)
	DECLARE @result VARCHAR(20)
	DECLARE @nResult FLOAT
	DECLARE @PeriodFrom_val VARCHAR(10)
	DECLARE @PeriodTo_val VARCHAR(10)
	DECLARE @DateFrom_val VARCHAR(10)
	DECLARE @DateTo_val VARCHAR(10)
	DECLARE @excelcolumn varchar(20)
	DECLARE @excelrow varchar(20)
	DECLARE @rowcode varchar(100)
	DECLARE @columncode varchar(100)
	DECLARE @HideRow bit

	/*
	1. Read config table
	2. Build SQL statement out of those values
	3. Execute that SQL statement
	*/
	BEGIN

		DECLARE dynamic_sql_cursor CURSOR FOR
		SELECT REPLACE('select @resultOUT = CAST(Sum(AMOUNT) as MONEY) from <tablename> A JOIN NGG_ACNT_ANL_CAT C ON A.ACCNT_CODE = C.ACNT_CODE WHERE C.ANL_CAT_ID = 11 ' + ANL_CODE + ' ' + ACCNT_CODE + ' ' + ANAL_T0 + ' '  + ANAL_T1 + ' ' + PERIOD + ' '  + TRANS_DATETIME + ' ' + ANAL_T3, '<tablename>', TableName)
		, '@resultOUT varchar(20) OUTPUT'
		,CalcType, PeriodFrom, PeriodTo, DateFrom, DateTo, SheetName, RowName, ColumnName, CellValue, ExcelColumn, ExcelRow, SectionName, RowCode, ColumnCode, HideRow
		FROM Config
		WHERE SheetName = @sheet
		AND (@section = '' OR SectionName = @section)
		ORDER BY ExcelRow ASC;

		OPEN dynamic_sql_cursor;
		FETCH NEXT FROM dynamic_sql_cursor
		INTO @sql, @sql_param, @CalcType, @start_period, @end_period, @start_date, @end_date, @sheetName, @RowName, @columnName, @CellValue, @excelcolumn, @excelrow, @sectionName, @rowcode, @columncode, @HideRow;  
		WHILE @@FETCH_STATUS = 0  
		BEGIN  

			SET @result = NULL
			SET @nResult = NULL

			SET @PeriodFrom_val = CASE @start_period WHEN '@PeriodFrom' THEN @PeriodFrom WHEN '@PeriodYearFrom' THEN @PeriodYearFrom WHEN '@pyMTDPeriodFrom' THEN @pyMTDPeriodFrom WHEN '@pyYTDPeriodFrom' THEN @pyYTDPeriodFrom ELSE '' END
			SET @PeriodTo_val = CASE @end_period WHEN '@PeriodTo' THEN @PeriodTo WHEN '@PeriodYearTo' THEN @PeriodTo WHEN '@PeriodYearToMinus1' THEN @PeriodYearToMinus1 WHEN '@pyMTDPeriodTo' THEN @pyMTDPeriodTo WHEN '@pyYTDPeriodTo' THEN @pyYTDPeriodTo ELSE '' END

			SET @DateFrom_val = CASE @start_date WHEN '@DateFrom' THEN @DateFrom WHEN '@MonthFrom' THEN @MonthFrom WHEN '@YearFrom' THEN @YearFrom WHEN '@pyMonthFrom' THEN @pyMonthFrom WHEN '@pyYearFrom' THEN @pyYearFrom ELSE '' END
			SET @DateTo_val = CASE @end_date WHEN '@DateTo' THEN @DateTo WHEN '@MonthTo' THEN @MonthTo WHEN '@YearTo' THEN @YearTo WHEN '@pyMonthTo' THEN @pyMonthTo WHEN '@pyMonthLastDayTo' THEN @pyMonthLastDayTo WHEN '@pyYearTo' THEN @pyYearTo ELSE '' END

			SET @sql = REPLACE(REPLACE(REPLACE(REPLACE(@sql, '<PeriodFrom>', '''' + @PeriodFrom_val + ''''), '<PeriodTo>', '''' + @PeriodTo_val + ''''), '<DateFrom>', '''' + @DateFrom_val + ''''), '<DateTo>', '''' + @DateTo_val + '''')
                                  
			--PRINT @sql
			--print @cellvalue

			-- execute sql for a single row
			IF @CalcType = 'QA'
			BEGIN
				exec sp_executesql @sql, @sql_param, @resultOUT = @result OUTPUT
				SET @nResult = CAST(@result AS FLOAT)
				
				IF @nResult IS NOT NULL AND @nResult < 0 AND ((@sheet = 'Detail Room' AND @columnName NOT LIKE '%Rev') 
				OR (@sheet = 'Summary' AND (@sectionName = 'STATISTICS')))
				BEGIN
					SET @nResult = @nResult * (-1)
				END
			END

			IF @CalcType = 'Formula'
			BEGIN
				SELECT @sql = NULL
					, @nResult = NULL
			END

			--SELECT @RowName,@CellValue, @result
			-- insert result from above sql into table #Results
			INSERT INTO @resultTable (SheetName, SectionName, RowName, RowCode, ColumnName, ColumnCode, CalcType, Result, CellValue, ExcelColumn, ExcelRow, SQL, HideRow)
			VALUES (@sheetName, @sectionName, @RowName, @rowcode, @columnName, @columncode, @Calctype, @nResult, @CellValue, @excelcolumn, @excelrow, @sql, @HideRow)

			-- go to next row and set values to those variables
			FETCH NEXT FROM dynamic_sql_cursor
			INTO @sql, @sql_param, @CalcType, @start_period, @end_period, @start_date, @end_date, @sheetName, @RowName, @columnName, @CellValue, @excelcolumn, @excelrow, @sectionName, @rowcode, @columncode, @HideRow;
		END;  
		CLOSE dynamic_sql_cursor;  
		DEALLOCATE dynamic_sql_cursor;

		SELECT * INTO #Result FROM @resultTable

	END
	----- BLOCK1 END -----


	----- BLOCK2 BEGIN -----
	-- Summary
	IF @sheet='Summary'
	BEGIN

		-- Row 31
		BEGIN
			update #Result set Result=0 where SheetName='Summary' and ExcelRow=31 and ExcelColumn IN ('B','C','D','F','G','H','Q','R','S','W','Y')

			-- update O31
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Summary' and CellValue='M31'),0) as m31, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and CellValue='N31'),0) as n31
			from #Result t1
			where sheetname='Summary'
			and CellValue='O31'
			and CalcType='Formula'
			)
			--SELECT *, m31+n31 FROM cte order by CellValue
			update cte set Result=m31+n31

			--select * from #Result where SheetName='Summary' and ExcelRow=31 order by ExcelColumn
		END

		-- Column J
		-- Except 15,20,32,34,44,46,52,53,57
		BEGIN
			-- J12 = O12 * J3/J4

			--DECLARE @inputDate1 DATETIME = '2024-04-01'
			DECLARE @J3 Int = DAY(@inputDate)
			DECLARE @J4 INT = DAY(EOMONTH(@inputDate))

			UPDATE #Result
			SET Result = ISNULL((SELECT t2.Result FROM #Result t2 WHERE t2.SheetName = 'Summary' AND ExcelColumn = 'O' 
			AND ExcelRow = RIGHT(t1.CellValue ,2)),0) * @J3 / @J4
			FROm #Result t1
			WHERE SheetName = 'Summary'
			AND ExcelColumn = 'J'
			AND ExcelRow NOT IN (14,20,32,34,44,46,52,53,57)
			AND CalcType = 'Formula'

			-- Cell J14
			-- J14 = J15-J12
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Summary' and CellValue='J12'),0) as j12, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and CellValue='J15'),0) as j15
			from #Result t1
			where sheetname='Summary'
			and CellValue='J14'
			and CalcType='Formula'
			)
			--SELECT *, j12-j14 FROM cte order by cellvalue 
			UPDATE cte SET REsult = j15-j12

			--select * from #Result where sheetname='Summary' and ExcelColumn = 'J' order by excelrow
		END

		-- Column K
		-- Except 46,57
		BEGIN
			--K12 = (H15-J15)/J15
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Summary' and ExcelColumn='H' AND ExcelRow = RIGHT(t1.CellValue,2)),0) as h, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and ExcelColumn='J' AND ExcelRow = RIGHT(t1.CellValue,2)),0) as j
			from #Result t1
			where sheetname='Summary'
			and ExcelColumn='K'
			and CalcType='Formula'
			)
			--SELECT *, CAST((h -j)* 1.0 / j * 100 as DECIMAL(5,1)) FROM cte order by cellvalue 
			UPDATE cte 
			SET REsult = CASE WHEN j=0 THEN 0.0 ELSE ((h-j)/j) END WHERE ExcelRow NOT IN (46,57)
			--select * from #Result where sheetname='Summary' and ExcelColumn='K' order by excelrow
			--select * from #Result where sheetname='Summary' and CellValue in ('H20','J20', 'K20')
		END

		-- Column T
		-- Except 12,14,20,32,34,44,46,50,52,53,55,57
		BEGIN
			-- T12 = J12 + QA
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #Result t2 where t2.sheetname = t1.sheetname and t2.ExcelColumn = 'J' AND t2.ExcelRow=t1.ExcelRow),0) as j,
			ISNULL((select t3.Result from #Result t3 where t3.sheetname = t1.sheetname and t3.ExcelColumn = 'T' AND t3.ExcelRow=t1.ExcelRow),0) as t
			from #Result t1
			where t1.sheetname='Summary' and t1.ExcelColumn = 'T'
			and CalcType='QA'
			)
			--SELECT *, j+t FROM cte order by cellvalue 
			--update cte set Result = j+t where ExcelRow NOT IN (14,15,20,32,34,44,46,50,52,53,55,57)
			update cte set Result = j+t where ExcelRow NOT IN (12,14,20,32,34,44,46,50,52,53,55,57)


			-- T14 = T15-T12
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #Result t2 where t2.sheetname = t1.sheetname and t2.CellValue='T12'),0) as t12,
			ISNULL((select t3.Result from #Result t3 where t3.sheetname = t1.sheetname and t3.CellValue='T15'),0) as t15
			from #Result t1
			where t1.sheetname='Summary' and t1.CellValue = 'T14'
			and t1.CalcType='Formula'
			)
			--SELECT *, t12-t14 FROM cte order by cellvalue 
			update cte set Result = t15-t12

			-- T53 = T15*1000/T43
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #Result t2 where t2.sheetname = t1.sheetname and t2.CellValue='T15'),0) as t15,
			ISNULL((select t3.Result from #Result t3 where t3.sheetname = t1.sheetname and t3.CellValue='T43'),0) as t43
			from #Result t1
			where t1.sheetname='Summary' and t1.CellValue = 'T53'
			and t1.CalcType='Formula'
			)
			--SELECT *, CAST((t15)* 1.0 / t43 as DECIMAL(10,2)) FROM cte
			update cte set Result= CASE WHEN t43=0 THEN 0.00 ELSE CAST((t15)* 1.0 / t43 as DECIMAL(10,2)) END

			-- select * from #Result where SheetName='Summary' and CellValue IN ('T15','T43','T53')
		END

		-- Column U
		-- Except 46,57
		BEGIN
			-- U12 = (S12-T12)/T12
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Summary' and t2.ExcelColumn='S' AND t2.ExcelRow = RIGHT(t1.CellValue,2)),0) as s, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and t3.ExcelColumn='T' AND t3.ExcelRow = RIGHT(t1.CellValue,2)),0) as t
			from #Result t1
			where sheetname='Summary'
			and ExcelColumn='U'
			and CalcType='Formula'
			and ExcelRow NOT IN (46,57)
			)
			--SELECT *, CASE WHEN t=0 THEN 0.1 ELSE (s-t)/t END FROM cte order by cellvalue 
			UPDATE cte SET Result = CASE WHEN t=0 THEN 0.0 ELSE ((s-t)/t) END

			--select * from #Result where sheetname='Summary' and ExcelColumn = 'U' order by excelrow
			--select * from #Result where CellValue In ('S55', 'T55', 'U55')

		END

		-- Column X
		-- Except 46,57
		BEGIN
			-- X12 = (H12-W12)/W12
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Summary' and ExcelColumn='H' AND ExcelRow = t1.ExcelRow),0) as h, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and ExcelColumn='W' AND ExcelRow = t1.ExcelRow),0) as w
			from #Result t1
			where sheetname='Summary'
			and ExcelColumn='X'
			and CalcType='Formula'
			)
			--SELECT *, CASE WHEN w=0 THEN 0.0 ELSE CAST((h-w)*1.0/w*100 as DECIMAL(10,1)) END FROM cte order by cellvalue 
			UPDATE cte 
			SET REsult = 
			CASE WHEN ExcelRow BETWEEN 12 AND 19 THEN 
				CASE WHEN ROUND(w/1000,0)=0 
				THEN 0.0 ELSE ((h-w)/w) END
			ELSE 
				CASE WHEN w=0 
				THEN 0.0 ELSE ((h-w)/w) END
			END
			WHERE ExcelRow NOT IN (46,57)
			--select * from #Result where SheetName='Summary' and ExcelColumn='X' order by ExcelRow
		END

		-- Column Z
		-- Except 46,57
		BEGIN
			-- Z12 = (S12-Y12)/Y12)
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Summary' and ExcelColumn='S' AND ExcelRow = RIGHT(t1.CellValue,2)),0) as s, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and ExcelColumn='Y' AND ExcelRow = RIGHT(t1.CellValue,2)),0) as y
			from #Result t1
			where sheetname='Summary'
			and ExcelColumn='Z'
			and CalcType='Formula'
			)
			--SELECT *, CAST((s - y)* 1.0 / y * 100 as DECIMAL(10,1)) FROM cte order by cellvalue 
			UPDATE cte 
			SET REsult = CASE WHEN y=0 THEN 0.0 ELSE ((s-y)/y) END WHERE ExcelRow NOT IN (46,57)

			--select * from #Result where SheetName='Summary' and ExcelColumn='Z' order by ExcelRow

		END 

		-- Row 20
		-- B20 = SUM(B16:B19)
		-- Except K,U,X,Z
		BEGIN
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Summary' and t2.ExcelColumn=t1.ExcelColumn AND t2.ExcelRow=t1.ExcelRow-4),0) as _16, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and t3.ExcelColumn=t1.ExcelColumn AND t3.ExcelRow=t1.ExcelRow-3),0) as _17,
			ISNULL((select t4.Result from #result t4 where t4.SheetName='Summary' and t4.ExcelColumn=t1.ExcelColumn AND t4.ExcelRow=t1.ExcelRow-2),0) as _18,
			ISNULL((select t5.Result from #result t5 where t5.SheetName='Summary' and t5.ExcelColumn=t1.ExcelColumn AND t5.ExcelRow=t1.ExcelRow-1),0) as _19
			from #Result t1
			where sheetname='Summary'
			and ExcelRow=20
			and CalcType='Formula'
			)
			--SELECT *, _16+_17+_18+_19 FROM cte where ExcelColumn NOT IN ('K','U','X','Z') order by CellValue
			UPDATE cte SET REsult = _16+_17+_18+_19 where ExcelColumn NOT IN ('K','U','X','Z')
			--select * from #Result where sheetname='Summary' and Excelrow=20 order by CellValue
		END

		-- Row 32
		-- B32 = SUM(B22:B31)
		-- Except K,U,X,Z
		BEGIN
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Summary' and t2.ExcelColumn=t1.ExcelColumn AND t2.ExcelRow=t1.ExcelRow-10),0) as _22, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and t3.ExcelColumn=t1.ExcelColumn AND t3.ExcelRow=t1.ExcelRow-9),0) as _23,
			ISNULL((select t4.Result from #result t4 where t4.SheetName='Summary' and t4.ExcelColumn=t1.ExcelColumn AND t4.ExcelRow=t1.ExcelRow-8),0) as _24,
			ISNULL((select t5.Result from #result t5 where t5.SheetName='Summary' and t5.ExcelColumn=t1.ExcelColumn AND t5.ExcelRow=t1.ExcelRow-7),0) as _25,
			ISNULL((select t6.Result from #result t6 where t6.SheetName='Summary' and t6.ExcelColumn=t1.ExcelColumn AND t6.ExcelRow=t1.ExcelRow-6),0) as _26,
			ISNULL((select t7.Result from #result t7 where t7.SheetName='Summary' and t7.ExcelColumn=t1.ExcelColumn AND t7.ExcelRow=t1.ExcelRow-5),0) as _27,
			ISNULL((select t8.Result from #result t8 where t8.SheetName='Summary' and t8.ExcelColumn=t1.ExcelColumn AND t8.ExcelRow=t1.ExcelRow-4),0) as _28,
			ISNULL((select t9.Result from #result t9 where t9.SheetName='Summary' and t9.ExcelColumn=t1.ExcelColumn AND t9.ExcelRow=t1.ExcelRow-3),0) as _29,
			ISNULL((select t10.Result from #result t10 where t10.SheetName='Summary' and t10.ExcelColumn=t1.ExcelColumn AND t10.ExcelRow=t1.ExcelRow-2),0) as _30,
			ISNULL((select t11.Result from #result t11 where t11.SheetName='Summary' and t11.ExcelColumn=t1.ExcelColumn AND t11.ExcelRow=t1.ExcelRow-1),0) as _31
			from #Result t1
			where sheetname='Summary'
			and ExcelRow=32
			and CalcType='Formula'
			)
			--SELECT *, _22+_23+_24+_25+_26+_27+_28+_29+_30+_31 FROM cte order by CellValue
			UPDATE cte SET REsult = _22+_23+_24+_25+_26+_27+_28+_29+_30+_31 WHERE ExcelColumn NOT IN ('K','U','X','Z')

			--select * from #Result where sheetname='Summary' and Excelrow=32 order by CellValue
		END

		-- Row 34
		-- B34 = B32+B20+B12
		-- Except K,U,X,Z
		BEGIN
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Summary' and t2.ExcelColumn=t1.ExcelColumn AND t2.ExcelRow=t1.ExcelRow-2),0) as _32, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and t3.ExcelColumn=t1.ExcelColumn AND t3.ExcelRow=t1.ExcelRow-14),0) as _20,
			ISNULL((select t4.Result from #result t4 where t4.SheetName='Summary' and t4.ExcelColumn=t1.ExcelColumn AND t4.ExcelRow=t1.ExcelRow-19),0) as _15
			from #Result t1
			where sheetname='Summary'
			and ExcelRow=34
			and CalcType='Formula'
			)
			--SELECT *, _32+_20+_12 FROM cte order by CellValue
			UPDATE cte SET REsult = _32+_20+_15 WHERE ExcelColumn NOT IN ('K','U','X','Z')

			--select * from #Result where sheetname='Summary' and Excelrow=34 order by ExcelColumn
		
		END

		-- Row 36
		-- B36 = B34+B35
		BEGIN
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Summary' and t2.ExcelColumn=t1.ExcelColumn AND t2.ExcelRow=t1.ExcelRow-2),0) as _34, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and t3.ExcelColumn=t1.ExcelColumn AND t3.ExcelRow=t1.ExcelRow-1),0) as _35
			from #Result t1
			where sheetname='Summary'
			and ExcelRow=36
			and CalcType='Formula'
			)
			--SELECT *, _32+_20+_12 FROM cte order by CellValue
			UPDATE cte SET REsult = _34+_35 WHERE ExcelColumn NOT IN ('K','U','X','Z')

			--select * from #Result where SheetName='Summary' and ExcelRow=36 order by ExcelColumn
			--select * from #Result where cellvalue in ('H36','J36','K36')
		END

		-- Row 44
		-- B44 = B43-(B48+B49+B50)
		-- Except K,U,X,Z
		BEGIN
			; with cte as (
			select *, 
			 ISNULL((select t2.Result from #result t2 where t2.SheetName='Summary' and t2.ExcelRow=t1.ExcelRow-1 and t2.ExcelColumn=t1.ExcelColumn),0) as _43,
			 ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and t3.ExcelRow=t1.ExcelRow+4 and t3.ExcelColumn=t1.ExcelColumn),0) as _48,
			 ISNULL((select t4.Result from #result t4 where t4.SheetName='Summary' and t4.ExcelRow=t1.ExcelRow+5 and t4.ExcelColumn=t1.ExcelColumn),0) as _49,
			 ISNULL((select t5.Result from #result t5 where t5.SheetName='Summary' and t5.ExcelRow=t1.ExcelRow+6 and t5.ExcelColumn=t1.ExcelColumn),0) as _50
			from #Result t1
			where sheetname='Summary'
			and ExcelRow=44
			)
			--SELECT *, _43 - _48 - _49 - _50 FROM cte order by cellvalue 
			UPDATE cte SET REsult=_43 - _48 - _49 - _50 WHERE ExcelColumn NOT IN ('K','U','X','Z')

			--select * from #Result where sheetname='Summary'and ExcelRow=44 order by ExcelColumn
		END

		-- Row 46
		-- B46 = B45/B44
		-- Except K,U,X,Z
		BEGIN
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Summary' and t2.ExcelRow=t1.ExcelRow-1 and ExcelColumn = t1.ExcelColumn),0) as _45,
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and t3.ExcelRow=t1.ExcelRow-2 and ExcelColumn = t1.ExcelColumn),0) as _44
			from #Result t1
			where sheetname='Summary'
			and ExcelRow=46
			and CalcType='Formula'
			)
			--SELECT *, CASE WHEN _44=0 THEN 0.0 ELSE CAST(_45* 1.0 / _44 * 100 as DECIMAL(10,1)) END FROM cte order by cellvalue
			UPDATE cte SET REsult = CASE WHEN _44=0 THEN 0.0 ELSE _45/_44 END WHERE ExcelColumn NOT IN ('K','U','X','Z')

			--select * from #Result where SheetName='Summary' and ExcelRow=46 order by ExcelRow, ExcelColumn
		END

		-- Row 52
		-- B52 = B15/B45
		-- F52 = F15*1000/F45
		-- But both of them produce the same result if use only 1 formula
		BEGIN
			; with cte as (
			select *, 
			ISNULL((select t2.Result from Staging.Summary_Revenue_Result t2 where t2.SheetName='Summary' and t2.ExcelRow=14 and ExcelColumn = t1.ExcelColumn),0) as _14,
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and t3.ExcelRow=45 and ExcelColumn = t1.ExcelColumn),0) as _45
			from #Result t1
			where sheetname='Summary'
			and ExcelRow=52
			and CalcType='Formula'
			and ExcelColumn NOT IN ('K','U','X','Z')
			)
			--SELECT *, CASE WHEN _45=0 THEN 0.00 ELSE CAST(_15* 1.00 / _45 as DECIMAL(10,2)) END FROM cte order by cellvalue
			UPDATE cte SET REsult = CASE WHEN _45=0 THEN 0.00 ELSE _14/_45 END

			--select * from Staging.Summary_Revenue_Result where SheetName='Summary' and CellValue IN ('J15')
			--select * from Staging.Summary_raw order by excelrow
		END

		-- Row 53
		-- B53 = B14/B43
		BEGIN
			; with cte as (
			select *, 
			ISNULL((select t2.Result from Staging.Summary_Revenue_Result t2 where t2.SheetName='Summary' and t2.ExcelRow=14 and t2.ExcelColumn = t1.ExcelColumn),0) as _14,
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and t3.ExcelRow=43 and t3.ExcelColumn = t1.ExcelColumn),0) as _43
			from #Result t1
			where sheetname='Summary'
			and ExcelRow=53
			and CalcType='Formula'
			and ExcelColumn NOT IN ('K','U','X','Z')
			)
			--SELECT *, CASE WHEN _43=0 THEN 0.00 ELSE _14/_43 END FROM cte order by cellvalue
			UPDATE cte SET REsult = CASE WHEN _43=0 THEN 0.00 ELSE _14/_43 END

			--select * from Staging.Summary_raw where ExcelColumn = 'T' and ExcelRow = 14
			--select * from #Result where ExcelColumn = 'T' and ExcelRow IN (14, 43)

			--update Config set CalcType='Formula' where RowName='Room Yield (External Revenues/Physical Rooms)' and cellvalue='T53'

		END

		-- Row 57
		-- B57 = B56/(B45+B50)
		BEGIN
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Summary' and t2.ExcelRow=t1.ExcelRow-1 and t2.ExcelColumn = t1.ExcelColumn),0) as _56,
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and t3.ExcelRow=t1.ExcelRow-12 and t3.ExcelColumn = t1.ExcelColumn),0) as _45,
			ISNULL((select t4.Result from #result t4 where t4.SheetName='Summary' and t4.ExcelRow=t1.ExcelRow-7 and t4.ExcelColumn = t1.ExcelColumn),0) as _50
			from #Result t1
			where sheetname='Summary'
			and ExcelRow=57
			and CalcType='Formula'
			and ExcelColumn NOT IN ('K','U','X','Z')
			)
			--SELECT *, CASE WHEN _45=0 THEN 0.00 ELSE CAST(_56* 1.00 / (_45+_50) as DECIMAL(10,2)) END FROM cte order by cellvalue
			UPDATE cte SET REsult = CASE WHEN _45=0 THEN 0.00 ELSE _56/(_45+_50) END

			--select * from #Result where SheetName='Summary' and ExcelRow=52 order by ExcelRow, ExcelColumn

			--update config set CalcType='Formula' where rowname='Sleeper Density' and CellValue='T57'
		END

		-- Column K again
		-- Except 46,57
		BEGIN
			--K12 = (H15-J15)/J15
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Summary' and ExcelColumn='H' AND ExcelRow = RIGHT(t1.CellValue,2)),0) as h, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and ExcelColumn='J' AND ExcelRow = RIGHT(t1.CellValue,2)),0) as j
			from #Result t1
			where sheetname='Summary'
			and ExcelColumn='K'
			and CalcType='Formula'
			)
			--SELECT *, CAST((h -j)* 1.0 / j * 100 as DECIMAL(5,1)) FROM cte order by cellvalue 
			UPDATE cte 
			SET REsult = CASE WHEN j=0 THEN 0.0 ELSE ((h-j)/j) END WHERE ExcelRow NOT IN (46,57)
			--select * from #Result where sheetname='Summary' and ExcelColumn='K' order by excelrow
			--select * from #Result where sheetname='Summary' and CellValue in ('H20','J20', 'K20')

		END

		-- Column X again
		-- Except 46,57
		BEGIN
			-- X12 = (H12-W12)/W12
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Summary' and ExcelColumn='H' AND ExcelRow = t1.ExcelRow),0) as h, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and ExcelColumn='W' AND ExcelRow = t1.ExcelRow),0) as w
			from #Result t1
			where sheetname='Summary'
			and ExcelColumn='X'
			and CalcType='Formula'
			)
			--SELECT *, CASE WHEN w=0 THEN 0.0 ELSE CAST((h-w)*1.0/w*100 as DECIMAL(10,1)) END FROM cte order by cellvalue 
			UPDATE cte 
			SET REsult = 
			CASE WHEN ExcelRow BETWEEN 12 AND 19 THEN 
				CASE WHEN ROUND(w/1000,0)=0 
				THEN 0.0 ELSE ((h-w)/w) END
			ELSE 
				CASE WHEN w=0 
				THEN 0.0 ELSE ((h-w)/w) END
			END
			WHERE ExcelRow NOT IN (46,57)
			--select * from #Result where SheetName='Summary' and ExcelColumn='X' order by ExcelRow
		END

		-- Column Z again
		-- Except 46,57
		BEGIN
			-- Z12 = (S12-Y12)/Y12)
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Summary' and ExcelColumn='S' AND ExcelRow = RIGHT(t1.CellValue,2)),0) as s, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and ExcelColumn='Y' AND ExcelRow = RIGHT(t1.CellValue,2)),0) as y
			from #Result t1
			where sheetname='Summary'
			and ExcelColumn='Z'
			and CalcType='Formula'
			)
			--SELECT *, CAST((s - y)* 1.0 / y * 100 as DECIMAL(10,1)) FROM cte order by cellvalue 
			UPDATE cte 
			SET REsult = CASE WHEN y=0 THEN 0.0 ELSE ((s-y)/y) END WHERE ExcelRow NOT IN (46,57)

			--select * from #Result where SheetName='Summary' and ExcelColumn='Z' order by ExcelRow

		END 

		-- Special Cells
		BEGIN

			-- K46 = H46-J46
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Summary' and t2.CellValue='H46'),0) as h46, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and t3.CellValue='J46'),0) as j46
			from #Result t1
			where sheetname='Summary'
			and CellValue='K46'
			and CalcType='Formula'
			)
			--SELECT *, CAST((h -j)* 1.0 / j * 100 as DECIMAL(5,1)) FROM cte order by cellvalue 
			UPDATE cte SET REsult = h46-j46

			-- K57 = H57-J57
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Summary' and t2.CellValue='H57'),0) as h57, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and t3.CellValue='J57'),0) as j57
			from #Result t1
			where sheetname='Summary'
			and CellValue='K57'
			and CalcType='Formula'
			)
			--SELECT *, CAST((h -j)* 1.0 / j * 100 as DECIMAL(5,1)) FROM cte order by cellvalue 
			UPDATE cte SET REsult = h57-j57

			-- M55=M45
			UPDATE #Result
			SET Result = ISNULL((SELECT t2.Result FROM #Result t2 WHERE t2.SheetName = 'Summary' AND CellValue='M45'),0)
			FROm #Result t1
			WHERE SheetName = 'Summary'
			AND CellValue='M55'
			AND CalcType = 'Formula'

			--N55=N45
			UPDATE #Result
			SET Result = ISNULL((SELECT t2.Result FROM #Result t2 WHERE t2.SheetName = 'Summary' AND CellValue='N45'),0)
			FROm #Result t1
			WHERE SheetName = 'Summary'
			AND CellValue='N55'
			AND CalcType = 'Formula'

			--T55=T45
			UPDATE #Result
			SET Result = ISNULL((SELECT t2.Result FROM #Result t2 WHERE t2.SheetName = 'Summary' AND CellValue='T45'),0)
			FROm #Result t1
			WHERE SheetName = 'Summary'
			AND CellValue='T55'
			AND CalcType = 'Formula'

			-- U46 = S46-T46
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Summary' and t2.CellValue='S46'),0) as s46, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and t3.CellValue='T46'),0) as t46
			from #Result t1
			where sheetname='Summary'
			and CellValue='U46'
			and CalcType='Formula'
			)
			--SELECT *,  s46-t46 FROM cte order by ExcelRow, ExcelColumn 
			UPDATE cte SET REsult = s46-t46

			-- U57 = S57-T57
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Summary' and t2.CellValue='S57'),0) as s57, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and t3.CellValue='T57'),0) as t57
			from #Result t1
			where sheetname='Summary'
			and CellValue='U57'
			and CalcType='Formula'
			)
			--SELECT *,  s57-t57 FROM cte order by ExcelRow, ExcelColumn 
			UPDATE cte SET REsult = s57-t57

			-- X46 = H46-W46
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Summary' and t2.CellValue='H46'),0) as h46, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and t3.CellValue='W46'),0) as w46
			from #Result t1
			where sheetname='Summary'
			and CellValue='X46'
			and CalcType='Formula'
			)
			--SELECT *,  s57-t57 FROM cte order by ExcelRow, ExcelColumn 
			UPDATE cte SET REsult = h46-w46

			-- X57 = H57-W57
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Summary' and t2.CellValue='H57'),0) as h57, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and t3.CellValue='W57'),0) as w57
			from #Result t1
			where sheetname='Summary'
			and CellValue='X57'
			and CalcType='Formula'
			)
			--SELECT *,  s57-t57 FROM cte order by ExcelRow, ExcelColumn 
			UPDATE cte SET REsult = h57-w57

			-- Z46 = S46-Y46
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Summary' and t2.CellValue='S46'),0) as s46, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and t3.CellValue='Y46'),0) as y46
			from #Result t1
			where sheetname='Summary'
			and CellValue='Z46'
			and CalcType='Formula'
			)
			--SELECT *,  s57-t57 FROM cte order by ExcelRow, ExcelColumn 
			UPDATE cte SET REsult = s46-y46

			-- Z57 = S57-Y57
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Summary' and t2.CellValue='S57'),0) as s57, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and t3.CellValue='Y57'),0) as y57
			from #Result t1
			where sheetname='Summary'
			and CellValue='Z57'
			and CalcType='Formula'
			)
			--SELECT *,  s57-t57 FROM cte order by ExcelRow, ExcelColumn 
			UPDATE cte SET REsult = s57-y57

		END

		-- Column U again
		-- Except 46,57
		BEGIN
			-- U12 = (S12-T12)/T12
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Summary' and t2.ExcelColumn='S' AND t2.ExcelRow = RIGHT(t1.CellValue,2)),0) as s, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Summary' and t3.ExcelColumn='T' AND t3.ExcelRow = RIGHT(t1.CellValue,2)),0) as t
			from #Result t1
			where sheetname='Summary'
			and ExcelColumn='U'
			and CalcType='Formula'
			and ExcelRow NOT IN (46,57)
			)
			--SELECT *, CASE WHEN t=0 THEN 0.0 ELSE ((s-t)/t) END FROM cte order by cellvalue 
			UPDATE cte SET Result = CASE WHEN t=0 THEN 0.0 ELSE ((s-t)/t) END
			--select * from #Result where sheetname='Summary' and ExcelColumn = 'U' order by excelrow
		END

		-- Copy revenue data into a temporary table to be used later
		BEGIN
			IF @section = 'Revenue' OR @section = ''
			BEGIN
				DROP TABLE IF EXISTS Staging.Summary_Revenue_Result
				SELECT * INTO Staging.Summary_Revenue_Result FROM #Result
				WHERE SectionName='Revenue'
			END
		END

		-- Round Values
		BEGIN
			
			-- Delete existing data for that section
			DELETE FROM Staging.Summary_raw WHERE (@section='' OR SectionName=@section)
			DELETE FROM Staging.Summary WHERE (@section='' OR SectionName=@section)

			INSERT INTO Staging.Summary_raw
			SELECT SheetName, SectionName, RowName, ExcelRow, HideRow, [B],[C],[D],[F],[G],[H],[J],[K],[M],[N],[O],[Q],[R],[S],[T],[U],[W],[X],[Y],[Z] -- Need to add all columns
			FROM (
			SELECt SheetName, SectionName, RowName, Result, ExcelRow, ExcelColumn, HideRow
			FROM #Result
			) as src
			PIVOT
			(
			MAX(Result)
			FOR ExcelColumn IN ([B],[C],[D],[F],[G],[H],[J],[K],[M],[N],[O],[Q],[R],[S],[T],[U],[W],[X],[Y],[Z]) -- Need to add all columns
			) as pvt
			ORDER BY ExcelROw

			-- Copy from raw table to rounded table
			INSERT INTO Staging.Summary SELECT * FROM Staging.Summary_raw WHERE (@section='' OR SectionName=@section)
			
			-- Replace 0 with null
			UPDATE Staging.Summary SET B = NULL WHERE B = 0
			UPDATE Staging.Summary SET C = NULL WHERE C = 0
			UPDATE Staging.Summary SET D = NULL WHERE D = 0
			UPDATE Staging.Summary SET F = NULL WHERE F = 0
			UPDATE Staging.Summary SET G = NULL WHERE G = 0
			UPDATE Staging.Summary SET H = NULL WHERE H = 0
			UPDATE Staging.Summary SET J = NULL WHERE J = 0
			UPDATE Staging.Summary SET K = NULL WHERE K = 0
			UPDATE Staging.Summary SET M = NULL WHERE M = 0
			UPDATE Staging.Summary SET N = NULL WHERE N = 0
			UPDATE Staging.Summary SET O = NULL WHERE O = 0
			UPDATE Staging.Summary SET Q = NULL WHERE Q = 0
			UPDATE Staging.Summary SET R = NULL WHERE R = 0
			UPDATE Staging.Summary SET S = NULL WHERE S = 0
			UPDATE Staging.Summary SET T = NULL WHERE T = 0
			UPDATE Staging.Summary SET U = NULL WHERE U = 0
			UPDATE Staging.Summary SET W = NULL WHERE W = 0
			UPDATE Staging.Summary SET X = NULL WHERE X = 0
			UPDATE Staging.Summary SET Y = NULL WHERE Y = 0
			UPDATE Staging.Summary SET Z = NULL WHERE Z = 0

			-- Revenue
			UPDATE Staging.Summary SET 
			B = ROUND(B, 0), C = ROUND(C, 0), D = ROUND(D, 0), 
			F = ROUND(F/1000, 0), G = ROUND(G/1000, 0), H = ROUND(H/1000, 0),
			J = ROUND(J/1000, 0), 
			K = ROUND(K, 3), 
			M = ROUND(M/1000, 0), N = ROUND(N/1000, 0), O = ROUND(O/1000, 0),
			Q = ROUND(Q/1000, 0), R = ROUND(R/1000, 0), S = ROUND(S/1000, 0),
			T = ROUND(T/1000, 0), 
			U = ROUND(U, 3),
			W = ROUND(W/1000, 0), 
			X = ROUND(X, 3),
			Y = ROUND(Y/1000, 0),
			Z = ROUND(Z, 3)
			WHERE ExcelRow < 43
			
			-- Statistics
			UPDATE Staging.Summary SET 
			B = ROUND(B, 0), C = ROUND(C, 0), D = ROUND(D, 0), 
			F = ROUND(F, 0), G = ROUND(G, 0), H = ROUND(H, 0),
			J = ROUND(J, 0), 
			K = ROUND(K, 3), 
			M = ROUND(M, 0), N = ROUND(N, 0), O = ROUND(O, 0),
			Q = ROUND(Q, 0), R = ROUND(R, 0), S = ROUND(S, 0),
			T = ROUND(T, 0), 
			U = ROUND(U, 3),
			W = ROUND(W, 0), 
			X = ROUND(X, 3), 
			Y = ROUND(Y, 0),
			Z = ROUND(Z, 3)
			WHERE ExcelRow >= 43 AND ExcelRow NOT IN (46, 52, 53, 57)

			-- Row 46 is percentage
			UPDATE Staging.Summary SET 
			B = ROUND(B, 3), C = ROUND(C, 3), D = ROUND(D, 3), 
			F = ROUND(F, 3), G = ROUND(G, 3), H = ROUND(H, 3),
			J = ROUND(J, 3), 
			K = ROUND(K, 3), 
			M = ROUND(M, 3), N = ROUND(N, 3), O = ROUND(O, 3),
			Q = ROUND(Q, 3), R = ROUND(R, 3), S = ROUND(S, 3),
			T = ROUND(T, 3), 
			U = ROUND(U, 3),
			W = ROUND(W, 3), 
			X = ROUND(X, 3), 
			Y = ROUND(Y, 3),
			Z = ROUND(Z, 3)
			WHERE ExcelRow = 46

			-- Row 52, 53 are percentage
			UPDATE Staging.Summary SET 
			B = ROUND(B, 2), C = ROUND(C, 2), D = ROUND(D, 2), 
			F = ROUND(F, 2), G = ROUND(G, 2), H = ROUND(H, 2),
			J = ROUND(J, 2), 
			K = ROUND(K, 3), 
			M = ROUND(M, 2), N = ROUND(N, 2), O = ROUND(O, 2),
			Q = ROUND(Q, 2), R = ROUND(R, 2), S = ROUND(S, 2),
			T = ROUND(T, 2),
			
			-- column U is a percentage, and it has 3 decimal points
			U = ROUND(U, 3),

			W = ROUND(W, 2),
			X = ROUND(X, 3),
			Y = ROUND(Y, 2),
			Z = ROUND(Z, 3)
			WHERE ExcelRow IN (52, 53)

			UPDATE Staging.Summary SET 
			B = ROUND(B, 2), C = ROUND(C, 2), D = ROUND(D, 2), 
			F = ROUND(F, 2), G = ROUND(G, 2), H = ROUND(H, 2),
			J = ROUND(J, 2), 
			K = ROUND(K, 2), 
			M = ROUND(M, 2), N = ROUND(N, 2), O = ROUND(O, 2),
			Q = ROUND(Q, 2), R = ROUND(R, 2), S = ROUND(S, 2),
			T = ROUND(T, 2),
			
			-- column U is a percentage
			U = ROUND(U, 2),

			W = ROUND(W, 2),
			X = ROUND(X, 2),
			Y = ROUND(Y, 2),
			Z = ROUND(Z, 2)
			WHERE ExcelRow = 57

		END

		-- update HideRow = 1 if all values are NULL
		UPDATE Staging.Summary
		SET HideRow = 1
		WHERE ISNULL(B,0) + ISNULL(C,0) + ISNULL(D,0) + ISNULL(F,0) + ISNULL(G,0) + ISNULL(H,0) + ISNULL(J,0) + ISNULL(K,0) + ISNULL(M,0) + ISNULL(N,0) + 
		ISNULL(O,0) + ISNULL(Q,0) + ISNULL(R,0) + ISNULL(S,0) + ISNULL(T,0) + ISNULL(U,0) + ISNULL(W,0) + ISNULL(X,0) + ISNULL(Y,0) + ISNULL(Z,0) = 0
		AND RowName NOT IN ('F&B Revenue', 'Others Revenue', 'TOTAL HOTEL REVENUE', 'House Use Rooms')

		SELECt * FROM Staging.Summary WHERE (@section = '' OR SectionName=@section) ORDER BY ExcelRow ASC
	END
	----- BLOCK2 END -----


	----- BLOCK3 BEGIN -----
	-- Detail Room
	IF @sheet='Detail Room'
	BEGIN
		-- Column D
		-- D12 = E12/C12
		BEGIN
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Detail Room' and t2.ExcelColumn='E' AND ExcelRow = t1.ExcelRow),0) as e,
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Detail Room' and t3.ExcelColumn='C' AND ExcelRow = t1.ExcelRow),0) as c
			from #Result t1
			where sheetname='Detail Room'
			and ExcelColumn='D'
			and CalcType='Formula'
			)
			--SELECT *, CASE WHEN c = 0 THEN 0.00 ELSE e/c END
			--FROM cte
			--order by ExcelRow, ExcelColumn 
			UPDATE cte 
			SET REsult = CASE WHEN c = 0 THEN 0.00 ELSE e/c END

			--select * from #result where sheetname='Detail Room' and CellValue IN ('E102', 'C102', 'D102')
			--order by ExcelRow
		END

		-- Column G
		-- G12 = H12/F12
		BEGIN
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Detail Room' and t2.ExcelColumn='H' AND t2.ExcelRow = t1.ExcelRow),0) as h,
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Detail Room' and t3.ExcelColumn='F' AND t3.ExcelRow = t1.ExcelRow),0) as f
			from #Result t1
			where sheetname='Detail Room'
			and ExcelColumn='G'
			and CalcType='Formula'
			)
			--SELECT *, CASE WHEN f = 0 THEN 0.00 ELSE h/f END
			--FROM cte
			--order by ExcelRow, ExcelColumn
			UPDATE cte 
			SET REsult = CASE WHEN f=0 THEN 0.00 ELSE h/f END

			--select * from #Result where SheetName='Detail Room' and ExcelColumn='G' order by ExcelRows
		END

		-- Column J
		-- J12 = K12/I12
		BEGIN
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Detail Room' and t2.ExcelColumn='K' AND t2.ExcelRow = t1.ExcelRow),0) as k,
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Detail Room' and t3.ExcelColumn='I' AND t3.ExcelRow = t1.ExcelRow),0) as i
			from #Result t1
			where sheetname='Detail Room'
			and ExcelColumn='J'
			and CalcType='Formula'
			)
			--SELECT *, CASE WHEN i = 0 THEN 0.00 ELSE k/i END
			--FROM cte
			--order by ExcelRow, ExcelColumn 
			UPDATE cte 
			SET REsult = CASE WHEN i=0 THEN 0.00 ELSE k/i END

		END

		-- Column M
		-- M12 = N12/L12
		BEGIN
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Detail Room' and t2.ExcelColumn='N' AND t2.ExcelRow = t1.ExcelRow),0) as n,
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Detail Room' and t3.ExcelColumn='L' AND t3.ExcelRow = t1.ExcelRow),0) as l
			from #Result t1
			where sheetname='Detail Room'
			and ExcelColumn='M'
			and CalcType='Formula'
			)
			--SELECT *, CASE WHEN l=0 THEN 0.00 ELSE n/l END
			--FROM cte
			--order by ExcelRow, ExcelColumn 
			UPDATE cte 
			SET REsult = CASE WHEN l=0 THEN 0.00 ELSE n/l END

			--select * from #Result where SheetName='Detail Room' and ExcelColumn='M' order by ExcelRow
		END

		-- Column P
		-- P12 = Q12/O12
		BEGIN
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Detail Room' and t2.ExcelColumn='Q' AND t2.ExcelRow = t1.ExcelRow),0) as q,
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Detail Room' and t3.ExcelColumn='O' AND t3.ExcelRow = t1.ExcelRow),0) as o
			from #Result t1
			where sheetname='Detail Room'
			and ExcelColumn='P'
			and CalcType='Formula'
			)
			--SELECT *, CASE WHEN o=0 THEN 0.00 ELSE q/o END
			--FROM cte
			--order by ExcelRow, ExcelColumn 
			UPDATE cte 
			SET REsult = CASE WHEN o=0 THEN 0.00 ELSE q/o END

			--select * from #Result where SheetName='Detail Room' and ExcelColumn='P' order by ExcelRow
		END

		-- Column S
		-- S12 = T12/R12
		BEGIN
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Detail Room' and t2.ExcelColumn='T' AND t2.ExcelRow = t1.ExcelRow),0) as t,
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Detail Room' and t3.ExcelColumn='R' AND t3.ExcelRow = t1.ExcelRow),0) as r
			from #Result t1
			where sheetname='Detail Room'
			and ExcelColumn='S'
			and CalcType='Formula'
			)
			--SELECT *, CASE WHEN r=0 THEN 0.00 ELSE CAST(t* 1.00 / r as DECIMAL(10,2)) END
			--FROM cte
			--order by ExcelRow, ExcelColumn 
			UPDATE cte 
			SET REsult = CASE WHEN r=0 THEN 0.00 ELSE t/r END
			--select * from #Result where SheetName='Detail Room' and ExcelColumn='S' order by ExcelRow
		END

		-- Value Rounding
		BEGIN
			
			-- Delete existing data for that section
			DELETE FROM Staging.Detail_Room_raw WHERE (@section='' OR SectionName=@section)
			DELETE FROM Staging.Detail_Room WHERE (@section='' OR SectionName=@section)

			INSERT INTO Staging.Detail_Room_raw
			SELECT SheetName, SectionName, RowName, ExcelRow, HideRow, [C],[D],[E],[F],[G],[H],[I],[J],[K],[L],[M],[N],[O],[P],[Q],[R],[S],[T] -- Need to add all columns
			FROM (
			SELECt SheetName, SectionName, RowName, Result, ExcelRow, ExcelColumn, HideRow
			FROM #Result
			) as src
			PIVOT
			(
			MAX(Result)
			FOR ExcelColumn IN ([C],[D],[E],[F],[G],[H],[I],[J],[K],[L],[M],[N],[O],[P],[Q],[R],[S],[T]) -- Need to add all columns
			) as pvt
			ORDER BY ExcelROw

			-- copy from raw table to rounded table
			INSERT INTO Staging.Detail_Room SELECT * FROM Staging.Detail_Room_raw WHERE (@section='' OR SectionName=@section)

			-- Replace 0 with null
			UPDATE Staging.Detail_Room SET C = NULL WHERE C = 0
			UPDATE Staging.Detail_Room SET D = NULL WHERE D = 0
			UPDATE Staging.Detail_Room SET E = NULL WHERE E = 0
			UPDATE Staging.Detail_Room SET F = NULL WHERE F = 0
			UPDATE Staging.Detail_Room SET G = NULL WHERE G = 0
			UPDATE Staging.Detail_Room SET H = NULL WHERE H = 0
			UPDATE Staging.Detail_Room SET I = NULL WHERE I = 0
			UPDATE Staging.Detail_Room SET J = NULL WHERE J = 0
			UPDATE Staging.Detail_Room SET K = NULL WHERE K = 0
			UPDATE Staging.Detail_Room SET L = NULL WHERE L = 0
			UPDATE Staging.Detail_Room SET M = NULL WHERE M = 0
			UPDATE Staging.Detail_Room SET N = NULL WHERE N = 0
			UPDATE Staging.Detail_Room SET O = NULL WHERE O = 0
			UPDATE Staging.Detail_Room SET P = NULL WHERE P = 0
			UPDATE Staging.Detail_Room SET Q = NULL WHERE Q = 0
			UPDATE Staging.Detail_Room SET R = NULL WHERE R = 0
			UPDATE Staging.Detail_Room SET S = NULL WHERE S = 0
			UPDATE Staging.Detail_Room SET T = NULL WHERE T = 0

			-- Format to Nearest INteger
			UPDATE Staging.Detail_Room SET C = ROUND(C, 0), 
			D = ROUND(D, 2),
			E = ROUND(E, 0), F = ROUND(F, 0), 
			G = ROUND(G, 2), 
			H = ROUND(H, 0), I = ROUND(I, 0), 
			J = ROUND(J, 2), 
			K = ROUND(K, 0), 
			L = ROUND(L, 0), 
			M = ROUND(M, 2), 
			N = ROUND(N, 0), O = ROUND(O, 0), 
			P = ROUND(P, 2), 
			Q = ROUND(Q, 0), R = ROUND(R, 0), 
			S = ROUND(S, 2), 
			T = ROUND(T, 0)
			WHERE (@section='' OR SectionName=@section)

		END

		-- update HideRow = 1 if all values are NULL
		UPDATE Staging.Detail_Room
		SET HideRow = 1
		WHERE ISNULL(C,0) + ISNULL(D,0) + ISNULL(E,0) + ISNULL(F,0) + ISNULL(G,0) + ISNULL(H,0) + ISNULL(I,0) + ISNULL(J,0) + ISNULL(K,0) + ISNULL(L,0) + 
		ISNULL(M,0) + ISNULL(N,0) + ISNULL(O,0) + ISNULL(P,0) + ISNULL(Q,0) + ISNULL(R,0) + ISNULL(S,0) + ISNULL(T,0) = 0
		AND RowName NOT IN ('Subtotal', 'TOTAL (Excluding Internal)', 'TOTAL (Internal)', 'Referral VIP - Others', 
		'Premium Mass - Others', 'Other Loyalty', 'Naga Group - Gaming', 'House Use', 'Complimentary')
		
		SELECt * FROM Staging.Detail_Room WHERE (@section='' OR SectionName=@section) ORDER BY ExcelRow ASC

	END
	----- BLOCK3 END -----


	----- BLOCK4 BEGIN -----
	-- Detail FB
	IF @sheet='Detail F&B'
	BEGIN
		-- Column E
		-- E12 = F12-C12-D12
		BEGIN
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Detail F&B' and t2.ExcelColumn='F' AND t2.ExcelRow = t1.ExcelRow),0) as f, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Detail F&B' and t3.ExcelColumn='C' AND t3.ExcelRow = t1.ExcelRow),0) as c,
			ISNULL((select t4.Result from #result t4 where t4.SheetName='Detail F&B' and t4.ExcelColumn='D' AND t4.ExcelRow = t1.ExcelRow),0) as d
			from #Result t1
			where sheetname='Detail F&B'
			and ExcelColumn='E'
			and CalcType='Formula'
			)
			--SELECT *, f-c-d FROM cte order by cellvalue 
			UPDATE cte SET REsult=f-c-d

			--select * from #Result where SheetName='Detail F&B' and ExcelColumn='E' order by ExcelRow
			--select * from #Result where SheetName='Detail F&B' and CellValue IN ('F36', 'C36', 'D36')
		END

		-- Column H
		-- H12 = F12/G12
		BEGIN
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Detail F&B' and t2.ExcelColumn='F' AND t2.ExcelRow = t1.ExcelRow),0) as f, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Detail F&B' and t3.ExcelColumn='G' AND t3.ExcelRow = t1.ExcelRow),0) as g
			from #Result t1
			where sheetname='Detail F&B'
			and ExcelColumn='H'
			and CalcType='Formula'
			)
			--SELECT *, CASE WHEN g=0 THEN 0.00 ELSE f/g END from cte order by ExcelRow, ExcelColumn
			UPDATE cte SET REsult = CASE WHEN g=0 THEN 0.00 ELSE f/g END

			--select * from #Result where SheetName='Detail F&B' and ExcelColumn='H' order by ExcelRow
			--select * from #Result where SheetName='Detail F&B' and CellValue in ('F34', 'G34', 'H34')
		END

		-- Column K
		-- K12 = L12-I12-J12
		BEGIN
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Detail F&B' and t2.ExcelColumn='L' AND t2.ExcelRow = t1.ExcelRow),0) as l, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Detail F&B' and t3.ExcelColumn='I' AND t3.ExcelRow = t1.ExcelRow),0) as i,
			ISNULL((select t4.Result from #result t4 where t4.SheetName='Detail F&B' and t4.ExcelColumn='J' AND t4.ExcelRow = t1.ExcelRow),0) as j
			from #Result t1
			where sheetname='Detail F&B'
			and ExcelColumn='K'
			and CalcType='Formula'
			)
			--SELECT *, l-i-j FROM cte order by ExcelRow, ExcelColumn 
			UPDATE cte SET REsult=l-i-j

			--select * from #Result where SheetName='Detail F&B' and ExcelColumn='K' order by ExcelRow
		END

		-- Column N
		-- N12 = L12/M12
		BEGIN
			; with cte as (
			select *, 
			ISNULL((select t2.Result from #result t2 where t2.SheetName='Detail F&B' and t2.ExcelColumn='L' AND t2.ExcelRow = t1.ExcelRow),0) as l, 
			ISNULL((select t3.Result from #result t3 where t3.SheetName='Detail F&B' and t3.ExcelColumn='M' AND t3.ExcelRow = t1.ExcelRow),0) as m
			from #Result t1
			where sheetname='Detail F&B'
			and ExcelColumn='N'
			and CalcType='Formula'
			)
			--SELECT *, CASE WHEN m=0 THEN 0.00 ELSE l/m END FROM cte order by ExcelRow, ExcelColumn 
			UPDATE cte SET REsult = CASE WHEN m=0 THEN 0.00 ELSE l/m END
			-- select * from #Result where SheetName='Detail F&B' and ExcelColumn='N' order by ExcelRow
		END

		-- Row 30
		-- C30 = SUM(C31:C35)
		BEGIN
			; with cte as (
				select *, 
				(select sum(t2.Result) from #Result t2 where t2.SheetName=t1.SheetName and t2.ExcelRow between 31 and 35 and t2.ExcelColumn=t1.ExcelColumn) as s 
				from #Result t1 where t1.SheetName='Detail F&B' and t1.ExcelRow=30
			)
			--select s from cte order by ExcelColumn
			update cte set Result=s
			--select * from #Result where SheetName='Detail F&B' and ExcelColumn='O' order by ExcelRow
			--select * from #Result where SheetName='Detail F&B' and CellValue IN ('F36', 'C36', 'D36')
		END

		-- Row 36
		-- C36 = SUM(C12:C30)
		BEGIN
			; with cte as (
				select *, 
				(select sum(t2.Result) from #Result t2 where t2.SheetName=t1.SheetName and t2.ExcelRow between 12 and 30 and t2.ExcelColumn=t1.ExcelColumn) as s 
				from #Result t1 where t1.SheetName='Detail F&B' and t1.ExcelRow=36
			)
			--select s from cte order by ExcelColumn
			update cte set Result=s
			--select * from #Result where SheetName='Detail F&B' and ExcelColumn='O' order by ExcelRow
			--select * from #Result where SheetName='Detail F&B' and CellValue IN ('F36', 'C36', 'D36')
		END

		-- Row 45
		-- C45 = SUM(O46:O57)
		BEGIN
			; with cte as (
				select *, 
				(select sum(t2.Result) from #Result t2 where t2.SheetName=t1.SheetName and t2.ExcelRow between 46 and 57 and t2.ExcelColumn=t1.ExcelColumn) as s 
				from #Result t1 where t1.SheetName='Detail F&B' and t1.ExcelRow=45
			)
			--select * from cte order by excelrow, ExcelColumn
			update cte set Result=s
			--select * from #Result where SheetName='Detail F&B' and ExcelColumn='O' order by ExcelRow
			--select * from #Result where SheetName='Detail F&B' and CellValue IN ('F36', 'C36', 'D36')
		END

		-- Row 58
		-- C58 = SUM(C38:C45)
		BEGIN
			; with cte as (
				select *, 
				(select sum(t2.Result) from #Result t2 where t2.SheetName=t1.SheetName and t2.ExcelRow between 38 and 45 and t2.ExcelColumn=t1.ExcelColumn) as s 
				from #Result t1 where t1.SheetName='Detail F&B' and t1.ExcelRow=58
			)
			--select * from cte order by excelrow, ExcelColumn
			update cte set Result=s
			--select * from #Result where SheetName='Detail F&B' and ExcelColumn='O' order by ExcelRow
			--select * from #Result where SheetName='Detail F&B' and CellValue IN ('F36', 'C36', 'D36')
		END

		-- Value Rounding
		BEGIN
			
			-- Delete existing data for that section
			DELETE FROM Staging.Detail_FB_raw WHERE (@section='' OR SectionName=@section)
			DELETE FROM Staging.Detail_FB WHERE (@section='' OR SectionName=@section)

			INSERT INTO Staging.Detail_FB_raw
			SELECT SheetName, SectionName, RowName, ExcelRow, HideRow, [C],[D],[E],[F],[G],[H],[I],[J],[K],[L],[M],[N],[O],[P],[Q],[R],[Z] -- Need to add all columns
			FROM (
			SELECt SheetName, SectionName, RowName, Result, ExcelRow, ExcelColumn, HideRow
			FROM #Result
			) as src
			PIVOT
			(
			MAX(Result)
			FOR ExcelColumn IN ([C],[D],[E],[F],[G],[H],[I],[J],[K],[L],[M],[N],[O],[P],[Q],[R],[Z]) -- Need to add all columns
			) as pvt
			ORDER BY ExcelROw

			-- copy from raw table to rounded table
			INSERT INTO Staging.Detail_FB SELECT * FROM Staging.Detail_FB_raw WHERE (@section='' OR SectionName=@section)

			UPDATE Staging.Detail_FB SET C = NULL WHERE C = 0
			UPDATE Staging.Detail_FB SET D = NULL WHERE D = 0
			UPDATE Staging.Detail_FB SET E = NULL WHERE E = 0
			UPDATE Staging.Detail_FB SET F = NULL WHERE F = 0
			UPDATE Staging.Detail_FB SET G = NULL WHERE G = 0
			UPDATE Staging.Detail_FB SET I = NULL WHERE I = 0
			UPDATE Staging.Detail_FB SET J = NULL WHERE J = 0
			UPDATE Staging.Detail_FB SET K = NULL WHERE K = 0
			UPDATE Staging.Detail_FB SET L = NULL WHERE L = 0
			UPDATE Staging.Detail_FB SET M = NULL WHERE M = 0
			UPDATE Staging.Detail_FB SET O = NULL WHERE O = 0
			UPDATE Staging.Detail_FB SET P = NULL WHERE P = 0
			UPDATE Staging.Detail_FB SET Q = NULL WHERE Q = 0
			UPDATE Staging.Detail_FB SET R = NULL WHERE R = 0

			-- B - Format to Nearest INteger
			UPDATE Staging.Detail_FB SET C = ROUND(C, 0), D = ROUND(D, 0), E = ROUND(E, 0), F = ROUND(F, 0), 
			G = ROUND(G, 0), I = ROUND(I, 0), J = ROUND(J, 0), K = ROUND(K, 0), 
			L = ROUND(L, 0), M = ROUND(M, 0), O = ROUND(O, 0), P = ROUND(P, 0), 
			Q = ROUND(Q, 0), R = ROUND(R, 0)
			WHERE (@section='' OR SectionName=@section)

		END

		-- update HideRow = 1 if all values are NULL
		UPDATE Staging.Detail_FB
		SET HideRow = 1
		WHERE ISNULL(C,0) + ISNULL(D,0) + ISNULL(E,0) + ISNULL(F,0) + ISNULL(G,0) + ISNULL(I,0) + ISNULL(J,0) + ISNULL(K,0) + ISNULL(L,0) + 
		ISNULL(M,0) + ISNULL(O,0) + ISNULL(P,0) + ISNULL(Q,0) + ISNULL(R,0) = 0
		AND RowName NOT IN ('Total F&B Revenue NAGA 1', 'Closed Outlets', 'Total F&B Revenue NAGA 2', 'Closed Outlets/VIP Floors')

		SELECt * FROM Staging.Detail_FB WHERE (@section='' OR SectionName=@section) ORDER BY ExcelRow ASC

	END
	----- BLOCK4 END -----


	----- BLOCK5 BEGIN -----
	-- Excecutive Summary
	IF @sheet='Executive Summary'
	BEGIN
		
		DROP TABLE IF EXISTS Staging.Executive_Summary

		if @section = 'NAGAWORLD'
		BEGIN
			-- Round Value
			SELECT SheetName, SectionName, RowName, ExcelRow, HideRow, [C],[D],[E],[F],[G],[H],[I],[J],[K] -- Need to add all columns
			INTO Staging.Executive_Summary
			FROM (
			SELECt SheetName, SectionName, RowName, Result, ExcelRow, ExcelColumn, HideRow
			FROM #Result
			) as src
			PIVOT
			(
			MAX(Result)
			FOR ExcelColumn IN ([C],[D],[E],[F],[G],[H],[I],[J],[K]) -- Need to add all columns
			) as pvt
			ORDER BY ExcelROw

			-- Room Revenue/Day
			UPDATE Staging.Executive_Summary SET 
			C = ROUND((SELECT t.B from Staging.Summary_raw t WHERE t.ExcelRow=15), 0),
			D = ROUND((SELECT t.C from Staging.Summary_raw t WHERE t.ExcelRow=15), 0), 
			E = ROUND((SELECT t.D from Staging.Summary_raw t WHERE t.ExcelRow=15), 0), 
			F = ROUND((SELECT t.F from Staging.Summary_raw t WHERE t.ExcelRow=15)/DAY(@inputDate),0), 
			G = ROUND((SELECT t.G from Staging.Summary_raw t WHERE t.ExcelRow=15)/DAY(@inputDate),0), 
			H = ROUND((SELECT t.H from Staging.Summary_raw t WHERE t.ExcelRow=15)/DAY(@inputDate),0),
			I = ROUND((SELECT t.Q from Staging.Summary_raw t WHERE t.ExcelRow=15)/(DATEDIFF(day, DATEADD(yy, DATEDIFF(yy, 0, GETDATE()), 0), @inputDate)+1), 0), 
			J = ROUND((SELECT t.R from Staging.Summary_raw t WHERE t.ExcelRow=15)/(DATEDIFF(day, DATEADD(yy, DATEDIFF(yy, 0, GETDATE()), 0), @inputDate)+1), 0), 
			K = ROUND((SELECT t.S from Staging.Summary_raw t WHERE t.ExcelRow=15)/(DATEDIFF(day, DATEADD(yy, DATEDIFF(yy, 0, GETDATE()), 0), @inputDate)+1), 0)
			WHERE ExcelRow = 3


			-- Calculate MTD Actual and YTD Actual
			SELECT DATEADD(YY, DATEDIFF(YY,0,TRANS_DATETIME),0) YTD_TRANS_DATETIME, DATEADD(MM, DATEDIFF(MM,0,TRANS_DATETIME),0) MTD_TRANS_DATETIME, TRANS_DATETIME, ANAL_T0, ANAL_T1, SUM(AMOUNT) AMOUNT
			INTO #temp 
			FROM NGG_A_SALFLDG 
			WHERE ACCNT_CODE BETWEEN '1' AND '1999999'
			AND PERIOD BETWEEN @PeriodYearFrom AND @PeriodYearTo
			AND TRANS_DATETIME BEtween @YearFrom AND @YearTo
			AND ANAL_T0 IN ('310', '350')
			AND (ANAL_T1 LIKE '3%' AND ANAL_T1 NOT IN ('3140', '3620'))
			--AND ANAL_T1 IN ('3210', '3230')
			GROUP BY DATEADD(YY, DATEDIFF(YY,0,TRANS_DATETIME),0), DATEADD(MM, DATEDIFF(MM,0,TRANS_DATETIME),0), TRANS_DATETIME, ANAL_T0, ANAL_T1

			-- MTD Actual
			SELECT SUM(CASE WHEN ANAL_T0 = '310' AND ANAL_T1 = '3090' THEN MTD_AMOUNT/DATEPART(DD, @inputDate) WHEN ANAL_T0 = '310' THEN MTD_AMOUNT/ MTD_COUNT END) MTD_N1
				   , SUM(CASE WHEN ANAL_T0 = '350' THEN MTD_AMOUNT/ MTD_COUNT END) MTD_N2
				   , SUM(CASE WHEN ANAL_T1 = '3090' THEN MTD_AMOUNT/DATEPART(DD, @inputDate) ELSE MTD_AMOUNT/ MTD_COUNT END) MTD_Total
			INTO #mtd_temp
			FROM (
			SELECT MTD_TRANS_DATETIME, ANAL_T0, ANAL_T1, SUM(AMOUNT) MTD_AMOUNT, COUNT(*) MTD_COUNT
			FROM #temp 
			WHERE MTD_TRANS_DATETIME = DATEADD(MM,DATEDIFF(MM,0,@inputDate),0)
			GROUP BY MTD_TRANS_DATETIME, ANAL_T0, ANAL_T1
			) temp

			-- YTD Actual
			SELECT SUM(CASE WHEN ANAL_T0 = '310' AND ANAL_T1 = '3090' THEN YTD_AMOUNT/ DATEPART(DY, @inputDate) WHEN ANAL_T0 = '310' THEN YTD_AMOUNT/ YTD_COUNT END) YTD_N1
				   , SUM(CASE WHEN ANAL_T0 = '350' THEN YTD_AMOUNT/ YTD_COUNT END) YTD_N2
				   , SUM(CASE WHEN ANAL_T1 = '3090' THEN YTD_AMOUNT/ DATEPART(DY, @inputDate) ELSE YTD_AMOUNT/ YTD_COUNT END) YTD_Total
			INTO #ytd_temp
			FROM (
			SELECT YTD_TRANS_DATETIME, ANAL_T0, ANAL_T1, SUM(AMOUNT) YTD_AMOUNT, COUNT(*) YTD_COUNT
			FROM #temp 
			WHERE YTD_TRANS_DATETIME = DATEADD(YY,DATEDIFF(YY,0,@inputDate),0)
			GROUP BY YTD_TRANS_DATETIME, ANAL_T0, ANAL_T1
			) temp

			-- F&B Revenue/Day
			UPDATE Staging.Executive_Summary SET 
			C = ROUND((SELECT t.B from Staging.Summary_raw t WHERE t.ExcelRow=20), 0),
			D = ROUND((SELECT t.C from Staging.Summary_raw t WHERE t.ExcelRow=20), 0),
			E = ROUND((SELECT t.D from Staging.Summary_raw t WHERE t.ExcelRow=20), 0),

			-- MTD Actual
			F = ROUND((SELECT MTD_N1 FROM #mtd_temp), 0),
			G = ROUND((SELECT MTD_N2 FROM #mtd_temp), 0),
			H = ROUND((SELECT MTD_TOTAL FROM #mtd_temp), 0),

			-- YTD Actual
			I = ROUND((SELECT YTD_N1 FROM #ytd_temp),0),
			J = ROUND((SELECT YTD_N2 FROM #ytd_temp),0),
			K = ROUND((SELECT YTD_TOTAL FROM #ytd_temp),0)
			
			WHERE ExcelRow = 4

			-- External Occupancy is from another sheet
			-- so we keep value as such
			UPDATE Staging.Executive_Summary SET 
			C = (ROUND((SELECT t.B from Staging.Summary_raw t WHERE t.ExcelRow=46),3)),
			D = (ROUND((SELECT t.C from Staging.Summary_raw t WHERE t.ExcelRow=46),3)),
			E = (ROUND((SELECT t.D from Staging.Summary_raw t WHERE t.ExcelRow=46),3)),
			F = (ROUND((SELECT t.F from Staging.Summary_raw t WHERE t.ExcelRow=46),3)),
			G = (ROUND((SELECT t.G from Staging.Summary_raw t WHERE t.ExcelRow=46),3)),
			H = (ROUND((SELECT t.H from Staging.Summary_raw t WHERE t.ExcelRow=46),3)),
			I = (ROUND((SELECT t.Q from Staging.Summary_raw t WHERE t.ExcelRow=46),3)),
			J = (ROUND((SELECT t.R from Staging.Summary_raw t WHERE t.ExcelRow=46),3)),
			K = (ROUND((SELECT t.S from Staging.Summary_raw t WHERE t.ExcelRow=46),3))
			WHERE ExcelRow = 5

			UPDATE Staging.Executive_Summary SET 
			C = ROUND((SELECT t.B from Staging.Summary_raw t WHERE t.ExcelRow=52), 2),
			D = ROUND((SELECT t.C from Staging.Summary_raw t WHERE t.ExcelRow=52), 2),
			E = ROUND((SELECT t.D from Staging.Summary_raw t WHERE t.ExcelRow=52), 2),
			F = ROUND((SELECT t.F from Staging.Summary_raw t WHERE t.ExcelRow=52), 2),
			G = ROUND((SELECT t.G from Staging.Summary_raw t WHERE t.ExcelRow=52), 2),
			H = ROUND((SELECT t.H from Staging.Summary_raw t WHERE t.ExcelRow=52), 2),
			I = ROUND((SELECT t.Q from Staging.Summary_raw t WHERE t.ExcelRow=52), 2),
			J = ROUND((SELECT t.R from Staging.Summary_raw t WHERE t.ExcelRow=52), 2),
			K = ROUND((SELECT t.S from Staging.Summary_raw t WHERE t.ExcelRow=52), 2)
			WHERE ExcelRow = 6

			UPDATE Staging.Executive_Summary SET 
			C = ROUND((SELECT t.B from Staging.Summary_raw t WHERE t.ExcelRow=34), 0),
			D = ROUND((SELECT t.C from Staging.Summary_raw t WHERE t.ExcelRow=34), 0),
			E = ROUND((SELECT t.D from Staging.Summary_raw t WHERE t.ExcelRow=34), 0),
			F = ROUND((SELECT t.F from Staging.Summary_raw t WHERE t.ExcelRow=34), 0),
			G = ROUND((SELECT t.G from Staging.Summary_raw t WHERE t.ExcelRow=34), 0),
			H = ROUND((SELECT t.H from Staging.Summary_raw t WHERE t.ExcelRow=34), 0),
			I = ROUND((SELECT t.Q from Staging.Summary_raw t WHERE t.ExcelRow=34), 0),
			J = ROUND((SELECT t.R from Staging.Summary_raw t WHERE t.ExcelRow=34), 0),
			K = ROUND((SELECT t.S from Staging.Summary_raw t WHERE t.ExcelRow=34), 0)
			WHERE ExcelRow = 8


			SELECt * FROM Staging.Executive_Summary ORDER BY ExcelRow ASC
		END
		
		if @section = 'MTD External Rooms Occupancy % (Market Segments)'
		BEGIN
			-- To Clear off yesterday's data in Staging.Executive_Summary_MTD Table
			UPDATE Staging.Executive_Summary_MTD
			SET SegmentValue = NULL

			DECLARE @detailRoomF91 AS Float
			DECLARE @detailRoomF76 as Float
			DECLARE @detailRoomF77 as Float
			DECLARE @detailRoomF75 as Float
			DECLARE @detailRoomF23 as Float
			DECLARE @detailRoomF50 as Float
			DECLARE @detailRoomF60 as Float
			DECLARE @detailRoomF89 as Float
			DECLARE @detailRoomF85 as Float
			DECLARE @detailRoomF17 as Float
			DECLARE @detailRoomF21 as Float

			SELECT @detailRoomF91 = t.F FROM Staging.Detail_Room_raw t WHERE t.ExcelRow=91
			SELECT @detailRoomF76 = t.F FROM Staging.Detail_Room_raw t WHERE t.ExcelRow=76
			SELECT @detailRoomF77 = t.F FROM Staging.Detail_Room_raw t WHERE t.ExcelRow=77
	
			SELECT @detailRoomF75 = t.F FROM Staging.Detail_Room_raw t WHERE t.ExcelRow=75

			SELECT @detailRoomF23 = t.F FROM Staging.Detail_Room_raw t WHERE t.ExcelRow=23
			
			SELECT @detailRoomF50 = t.F FROM Staging.Detail_Room_raw t WHERE t.ExcelRow=50
			SELECT @detailRoomF60 = t.F FROM Staging.Detail_Room_raw t WHERE t.ExcelRow=60

			SELECT @detailRoomF89 = t.F FROM Staging.Detail_Room_raw t WHERE t.ExcelRow=89

			SELECT @detailRoomF85 = t.F FROM Staging.Detail_Room_raw t WHERE t.ExcelRow=85

			SELECT @detailRoomF17 = t.F FROM Staging.Detail_Room_raw t WHERE t.ExcelRow=17
			SELECT @detailRoomF21 = t.F FROM Staging.Detail_Room_raw t WHERE t.ExcelRow=21

			--UPDATE Staging.Executive_Summary_MTD 
			--SET SEgmentValue = CASE WHEN @detailRoomF91 = 0 THEN 0.0 ELSE (ROUND(((@detailRoomF76)/(@detailRoomF91))*100,1) + 
			--ROUND(((@detailRoomF77)/(@detailRoomF91))*100,1)) END
			--WHERE SegmentName = 'Leisure FIT / Leisure GIT'

			UPDATE Staging.Executive_Summary_MTD 
			SET SEgmentValue = 
			CASE WHEN @detailRoomF91 = 0 OR @detailRoomF76 IS NULL THEN 0.0 ELSE ROUND(((@detailRoomF76)/(@detailRoomF91))*100,1) END 
			+ 
			CASE WHEN @detailRoomF91 = 0 OR @detailRoomF77 IS NULL THEN 0.0 ELSE ROUND(((@detailRoomF77)/(@detailRoomF91))*100,1) END
			WHERE SegmentName = 'Leisure FIT / Leisure GIT'

			--UPDATE Staging.Executive_Summary_MTD 
			--SET SEgmentValue = CASE WHEN @detailRoomF91 = 0 THEN 0.0 ELSE (ROUND(((@detailRoomF75)/(@detailRoomF91))*100,1)) END
			--WHERE SegmentName = 'Gaming Mass'
			UPDATE Staging.Executive_Summary_MTD 
			SET SEgmentValue = CASE WHEN @detailRoomF91 = 0 OR @detailRoomF75 IS NULL THEN 0.0 ELSE (ROUND(((@detailRoomF75)/(@detailRoomF91))*100,1)) END
			WHERE SegmentName = 'Gaming Mass'

			--UPDATE Staging.Executive_Summary_MTD 
			--SET SEgmentValue = CASE WHEN @detailRoomF91 = 0 THEN 0.0 ELSE (ROUND(((@detailRoomF23)/(@detailRoomF91))*100,1)) END
			--WHERE SegmentName = 'Direct FIT'
			UPDATE Staging.Executive_Summary_MTD 
			SET SEgmentValue = CASE WHEN @detailRoomF91 = 0 OR @detailRoomF23 IS NULL THEN 0.0 ELSE (ROUND(((@detailRoomF23)/(@detailRoomF91))*100,1)) END
			WHERE SegmentName = 'Direct FIT'
			
			--UPDATE Staging.Executive_Summary_MTD 
			--SET SEgmentValue =  CASE WHEN @detailRoomF91 = 0 THEN 0.0 ELSE (
			--	ROUND((@detailRoomF50)/(@detailRoomF91)*100,1) + 
			--	ROUND((@detailRoomF60)/(@detailRoomF91)*100,1)
			--) END
			--WHERE SegmentName = 'Premium Mass / Referral VIP'
			UPDATE Staging.Executive_Summary_MTD 
			SET SEgmentValue =
			CASE WHEN @detailRoomF91 = 0 OR @detailRoomF50 IS NULL THEN 0.0 ELSE ROUND((@detailRoomF50)/(@detailRoomF91)*100,1) END
			+ 
			CASE WHEN @detailRoomF91 = 0 OR @detailRoomF60 IS NULL THEN 0.0 ELSE ROUND((@detailRoomF60)/(@detailRoomF91)*100,1) END
			WHERE SegmentName = 'Premium Mass / Referral VIP'

			--UPDATE Staging.Executive_Summary_MTD 
			--SET SEgmentValue =  CASE WHEN @detailRoomF91 = 0 THEN 0.0 ELSE (ROUND(((@detailRoomF89)/(@detailRoomF91))*100,1)) END
			--WHERE SegmentName = 'Package'
			UPDATE Staging.Executive_Summary_MTD 
			SET SEgmentValue =  CASE WHEN @detailRoomF91 = 0 OR @detailRoomF89 IS NULL THEN 0.0 ELSE (ROUND(((@detailRoomF89)/(@detailRoomF91))*100,1)) END
			WHERE SegmentName = 'Package'

			--UPDATE Staging.Executive_Summary_MTD 
			--SET SEgmentValue =  CASE WHEN @detailRoomF91 = 0 THEN 0.0 ELSE (ROUND(((@detailRoomF85)/(@detailRoomF91))*100,1)) END
			--WHERE SegmentName = 'Online Travel Agents'
			UPDATE Staging.Executive_Summary_MTD 
			SET SEgmentValue =  CASE WHEN @detailRoomF91 = 0 OR @detailRoomF85 IS NULL THEN 0.0 ELSE (ROUND(((@detailRoomF85)/(@detailRoomF91))*100,1)) END
			WHERE SegmentName = 'Online Travel Agents'

			--UPDATE Staging.Executive_Summary_MTD 
			--SET SEgmentValue =  CASE WHEN @detailRoomF91 = 0 THEN 0.0 ELSE (
			--	ROUND(((@detailRoomF17)/(@detailRoomF91))*100,1) + 
			--	ROUND(((@detailRoomF21)/(@detailRoomF91))*100,1)
			--) END
			--WHERE SegmentName = 'Corporate FIT / Corporate GIT'
			UPDATE Staging.Executive_Summary_MTD 
			SET SEgmentValue = 
			 CASE WHEN @detailRoomF91 = 0 OR @detailRoomF17 IS NULL THEN 0.0 ELSE ROUND(((@detailRoomF17)/(@detailRoomF91))*100,1) END 
			 + 
			 CASE WHEN @detailRoomF91 = 0 OR @detailRoomF21 IS NULL THEN 0.0 ELSE ROUND(((@detailRoomF21)/(@detailRoomF91))*100,1) END
			WHERE SegmentName = 'Corporate FIT / Corporate GIT'
			
			-- Adjust the highest vallue
			UPDATE Staging.Executive_Summary_MTD 
			SET SegmentValue = (SELECT (SELECT TOP(1) SegmentValue from Staging.Executive_Summary_MTD ORDER BY SegmentValue DESC) + 
			(100-SUM(SegmentValue)) FROM Staging.Executive_Summary_MTD)
			WHERE SegmentName = (SELECT TOP(1) SegmentName FROM Staging.Executive_Summary_MTD ORDER BY SegmentValue DESC)

			SELECT CAST(CAST(SegmentValue as numeric(5,1)) as varchar(10)) + '% ' + SegmentName SegmentName
			FROM Staging.Executive_Summary_MTD
			ORDER BY SegmentValue DESC

		END
	
		if @section = 'Key Data F&B'
		BEGIN

			-- To Clear off yesterday's data in Staging.Executive_Summary_KeyData Table
			UPDATE Staging.Executive_Summary_KeyData
			SET SegmentValue = NULL

			UPDATE Staging.Executive_Summary_KeyData
			SET SegmentValue = (SELECT Top 1 RowName + ' of $' + CONVERT(varchar, format(F, 'N0'))
			FROM Staging.Detail_FB
			WHERE ExcelRow NOT IN (36,58)
			ORDER BY F DESC)
			WHERE SegmentName = 'Top performing F&B outlet for the day:'

			UPDATE Staging.Executive_Summary_KeyData
			SET SegmentValue = (SELECT Top 1 'Naga 1 - ' + RowName + ' $'+ CONVERT(varchar, format(L/DAY(@inputDate), 'N0')) + ' average per day'
			FROM Staging.Detail_FB
			WHERE ExcelRow BETWEEN 12 AND 35
			ORDER BY L DESC)
			WHERE SegmentName = 'Top performing F&B outlets for the month:'

			UPDATE Staging.Executive_Summary_KeyData
			SET SegmentValue = (SELECT Top 1 'Naga 2 - ' + RowName + ' $' + CONVERT(varchar, format(L/DAY(@inputDate), 'N0')) + ' average per day'
			FROM Staging.Detail_FB
			WHERE ExcelRow BETWEEN 38 AND 57
			ORDER BY L DESC)
			WHERE SegmentName = ''
			
			SELECT SegmentName, SegmentValue FROM Staging.Executive_Summary_KeyData
			ORDER BY SegmentOrder

		END
	
	END
	----- BLOCK5 BEGIN -----

END
--GO


