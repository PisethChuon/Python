from minio import Minio
from minio.error import S3Error
import os
import time

# S3 Configuration
client = Minio(
    "s3.nagaworld.com",
    access_key="BlVh5O1ovXUr2g93",
    secret_key="zVEwIinRTsZtyV50e6EmcRjmj7IaGroV",
    secure=True  # Enable HTTPS certificate verification
)

def download_objects(bucket_name, destination_folder):
    """
    Download all objects from a bucket to a local folder.
    """
    try:
        if not os.path.exists(destination_folder):
            os.makedirs(destination_folder)

        # List all objects in the bucket
        objects = client.list_objects(bucket_name, recursive=True)
        for obj in objects:
            file_path = os.path.join(destination_folder, obj.object_name)
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            client.fget_object(bucket_name, obj.object_name, file_path)
            print(f"Downloaded {obj.object_name} to {file_path}")
    except S3Error as e:
        print(f"Error accessing bucket {bucket_name}: {e}")

# 503 status
def download_objects_with_retry(bucket_name, destination_folder, max_retries=5, delay=5):
    """
    Retry downloading objects from the bucket with 'exponential backoff' if a 503 error is encountered.
    """
    attempt = 0
    while attempt < max_retries:
        try:
            download_objects(bucket_name, destination_folder)
            break  # Exit loop if successful
        except S3Error as e:
            if "503" in str(e):  # Check for Service Unavailable (503) error
                print(f"Service unavailable. Retrying... (Attempt {attempt + 1})")
                attempt += 1
                time.sleep(delay * (2 ** attempt))  # Exponential backoff
            else:
                print(f"Error accessing bucket {bucket_name}: {e}")
                break  # Exit loop for non-503 errors
    else:
        print(f"Failed to download objects after {max_retries} attempts.")

if __name__ == "__main__":
    # Start with downloading 'myportal-epp'
    print(f"Starting download for bucket: myportal-epp")
    destination_base = "./downloads"
    destination_folder = os.path.join(destination_base, "myportal-epp")
    download_objects_with_retry("myportal-epp", destination_folder)
    

    # Start with downloading 'emp-photo' 
    # print(f"Starting download for bucket: emp-photo")
    # destination_folder = os.path.join(destination_base, "emp-photo")
    # download_objects_with_retry("emp-photo", destination_folder)

    print("All downloads completed.")
