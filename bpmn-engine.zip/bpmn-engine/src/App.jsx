import "flowbite";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import "bpmn-js/dist/assets/diagram-js.css";
import "bpmn-js/dist/assets/bpmn-font/css/bpmn-embedded.css";

import { MainPage } from "./pages/main";

import { AdminPage } from "./pages/admin";
import { WorkflowEditPage } from "./pages/admin/workflow/edit";
import { WorkflowNewPage } from "./pages/admin/workflow/new";
import { FormEditPage } from "./pages/admin/form/edit";

import { VerifierPage } from "./pages/verifier";
import { HODPage } from "./pages/hod";
import { RequestorPage } from "./pages/requestor";
import { RequestNewPage } from "./pages/request/new";

import { RequestDetailPage } from "./pages/request/detail";
import { RequestEditPage } from "./pages/request/edit";

export default function App() {
  return (
    <div className="w-screen h-screen">
      <Router>
        <Routes>
        <Route path="/" element={<MainPage />} />
          <Route path="/admin" element={<AdminPage />} />
          <Route path="/admin/workflow/new" element={<WorkflowNewPage />} />
          <Route path="/admin/workflow/:wid/edit" element={<WorkflowEditPage />} />
          <Route path="/admin/workflow/:wid/form" element={<FormEditPage />} />

          <Route path="/requestor" element={<RequestorPage />} />
          <Route path="/verifier" element={<VerifierPage />} />
          <Route path="/hod" element={<HODPage />} />
          
          <Route path="/request/new" element={<RequestNewPage />} />
          <Route path="/request/edit/:rid" element={<RequestEditPage />} />
          <Route path="/request/detail/:rid" element={<RequestDetailPage />} />
          
        </Routes>
      </Router>
    </div>
  );
}
