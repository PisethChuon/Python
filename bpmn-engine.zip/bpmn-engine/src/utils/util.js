import BpmnModdle from "bpmn-moddle";

export async function getActivities(xml) {
    const moddle = new BpmnModdle();
    const { rootElement } = await moddle.fromXML(xml);
    const elements = rootElement.rootElements[0].flowElements || [];
    return elements
      .filter((el) =>
        ["bpmn:UserTask"].includes(el.$type)
      )
      .map((el) => ({
        id: el.id,
        name: el.name || el.$type, // Use name if available
        type: el.$type.replace("bpmn:", ""),
      }))
      .sort((a, b) => a.name.localeCompare(b.name))
}

export function findFieldKey(schema, id) {
  const components = schema.components
  if (!components) return null
  for (const component of components) {
    if (component.id == id) return component
    if (component.components) return findFieldKey(component, id)
  }
}

export function generateId() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < 4; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

export function findFormData(state, data) {
  if (data.state == state) {
    return data.formData
  }
  for (const historyState of data.history) {
    return findFormData(state, historyState)
  }
}

export const ACTIONS = {
  SUBMIT: "Submit",
  RESUBMIT: "Resubmit",
  REJECT: "Reject",
  REWORK: "Rework",
  VERIFY: "Verify",
  CANCEL: "Cancel",
  APPROVE: "Approve"
}