import { useRef, useEffect } from "react";
import PropTypes from "prop-types";
import { Form } from "@bpmn-io/form-js";
import { ACTIONS } from "../utils/util";

export function FormLoader({
  form,
  formData,
  onSubmit,
  onResubmit,
  onVerify,
  onRework,
  onReject,
  onCancel,
  onApprove,
}) {
  const formContainer = useRef(null);
  const formInstance = useRef(null);

  useEffect(() => {
    if (!formContainer.current) return;
    if (
      !onSubmit &&
      !onReject &&
      !onRework &&
      !onCancel &&
      !onApprove &&
      !onResubmit &&
      !onVerify
    ) {
      formInstance.current = new Form({
        container: formContainer.current,
        properties: {
          readOnly: true,
        },
      });
    } else {
      formInstance.current = new Form({
        container: formContainer.current,
      });
    }

    if (!formData) {
      formInstance.current.importSchema(form.schema).then(async () => {
        console.log("Form loaded successfully");
      });
    } else {
      formInstance.current
        .importSchema(form.schema, formData)
        .then(async () => {
          console.log("Form loaded successfully");
        });
    }
  }, []);

  return (
    <div className="w-full h-full flex flex-col">
      <div ref={formContainer}></div>
      <div className="flex justify-end mr-11">
        {form.actions.includes(ACTIONS.SUBMIT) && onSubmit ? (
          <button
            type="button"
            className="focus:outline-none text-white bg-green-700 hover:bg-green-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-900"
            onClick={() => onSubmit(formInstance)}
          >
            {ACTIONS.SUBMIT}
          </button>
        ) : (
          <></>
        )}

        {form.actions.includes(ACTIONS.REWORK) && onRework ? (
          <button
            type="button"
            className="focus:outline-none text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-900"
            onClick={() => onRework(formInstance)}
          >
            {ACTIONS.REWORK}
          </button>
        ) : (
          <></>
        )}

        {form.actions.includes(ACTIONS.RESUBMIT) && onResubmit ? (
          <button
            type="button"
            className="focus:outline-none text-white bg-gray-700 hover:bg-gray-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-900"
            onClick={() => onResubmit(formInstance)}
          >
            {ACTIONS.RESUBMIT}
          </button>
        ) : (
          <></>
        )}

        {form.actions.includes(ACTIONS.REJECT) && onReject ? (
          <button
            type="button"
            className="focus:outline-none text-white bg-violet-700 hover:bg-violet-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-900"
            onClick={() => onReject(formInstance)}
          >
            {ACTIONS.REJECT}
          </button>
        ) : (
          <></>
        )}

        {form.actions.includes(ACTIONS.CANCEL) && onCancel ? (
          <button
            type="button"
            className="focus:outline-none text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-900"
            onClick={() => onCancel(formInstance)}
          >
            {ACTIONS.CANCEL}
          </button>
        ) : (
          <></>
        )}

        {form.actions.includes(ACTIONS.VERIFY) && onVerify ? (
          <button
            type="button"
            className="focus:outline-none text-white bg-cyan-700 hover:bg-cyan-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-900"
            onClick={() => onVerify(formInstance)}
          >
            {ACTIONS.VERIFY}
          </button>
        ) : (
          <></>
        )}

        {form.actions.includes(ACTIONS.APPROVE) && onApprove ? (
          <button
            type="button"
            className="focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-900"
            onClick={() => onApprove(formInstance)}
          >
            {ACTIONS.APPROVE}
          </button>
        ) : (
          <></>
        )}
      </div>
    </div>
  );
}

FormLoader.propTypes = {
  form: PropTypes.object,
  formData: PropTypes.object,
  onSubmit: PropTypes.func,
  onResubmit: PropTypes.func,
  onVerify: PropTypes.func,
  onRework: PropTypes.func,
  onCancel: PropTypes.func,
  onReject: PropTypes.func,
  onApprove: PropTypes.func,
};
