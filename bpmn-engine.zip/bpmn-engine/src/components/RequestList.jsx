import PropTypes from "prop-types";
import { useNavigate } from "react-router-dom";

export function RequestList({list, getLink }) {
  const navigate = useNavigate();

  return (
    <table className="w-full text-left rtl:text-right text-gray-500 dark:text-gray-400">
      <thead className="text-gray-700 uppercase dark:text-gray-400">
        <tr>
          <th scope="col" className="px-6 py-3 bg-gray-50 dark:bg-gray-800 ">
            Id
          </th>
          <th scope="col" className="px-6 py-3 bg-gray-50 dark:bg-gray-800 ">
            Create Date
          </th>
          <th scope="col" className="px-6 py-3 ">
            Create By
          </th>
          <th scope="col" className="px-6 py-3 ">
            Workflow
          </th>
          <th scope="col" className="px-6 py-3 ">
            State
          </th>
        </tr>
      </thead>
      <tbody>
        {list.map((r) => {
          return (
            <tr
              key={r.id}
              className="cursor-pointer"
              onClick={() => {
                window.location.href = getLink(r);
              }}
            >
              <td className="px-6 py-4 text-xl">{r.id}</td>
              <td className="px-6 py-4 text-xl">{r.createdDt}</td>
              <td className="px-6 py-4 text-xl">{r.createdBy}</td>
              <td className="px-6 py-4 text-xl">{r.workflow}</td>
              <td className="px-6 py-4 text-xl">{r.state}</td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
}

RequestList.propTypes = {
  list: PropTypes.array,
  getLink: PropTypes.func,
};
