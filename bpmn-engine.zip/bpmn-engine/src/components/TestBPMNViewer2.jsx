import React, { useEffect, useRef, useState } from "react";
import BpmnModdle from "bpmn-moddle"; // Library to parse BPMN XML

export function BpmnToXState() {
    
  const bpmnXml = `<?xml version="1.0" encoding="UTF-8"?>
  <bpmn:definitions xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                    xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL"
                    id="Definitions_1"
                    targetNamespace="http://bpmn.io/schema/bpmn">
    <bpmn:process id="Process_1" isExecutable="false">
      <bpmn:startEvent id="StartEvent_1"/>
      <bpmn:task id="Task_1" name="Task One"/>
      <bpmn:task id="Task_2" name="Task Two"/>
      <bpmn:endEvent id="EndEvent_1"/>
      <bpmn:sequenceFlow id="Flow_1" sourceRef="StartEvent_1" targetRef="Task_1"/>
      <bpmn:sequenceFlow id="Flow_2" sourceRef="Task_1" targetRef="Task_2"/>
      <bpmn:sequenceFlow id="Flow_3" sourceRef="Task_2" targetRef="EndEvent_1"/>
    </bpmn:process>
  </bpmn:definitions>`;

  useEffect(() => {
    /*
      const process = definitions.rootElements.find(el => el.$type === "bpmn:Process");
      if (!process) return;

      const states = {};
      const transitions = {};

      process.flowElements.forEach((el) => {
        if (el.$type === "bpmn:Task" || el.$type === "bpmn:StartEvent" || el.$type === "bpmn:EndEvent") {
          states[el.id] = { on: {} };
        }

        if (el.$type === "bpmn:SequenceFlow") {
          const from = el.sourceRef.id;
          const to = el.targetRef.id;

          if (states[from]) {
            states[from].on[`NEXT_${to}`] = to;
          }
        }
      });

    */


    const test123 = async () => {
        
    const moddle = new BpmnModdle();
    
    console.log("1")
    const { rootElement } = await moddle.fromXML(bpmnXml)

    console.log(rootElement)
    
    const process = rootElement.rootElements.find(el => el.$type == "bpmn:Process")

    console.log(process)

    }

    test123()
  }, []);

  return (
    <div>
      <h2>BPMN to XState Converter</h2>
      
    </div>
  );
};
