import { useEffect, useRef } from "react";
import BpmnJS from "bpmn-js";

const bpmnXml = `<?xml version="1.0" encoding="UTF-8"?>
<definitions xmlns="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:omgdi="http://www.omg.org/spec/DD/20100524/DI" xmlns:omgdc="http://www.omg.org/spec/DD/20100524/DC" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="sid-38422fae-e03e-43a3-bef4-bd33b32041b2" targetNamespace="http://bpmn.io/bpmn" exporter="bpmn-js (https://demo.bpmn.io)" exporterVersion="18.1.1">
  <bpmn:process id="bpmn:process_1" isExecutable="false">
    <bpmn:startEvent id="bpmn:startEvent_1y45yut" name="Start">
      <bpmn:outgoing>bpmn:sequenceFlow_0h21x7r</bpmn:outgoing>
    </bpmn:startEvent>
    <bpmn:task id="bpmn:task_1hcentk" name="Activity">
      <bpmn:incoming>bpmn:sequenceFlow_0h21x7r</bpmn:incoming>
      <bpmn:outgoing>Flow_0pszmv5</bpmn:outgoing>
    </bpmn:task>
    <bpmn:sequenceFlow id="bpmn:sequenceFlow_0h21x7r" sourceRef="bpmn:startEvent_1y45yut" targetRef="bpmn:task_1hcentk" />
    <bpmn:endEvent id="Event_0f6umgd" name="End">
      <bpmn:incoming>Flow_0pszmv5</bpmn:incoming>
    </bpmn:endEvent>
    <bpmn:sequenceFlow id="Flow_0pszmv5" sourceRef="bpmn:task_1hcentk" targetRef="Event_0f6umgd" />
  </bpmn:process>
  <bpmndi:BPMNDiagram id="BpmnDiagram_1">
    <bpmndi:BPMNPlane id="BpmnPlane_1" bpmnElement="bpmn:process_1">
      <bpmndi:BPMNShape id="bpmn:startEvent_1y45yut_di" bpmnElement="bpmn:startEvent_1y45yut">
        <omgdc:Bounds x="152" y="102" width="36" height="36" />
        <bpmndi:BPMNLabel>
          <omgdc:Bounds x="158" y="145" width="25" height="14" />
        </bpmndi:BPMNLabel>
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="bpmn:task_1hcentk_di" bpmnElement="bpmn:task_1hcentk">
        <omgdc:Bounds x="240" y="80" width="100" height="80" />
        <bpmndi:BPMNLabel />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Event_0f6umgd_di" bpmnElement="Event_0f6umgd">
        <omgdc:Bounds x="402" y="102" width="36" height="36" />
        <bpmndi:BPMNLabel>
          <omgdc:Bounds x="410" y="145" width="20" height="14" />
        </bpmndi:BPMNLabel>
      </bpmndi:BPMNShape>
      <bpmndi:BPMNEdge id="bpmn:sequenceFlow_0h21x7r_di" bpmnElement="bpmn:sequenceFlow_0h21x7r">
        <omgdi:waypoint x="188" y="120" />
        <omgdi:waypoint x="240" y="120" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_0pszmv5_di" bpmnElement="Flow_0pszmv5">
        <omgdi:waypoint x="340" y="120" />
        <omgdi:waypoint x="402" y="120" />
      </bpmndi:BPMNEdge>
    </bpmndi:BPMNPlane>
  </bpmndi:BPMNDiagram>
</definitions>
`;

export function TestBpmnViewer() {
  const containerRef = useRef(null);
  const bpmnViewer = useRef(null);
  const overlays = useRef(null);
  
  useEffect(() => {
    if (!bpmnViewer.current) {
        bpmnViewer.current = new BpmnJS({ container: containerRef.current });
        const canvas = bpmnViewer.current.get("canvas");
        canvas.zoom("fit-viewport");
    }

    return () => {
      if (bpmnViewer.current) {
        bpmnViewer.current.destroy();
        bpmnViewer.current = null;
      }
    };
  }, []);

  useEffect(() => {
    bpmnViewer.current
      .importXML(bpmnXml)
      .then(() => {
        
        overlays.current = bpmnViewer.current.get("overlays");
        const registry = bpmnViewer.current.get("elementRegistry");
        const founds = registry.getAll().filter(e => e.id == "bpmn:task_1hcentk")
        const selected = founds[0]
        
        overlays.current.clear()
        overlays.current.add(selected.id, {
            position: { top: -1, left: -1 },
            html: `<div style="
              width: ${selected.width}px;
              height: ${selected.height}px;
              background: rgba(1, 252, 39, 0.5);
              position: absolute;
              border-radius: 10px;
            "></div>`,
          });

      })
      .catch((err) => {
        console.error("Failed to load BPMN diagram", err);
      });
  }, [bpmnViewer]);

  return (
    <div>
      <h2>BPMN Modeler</h2>
      <div
        ref={containerRef}
        style={{ width: "100%", height: "500px", border: "1px solid #ccc" }}
      />
    </div>
  );
}
