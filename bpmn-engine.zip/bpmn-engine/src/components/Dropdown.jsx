import { useState } from "react";
import PropTypes from "prop-types";

export function Dropdown({optionList, selectedOption, setSelectedOption}) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="relative inline-block">
      {/* Dropdown Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center inline-flex items-center"
      >
        {selectedOption ? selectedOption.name : ''}
        <svg
          className="w-4 h-4 ml-2 transition-transform duration-200"
          aria-hidden="true"
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 20 20"
          style={{ transform: isOpen ? "rotate(180deg)" : "rotate(0deg)" }}
        >
          <path
            stroke="currentColor"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
            d="M5 7l5 5 5-5"
          />
        </svg>
      </button>

      {/* Dropdown Menu */}
      {isOpen && (
        <div className="absolute left-0 mt-2 bg-white divide-y divide-gray-100 rounded-lg shadow-lg w-44 z-10">
          <ul className="py-2 text-sm text-gray-700">
            {optionList && optionList.map((o) => (
              <li key={o.id}>
              <a href="#" className="block px-4 py-2 hover:bg-gray-100" 
                onClick={() => {
                  setSelectedOption(o)
                  setIsOpen(false)
                }}
              >
                {o.name}
              </a>
            </li>
          ))}
           
          </ul>
        </div>
      )}
    </div>
  );
};

Dropdown.propTypes = {
  optionList: PropTypes.string,
  selectedOption: PropTypes.object,
  setSelectedOption: PropTypes.func
};
