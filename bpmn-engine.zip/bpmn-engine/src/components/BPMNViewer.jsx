import { useRef, useEffect } from "react";
import PropTypes from "prop-types";
import BpmnJS from "bpmn-js";

export function BPMNViewer({ xml, selectedNode }) {
  const containerRef = useRef(null);
  const bpmnViewer = useRef(null);
  const overlays = useRef(null);

  useEffect(() => {
    if (!bpmnViewer.current) {
      bpmnViewer.current = new BpmnJS({ container: containerRef.current });
    }
    return () => {
      if (bpmnViewer.current) {
        bpmnViewer.current.destroy();
        bpmnViewer.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (!bpmnViewer.current) {
      return;
    }

    bpmnViewer.current
      .importXML(xml)
      .then(async () => {

        // hightlight current activity
        bpmnViewer.current.get("canvas").zoom("fit-viewport");
        overlays.current = bpmnViewer.current.get("overlays");
        const registry = bpmnViewer.current.get("elementRegistry");
        
        if (selectedNode) {
          const list = registry.getAll()
          const founds = list.filter((e) => e.di.bpmnElement.name == `${selectedNode}`);
          
          const selected = founds[0];
          if (!selected) return
          
          overlays.current.clear();
          overlays.current.add(selected.id, {
            position: { top: -1, left: -1 },
            html: `<div style="
              width: ${selected.width}px;
              height: ${selected.height}px;
              background: rgba(1, 252, 39, 0.5);
              position: absolute;
              border-radius: 10px;
            "></div>`,
          });
        }
      })
      .catch((err) => console.error("Failed to load BPMN diagram", err));
  }, [xml, selectedNode]);

  return (
    <div className="h-full w-full overflow-y-auto">
        <div ref={containerRef} className="w-full h-full p-5"></div>
    </div>
  );
}

BPMNViewer.propTypes = {
  xml: PropTypes.string,
  selectedNode: PropTypes.string,
};
