import axios from "axios";
import { useState, useEffect } from "react";
import BPMNModdle from "bpmn-moddle";
import { createMachine, createActor } from "xstate";
import { BPMNViewer } from "../../components/BPMNViewer";
import { FormLoader } from "../../components/FormLoader";
import { RequestList } from "../../components/RequestList";
import { findFieldKey, findFormData, generateId } from "../../utils/util";
import { useNavigate, useParams } from "react-router-dom";

export function RequestEditPage() {
  const navigate = useNavigate();
  const { rid } = useParams();
  const [requestList, setRequestList] = useState([]);
  const [request, setRequest] = useState(null);
  const [workflow, setWorkflow] = useState(null);
  const [stateMachine, setStateMachine] = useState(null);
  const [currentState, setCurrentState] = useState(null);
  const [form, setForm] = useState(null);
  const [formData, setFormData] = useState(null);
  const [actor, setActor] = useState(null);

  async function fetchWorkflows() {
    return await axios.get("http://localhost:3000/workflows");
  }

  async function fetchForms() {
    return await axios.get("http://localhost:3000/forms");
  }

  async function fetchRequests() {
    return await axios.get("http://localhost:3000/requests");
  }

  useEffect(() => {
    const list = async () => {
      const response = await fetchRequests();
      const data = response.data;
      if (data) setRequestList(data);
      const found = data.find((r) => r.id == rid);
      if (found) {
        setRequest(found);
      }
    };
    list();
  }, [rid]);

  useEffect(() => {
    if (!request) return;
    const fetchWorkflowList = async () => {
      const response = await fetchWorkflows();
      const workflows = response.data;
      const found = workflows.find((w) => w.name == request.workflow);
      if (found) {
        setWorkflow(found);
      }
    };
    fetchWorkflowList();
  }, [request]);

  useEffect(() => {
    if (!workflow) return;

    // generate state machine out of bpmn xml
    const createStateMachine = async () => {
      try {
        const moddle = new BPMNModdle();
        const { rootElement } = await moddle.fromXML(workflow.bpmn);
        const process = rootElement.rootElements.find(
          (el) => el.$type === "bpmn:Process"
        );
        if (!process) return;
        const states = {};
        process.flowElements.forEach((el) => {
          if (
            el.$type === "bpmn:UserTask" ||
            el.$type === "bpmn:SendTask" ||
            el.$type === "bpmn:StartEvent" ||
            el.$type === "bpmn:EndEvent"
          ) {
            states[el.name] = { on: {} };
          }
          if (el.$type === "bpmn:SequenceFlow") {
            const from = el.sourceRef.name;
            const to = el.targetRef.name;
            if (states[from]) {
              states[from].on[`${el.name}`] = to;
            }
          }
        });
        const machine = createMachine({
          id: `${workflow.name}`,
          initial: request.state,
          states,
        });

        setStateMachine(machine);
      } catch (e) {
        console.error(e);
      }
    };

    createStateMachine();
  }, [workflow]);

  useEffect(() => {
    if (!request || !request.history) return;
    const fetchFormDetail = async () => {
      const response = await fetchForms();
      if (response.data) {
        const forms = response.data;
        const form = forms.find((f) => f.activityName == currentState);
        if (form) {
          setForm(form);
          const fdata = findFormData("Submission", request)
          
          setFormData(fdata)
        }
      }
    };
    fetchFormDetail();
  }, [currentState]);

  useEffect(() => {
    if (!stateMachine) return;
    try {
      // start the state machine
      const actor1 = createActor(stateMachine);
      actor1.subscribe((snapshot) => {
        console.log("Value:", snapshot.value);
      });
      actor1.start();
      actor1.send({ type: "Submit" });
      setCurrentState(actor1.getSnapshot().value);

      setActor(actor1);
    } catch (e) {
      console.error(e);
    }
  }, [stateMachine]);

  const validate = async (formInstance) => {
    if (!formInstance || !formInstance.current) return;

    // validate form
    let errors = [];
    const error = await formInstance.current.validate();

    if (Object.keys(error).length > 0) {
      /**
       * error only has id of field, we don't know what it is.
       * we try to replace those ids with keys which are meaningful enough.
       */
      for (const key of Object.keys(error)) {
        const field = findFieldKey(form.schema, key);
        if (!field) continue;
        errors.push({
          field: field.key,
          errors: error[key],
        });
      }
      return errors;
    }

    return true;
  };

  const onResubmit = async (formInstance) => {
   // validate
   validate(formInstance);

   // set previous state to done
   const dataToUpdate = {
     ...request,
     done: true
   }
   const res1 = await axios.put(`http://localhost:3000/requests/${request.id}`, dataToUpdate);
   
   // create current state data
   const formData = await formInstance.current._getState().data;
   const dataForCurrentState = {
     workflow: workflow.name,
     state: actor.getSnapshot().value,
     createdBy: localStorage.getItem("user"),
     createdDt: new Date(),
     form: form.name,
     formData: formData,
     done: true,
     history: [res1.data],
   };
   const res2 = await axios.post("http://localhost:3000/requests", dataForCurrentState);

   // create next state data
   actor.send({ type: "Resubmit" });
   setCurrentState(actor.getSnapshot().value);

   const dataForNextState = {
     workflow: workflow.name,
     state: actor.getSnapshot().value,
     createdBy: null,
     createdDt: null,
     form: null,
     formData: null,
     done: false,
     history: [res2.data],
   };
   const res3 = await axios.post("http://localhost:3000/requests", dataForNextState);

   alert(`request is now set to ${actor.getSnapshot().value} state`);
   navigate(`/request/detail/${res3.data.id}`);
  };

  const onVerify = async (formInstance) => {
   // validate
   validate(formInstance);

   // set previous state to done
   const dataToUpdate = {
     ...request,
     done: true
   }
   const res1 = await axios.put(`http://localhost:3000/requests/${request.id}`, dataToUpdate);
   
   // create current state data
   const formData = await formInstance.current._getState().data;
   const dataForCurrentState = {
     workflow: workflow.name,
     state: actor.getSnapshot().value,
     createdBy: localStorage.getItem("user"),
     createdDt: new Date(),
     form: form.name,
     formData: formData,
     done: true,
     history: [res1.data],
   };
   const res2 = await axios.post("http://localhost:3000/requests", dataForCurrentState);

   // create next state data
   actor.send({ type: "Verify" });
   setCurrentState(actor.getSnapshot().value);

   const dataForNextState = {
     workflow: workflow.name,
     state: actor.getSnapshot().value,
     createdBy: null,
     createdDt: null,
     form: null,
     formData: null,
     done: false,
     history: [res2.data],
   };
   const res3 = await axios.post("http://localhost:3000/requests", dataForNextState);

   alert(`request is now set to ${actor.getSnapshot().value} state`);
   navigate(`/request/detail/${res3.data.id}`);
  };

  const onReject = async (formInstance) => {
   // validate
   validate(formInstance);

   // set previous state to done
   const dataToUpdate = {
     ...request,
     done: true
   }
   const res1 = await axios.put(`http://localhost:3000/requests/${request.id}`, dataToUpdate);
   
   // create current state data
   const formData = await formInstance.current._getState().data;
   const dataForCurrentState = {
     workflow: workflow.name,
     state: actor.getSnapshot().value,
     createdBy: localStorage.getItem("user"),
     createdDt: new Date(),
     form: form.name,
     formData: formData,
     done: true,
     history: [res1.data],
   };
   const res2 = await axios.post("http://localhost:3000/requests", dataForCurrentState);

   // create next state data
   actor.send({ type: "Reject" });
   setCurrentState(actor.getSnapshot().value);

   const dataForNextState = {
     workflow: workflow.name,
     state: actor.getSnapshot().value,
     createdBy: null,
     createdDt: null,
     form: null,
     formData: null,
     done: false,
     history: [res2.data],
   };
   const res3 = await axios.post("http://localhost:3000/requests", dataForNextState);

   alert(`request is now set to ${actor.getSnapshot().value} state`);
   navigate(`/request/detail/${res3.data.id}`);
  };

  const onCancel = async (formInstance) => {
   // validate
   validate(formInstance);

   // set previous state to done
   const dataToUpdate = {
     ...request,
     done: true
   }
   const res1 = await axios.put(`http://localhost:3000/requests/${request.id}`, dataToUpdate);
   
   // create current state data
   const formData = await formInstance.current._getState().data;
   const dataForCurrentState = {
     workflow: workflow.name,
     state: actor.getSnapshot().value,
     createdBy: localStorage.getItem("user"),
     createdDt: new Date(),
     form: form.name,
     formData: formData,
     done: true,
     history: [res1.data],
   };
   const res2 = await axios.post("http://localhost:3000/requests", dataForCurrentState);

   // create next state data
   actor.send({ type: "Cancel" });
   setCurrentState(actor.getSnapshot().value);

   const dataForNextState = {
     workflow: workflow.name,
     state: actor.getSnapshot().value,
     createdBy: null,
     createdDt: null,
     form: null,
     formData: null,
     done: false,
     history: [res2.data],
   };
   const res3 = await axios.post("http://localhost:3000/requests", dataForNextState);

   alert(`request is now set to ${actor.getSnapshot().value} state`);
   navigate(`/request/detail/${res3.data.id}`);
  };

  const onRework = async (formInstance) => {
    // validate
    validate(formInstance);

    // set previous state to done
    const dataToUpdate = {
      ...request,
      done: true
    }
    const res1 = await axios.put(`http://localhost:3000/requests/${request.id}`, dataToUpdate);
    
    // create current state data
    const formData = await formInstance.current._getState().data;
    const dataForCurrentState = {
      workflow: workflow.name,
      state: actor.getSnapshot().value,
      createdBy: localStorage.getItem("user"),
      createdDt: new Date(),
      form: form.name,
      formData: formData,
      done: true,
      history: [res1.data],
    };
    const res2 = await axios.post("http://localhost:3000/requests", dataForCurrentState);

    // create next state data
    actor.send({ type: "Rework" });
    setCurrentState(actor.getSnapshot().value);

    const dataForNextState = {
      workflow: workflow.name,
      state: actor.getSnapshot().value,
      createdBy: null,
      createdDt: null,
      form: null,
      formData: null,
      done: false,
      history: [res2.data],
    };
    const res3 = await axios.post("http://localhost:3000/requests", dataForNextState);

    alert(`request is now set to ${actor.getSnapshot().value} state`);
    navigate(`/request/detail/${res3.data.id}`);
  };

  const onApprove = async (formInstance) => {
   // validate
   validate(formInstance);

   // set previous state to done
   const dataToUpdate = {
     ...request,
     done: true
   }
   const res1 = await axios.put(`http://localhost:3000/requests/${request.id}`, dataToUpdate);
   
   // create current state data
   const formData = await formInstance.current._getState().data;
   const dataForCurrentState = {
     workflow: workflow.name,
     state: actor.getSnapshot().value,
     createdBy: localStorage.getItem("user"),
     createdDt: new Date(),
     form: form.name,
     formData: formData,
     done: true,
     history: [res1.data],
   };
   const res2 = await axios.post("http://localhost:3000/requests", dataForCurrentState);

   // create next state data
   actor.send({ type: "Approve" });
   setCurrentState(actor.getSnapshot().value);

   const dataForNextState = {
     workflow: workflow.name,
     state: actor.getSnapshot().value,
     createdBy: null,
     createdDt: null,
     form: null,
     formData: null,
     done: false,
     history: [res2.data],
   };
   const res3 = await axios.post("http://localhost:3000/requests", dataForNextState);

   alert(`request is now set to ${actor.getSnapshot().value} state`);
   navigate(`/request/detail/${res3.data.id}`);
  };

  return (
    <div className="flex flex-col w-full h-full">
      <div className="p-5 bg-gray-200 space-x-3">
        <label className="text-lg">
          Workflow: {request ? request.workflow : ""}
        </label>
      </div>
      <div className="w-full h-full flex justify-between">
        <div className="flex-1 flex flex-col p-5">
          <h3 className="text-1xl font-bold">Current State</h3>
          <div className="">
            {/*<pre>{JSON.stringify(stateMachine, null, 2)}</pre>*/}
            {form && workflow ? (
              <FormLoader
                form={form}
                formData={formData}
                onResubmit={onResubmit}
                onRework={onRework}
                onVerify={onVerify}
                onReject={onReject}
                onCancel={onCancel}
                onApprove={onApprove}
              />
            ) : (
              <></>
            )}
          </div>
          <div>
            <h3 className="text-1xl font-bold">History</h3>
            <div className="shadow-md sm:rounded-lg p-10">
              <RequestList
                list={request ? request.history : []}
                getLink={(request) => {
                  return `/request/detail/${request.id}`
                }}
              />
            </div>
          </div>
        </div>
        <div className="bg-gray-100 w-[800px]">
          {workflow ? (
            <BPMNViewer xml={workflow.bpmn} selectedNode={currentState} />
          ) : (
            <></>
          )}
        </div>
      </div>
    </div>
  );
}
