import axios from "axios";
import { useState, useEffect } from "react";
import BPMNModdle from "bpmn-moddle";
import { createMachine, createActor } from "xstate";

import { Dropdown } from "../../components/Dropdown";
import { BPMNViewer } from "../../components/BPMNViewer";
import { FormLoader } from "../../components/FormLoader";
import { findFieldKey, generateId } from "../../utils/util";

export function RequestNewPage() {
  const [workflowList, setWorkflowList] = useState();
  const [selectedWorkflow, setSelectedWorkflow] = useState(null);
  const [stateMachine, setStateMachine] = useState(null);
  const [currentState, setCurrentState] = useState(null);
  const [form, setForm] = useState(null);
  const [actor, setActor] = useState(null);

  async function fetchWorkflows() {
    return await axios.get("http://localhost:3000/workflows");
  }

  async function fetchForms() {
    return await axios.get("http://localhost:3000/forms");
  }

  useEffect(() => {
    const list = async () => {
      const response = await fetchWorkflows();
      if (response.data && response.data.length > 0) {
        setWorkflowList(response.data);
        setSelectedWorkflow(response.data[0]);
      }
    };
    list();
  }, []);

  useEffect(() => {
    if (!selectedWorkflow) return;

    // generate state machine out of bpmn xml
    const createStateMachine = async () => {
      try {
        const moddle = new BPMNModdle();
        const { rootElement } = await moddle.fromXML(selectedWorkflow.bpmn);
        const process = rootElement.rootElements.find(
          (el) => el.$type === "bpmn:Process"
        );
        if (!process) return;
        const states = {};
        process.flowElements.forEach((el) => {
          if (
            el.$type === "bpmn:Task" ||
            el.$type === "bpmn:UserTask" ||
            el.$type === "bpmn:SendTask" ||
            el.$type === "bpmn:StartEvent" ||
            el.$type === "bpmn:EndEvent"
          ) {
            states[el.name] = { on: {} };
          }
          if (el.$type === "bpmn:SequenceFlow") {
            const from = el.sourceRef.name;
            const to = el.targetRef.name;
            if (states[from]) {
              states[from].on[`${el.name}`] = to;
            }
          }
        });
        const machine = createMachine({
          id: `${selectedWorkflow.name}`,
          initial: Object.keys(states)[0],
          states,
        });
        
        setStateMachine(machine);
      } catch (e) {
        console.error(e);
      }
    };

    createStateMachine();
  }, [selectedWorkflow]);

  useEffect(() => {
    const fetchFormDetail = async () => {
      const response = await fetchForms();
      if (response.data) {
        const forms = response.data;
        const form = forms.find((f) => f.activityName == currentState);
        if (form) {
          setForm(form);
        }
      }
    };
    fetchFormDetail();
  }, [currentState]);

  useEffect(() => {
    if (!stateMachine) return;
    try {
      // start the state machine
      const actor1 = createActor(stateMachine);
      actor1.subscribe((snapshot) => {
        console.log("Value:", snapshot.value);
      });
      actor1.start();
      actor1.send({ type: "Start" });
      setCurrentState(actor1.getSnapshot().value);

      setActor(actor1);
    } catch (e) {
      console.error(e);
    }
  }, [stateMachine]);

  const onSubmit = async (formInstance) => {
    if (!formInstance || !formInstance.current) return;

    // validate form
    let errors = [];
    const error = await formInstance.current.validate();

    if (Object.keys(error).length > 0) {

      /**
       * error only has id of field, we don't know what it is.
       * we try to replace those ids with keys which are meaningful enough.
       */
      for (const key of Object.keys(error)) {
        const field = findFieldKey(form.schema, key);
        if (!field) continue;
        errors.push({
          field: field.key,
          errors: error[key],
        });
      }
      return;
    }

    // create data for the current state
    const formData = await formInstance.current._getState().data
    const dataForCurrentState = {
      workflow: selectedWorkflow.name,
      state: actor.getSnapshot().value,
      createdBy: localStorage.getItem("user"),
      createdDt: new Date(),
      form: form.name,
      formData: formData,
      done: true,
      history: []
    };
    const res1 = await axios.post("http://localhost:3000/requests", dataForCurrentState);

    // create data for next state
    actor.send({type: "Submit"})
    setCurrentState(actor.getSnapshot().value)

    const dataForNextState = {
      workflow: selectedWorkflow.name,
      state: actor.getSnapshot().value,
      createdBy: null,
      createdDt: null,
      form: null,
      formData: null,
      done: false,
      history: [
        res1.data
      ]
    }

    const res2 = await axios.post(`http://localhost:3000/requests`, dataForNextState);
    alert("request is submitted")
    window.location.href=`/request/detail/${res2.data.id}`
  };

  const onResubmit = () => {};
  const onReject = () => {};
  const onCancel = () => {};
  const onRework = () => {};
  const onApprove = () => {};

  return (
    <div className="flex flex-col w-full h-full">
      <div className="p-5 bg-gray-200 space-x-3">
        <label className="text-lg">Select a workflow</label>
        <Dropdown
          optionList={workflowList}
          selectedOption={selectedWorkflow}
          setSelectedOption={setSelectedWorkflow}
        />
      </div>
      <div className="w-full h-full flex justify-between">
        <div className="flex-1">
          {/*<pre>{JSON.stringify(stateMachine, null, 2)}</pre>*/}
          {form && selectedWorkflow ? (
            <FormLoader
              form={form}
              onSubmit={onSubmit}
              onResubmit={onResubmit}
              onRework={onRework}
              onReject={onReject}
              onCancel={onCancel}
              onApprove={onApprove}
            />
          ) : (
            <></>
          )}
        </div>
        <div className="bg-gray-100 w-[800px]">
          {selectedWorkflow ? (
            <BPMNViewer
              xml={selectedWorkflow.bpmn}
              selectedNode={currentState}
            />
          ) : (
            <></>
          )}
        </div>
      </div>
    </div>
  );
}
