import axios from "axios";
import { useState, useEffect } from "react";
import { BPMNViewer } from "../../components/BPMNViewer";
import { RequestList } from "../../components/RequestList";
import { FormLoader } from "../../components/FormLoader";
import { useParams } from "react-router-dom";

export function RequestDetailPage() {
  const { rid } = useParams();
  const [request, setRequest] = useState(null);
  const [workflow, setWorkflow] = useState(null);
  const [currentState, setCurrentState] = useState(null);
  const [form, setForm] = useState(null);
  const [formData, setsFormData] = useState(null);

  async function fetchWorkflows() {
    return await axios.get("http://localhost:3000/workflows");
  }

  async function fetchForms() {
    return await axios.get("http://localhost:3000/forms");
  }

  async function fetchRequests() {
    return await axios.get("http://localhost:3000/requests");
  }

  useEffect(() => {
    const list = async () => {
      const response = await fetchRequests();
      const requests = response.data;
      const found = requests.find((r) => r.id == rid);
      if (found) {
        setRequest(found);
      }
    };
    list();
  }, [rid]);

  useEffect(() => {
    if (!request) return;
    const fetchWorkflowList = async () => {
      const response = await fetchWorkflows();
      const workflows = response.data;
      const found = workflows.find((w) => w.name == request.workflow);
      if (found) {
        setWorkflow(found);
      }
    };
    fetchWorkflowList();
    setCurrentState(request.state)
  }, [request]);

  useEffect(() => {

    if (!currentState) return
    
    //console.log(currentState)

    const fetchFormDetail = async () => {
      const response = await fetchForms();
      if (response.data) {
        const forms = response.data;
        const form1 = forms.find((f) => f.activityName == currentState);
        if (form1) {
          setForm(form1);
        }
      }
    };
    fetchFormDetail();

    if (!request) return
      setsFormData(request.formData)
  }, [currentState]);


  return (
    <div className="flex flex-col w-full h-full">
      <div className="p-5 bg-gray-200 space-x-3">
        <label className="text-lg">Workflow: {request ? request.workflow : ''}</label>
      </div>
      <div className="w-full h-full flex justify-between">
        <div className="flex flex-col justify-between p-5">
          <div className="font-bold text-1xl">Current State</div>
          <div className="flex-1">
            {/*<pre>{JSON.stringify(stateMachine, null, 2)}</pre>*/}
            {form ? <FormLoader form={form} formData={formData} /> : <>NO</>}
          </div>

          <div>
            <h3 className="text-1xl font-bold">History</h3>
            {request ? <RequestList list={request.history} getLink={(request) => {
              return `/request/detail/${request.id}`
            }} /> : <></>}
          </div>
        </div>
        <div className="bg-gray-100 w-[800px]">
          {workflow ? (
            <BPMNViewer xml={workflow.bpmn} selectedNode={currentState} />
          ) : (
            <></>
          )}
        </div>
      </div>
    </div>
  );
}
