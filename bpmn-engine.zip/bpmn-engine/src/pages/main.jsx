export function MainPage() {
  return (
    <div className="flex justify-center items-center space-x-5 w-full h-full">
      <button
        className="w-96 h-16 bg-red-700 text-white flex justify-center items-center cursor-pointer"
        onClick={() => {
          localStorage.setItem("user", "admin")
          window.location.href = "/admin"
        }}
      >
        Login as Admin
      </button>
      <button
        className="w-96 h-16 bg-red-700 text-white flex justify-center items-center cursor-pointer"
        onClick={() => {
          localStorage.setItem("user", "hod")
          window.location.href = "/hod"
        }}
      >
        Login as HOD
      </button>
      <button
        className="w-96 h-16 bg-red-700 text-white flex justify-center items-center cursor-pointer"
        onClick={() => {
          localStorage.setItem("user", "verifier")
          window.location.href = "/verifier"
        }}
      >
        Login as SGT Verifier
      </button>
      <button
        className="w-96 h-16 bg-red-700 text-white flex justify-center items-center cursor-pointer"
        onClick={() => {
          localStorage.setItem("user", "requestor")
          window.location.href = "/requestor"
        }}
      >
        Login as Requestor
      </button>
    </div>
  );
}
