import axios from "axios";
import { useEffect, useState } from "react";
import { RequestList } from "../../components/RequestList";

export function HODPage() {
  const [requestList, setRequestList] = useState([]);

  useEffect(() => {
    const fetchRequests = async () => {
      const response = await axios.get("http://localhost:3000/requests")
      const data = response.data
      if (data) {
        const dataForHOD = data.filter(r => r.state == "HOD Review" && r.done == false)
        setRequestList(dataForHOD)
      }
    }
    fetchRequests()
  }, [])

  return (
    <div className="shadow-md sm:rounded-lg p-10">
      <RequestList list={requestList} getLink={(request) => {
        if (request.state == "HOD Review") {
          return `/request/edit/${request.id}`
        } else {
          return `/request/detail/${request.id}`
        }
      }}/>
    </div>
  );
}
