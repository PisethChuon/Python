import { useNavigate } from "react-router-dom";
import { RequestList } from "../../components/RequestList";
import { useEffect, useState } from "react";
import axios from "axios";

export function RequestorPage() {
  const navigate = useNavigate();
  const [requestList, setRequestList] = useState([]);

  useEffect(() => {
    const fetchRequests = async () => {
      const response = await axios.get("http://localhost:3000/requests")
      const data = response.data
      if (data) {
        setRequestList(data.filter(r => r.done == false))
      }
    }
    fetchRequests()
  }, [])

  return (
    <div className="shadow-md sm:rounded-lg p-10">
      <div className="flex justify-end">
        <button
          type="button"
          className="focus:outline-none text-white bg-green-600 hover:bg-red-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-900"
          onClick={() => {
            navigate("/request/new");
          }}
        >
          New
        </button>
      </div>
      <RequestList list={requestList} getLink={(request) => {
        if (request.state == "Requestor Rework") {
          return `/request/edit/${request.id}`
        }
        return `/request/detail/${request.id}`
      }} />
    </div>
  );
}
