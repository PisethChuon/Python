import { useParams } from "react-router-dom";
import { FormDesigner } from "../../../components/FormDesigner";
import PropTypes from "prop-types";
import { useEffect, useState } from "react";
import axios from "axios";
import { ACTIONS, getActivities } from "../../../utils/util";
import { Dropdown } from "../../../components/Dropdown";

export function FormEditPage() {
  const { wid } = useParams();
  const [selectedWorkflow, setSelectedWorkflow] = useState(null);
  const [activities, setActivities] = useState([]);
  const [selectedActivity, setSelectedActivity] = useState(null);
  const [formSchema, setFormSchema] = useState(null);
  const [isSubmit, setIsSubmit] = useState(false);
  const [isResubmit, setIsResubmit] = useState(false);
  const [isReject, setIsReject] = useState(false);
  const [isVerify, setIsVerify] = useState(false);
  const [isRework, setIsRework] = useState(false);
  const [isCancel, setIsCancel] = useState(false);
  const [isApprove, setIsApprove] = useState(false);

  useEffect(() => {
    const fetchDetail = async () => {
      const response = await axios.get(
        `http://localhost:3000/workflows/${wid}`
      );
      if (response.data) {
        setSelectedWorkflow(response.data);
      }
    };
    fetchDetail();
  }, []);

  useEffect(() => {
    if (!selectedWorkflow) return;
    const fetchActivities = async () => {
      const temp = await getActivities(selectedWorkflow.bpmn);
      if (temp && temp.length > 0) {
        setActivities(temp);
        setSelectedActivity(temp[0]);
      }
    };
    fetchActivities();
  }, [selectedWorkflow]);

  useEffect(() => {
    if (!selectedActivity) return;
    const fetchFormSchema = async () => {
      const response = await axios.get("http://localhost:3000/forms");
      const forms = response.data;
      const findForms = forms.filter(
        (f) => f.activityName == selectedActivity.name
      );
      if (findForms.length > 0) {
        const form = findForms[0];

        // clear all
        setIsSubmit(false);
        setIsResubmit(false);
        setIsRework(false);
        setIsVerify(false);
        setIsCancel(false);
        setIsApprove(false);
        setIsReject(false);

        // now set action according to data
        if (form.actions.includes(ACTIONS.SUBMIT)) setIsSubmit(true);
        if (form.actions.includes(ACTIONS.RESUBMIT)) setIsResubmit(true);
        if (form.actions.includes(ACTIONS.REWORK)) setIsRework(true);
        if (form.actions.includes(ACTIONS.VERIFY)) setIsVerify(true);
        if (form.actions.includes(ACTIONS.REJECT)) setIsReject(true);
        if (form.actions.includes(ACTIONS.CANCEL)) setIsCancel(true);
        if (form.actions.includes(ACTIONS.APPROVE)) setIsApprove(true);

        setFormSchema(form.schema);
      }
    };

    fetchFormSchema();
  }, [selectedActivity]);

  const onSave = async (schema) => {
    const actionList = [];
    if (isSubmit) actionList.push(ACTIONS.SUBMIT)
    if (isResubmit) actionList.push(ACTIONS.RESUBMIT)
    if (isReject) actionList.push(ACTIONS.REJECT)
    if (isRework) actionList.push(ACTIONS.REWORK)
    if (isCancel) actionList.push(ACTIONS.CANCEL)
    if (isVerify) actionList.push(ACTIONS.VERIFY)
    if (isApprove) actionList.push(ACTIONS.APPROVE)

    const data = {
      activityName: selectedActivity.name,
      actions: actionList,
      schema: schema,
    };
    const response = await axios.get(`http://localhost:3000/forms`);
    const forms = response.data;
    const findForms = forms.filter(
      (f) => f.activityName == selectedActivity.name
    );

    if (findForms.length == 0) {
      await axios.post("http://localhost:3000/forms", data);
    } else {
      const form = findForms[0];
      await axios.put(`http://localhost:3000/forms/${form.id}`, data);
    }

    alert("saved successfully")
  };

  const onToggleSubmit = () => {
    setIsSubmit(!isSubmit);
  };

  const onToggleResubmit = () => {
    setIsResubmit(!isResubmit);
  };

  const onToggleReject = () => {
    setIsReject(!isReject);
  };

  const onToggleVerify = () => {
    setIsVerify(!isVerify);
  };

  const onToggleCancel = () => {
    setIsCancel(!isCancel);
  };

  const onToggleRework = () => {
    setIsRework(!isRework);
  };

  const onToggleApprove = () => {
    setIsApprove(!isApprove);
  };

  return (
    <div className="w-full h-full p-5">
      <div>
        <Dropdown
          optionList={activities}
          selectedOption={selectedActivity}
          setSelectedOption={setSelectedActivity}
        />
      </div>
      <div>
        <div className="flex gap-3 my-4">
          <div className="flex items-center">
            <input
              checked={isSubmit}
              onChange={onToggleSubmit}
              id="submit"
              type="checkbox"
              className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded-sm focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
            />
            <label
              htmlFor="submit"
              className="ms-2 text-sm font-medium text-gray-900 dark:text-gray-300"
            >
              {ACTIONS.SUBMIT}
            </label>
          </div>
          <div className="flex items-center">
            <input
              checked={isResubmit}
              onChange={onToggleResubmit}
              id="resubmit"
              type="checkbox"
              className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded-sm focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
            />
            <label
              htmlFor="resubmit"
              className="ms-2 text-sm font-medium text-gray-900 dark:text-gray-300"
            >
              {ACTIONS.RESUBMIT}
            </label>
          </div>

          <div className="flex items-center">
            <input
              checked={isReject}
              onChange={onToggleReject}
              id="reject"
              type="checkbox"
              className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded-sm focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
            />
            <label
              htmlFor="reject"
              className="ms-2 text-sm font-medium text-gray-900 dark:text-gray-300"
            >
              {ACTIONS.REJECT}
            </label>
          </div>

          <div className="flex items-center">
            <input
              checked={isVerify}
              onChange={onToggleVerify}
              id="verify"
              type="checkbox"
              className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded-sm focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
            />
            <label
              htmlFor="verify"
              className="ms-2 text-sm font-medium text-gray-900 dark:text-gray-300"
            >
              {ACTIONS.VERIFY}
            </label>
          </div>

          <div className="flex items-center">
            <input
              checked={isCancel}
              onChange={onToggleCancel}
              id="cancel"
              type="checkbox"
              className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded-sm focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
            />
            <label
              htmlFor="cancel"
              className="ms-2 text-sm font-medium text-gray-900 dark:text-gray-300"
            >
              {ACTIONS.CANCEL}
            </label>
          </div>

          <div className="flex items-center">
            <input
              checked={isRework}
              onChange={onToggleRework}
              id="rework"
              type="checkbox"
              className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded-sm focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
            />
            <label
              htmlFor="rework"
              className="ms-2 text-sm font-medium text-gray-900 dark:text-gray-300"
            >
              {ACTIONS.REWORK}
            </label>
          </div>

          <div className="flex items-center">
            <input
              checked={isApprove}
              onChange={onToggleApprove}
              id="approve"
              type="checkbox"
              value=""
              className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded-sm focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
            />
            <label
              htmlFor="approve"
              className="ms-2 text-sm font-medium text-gray-900 dark:text-gray-300"
            >
              {ACTIONS.APPROVE}
            </label>
          </div>
        </div>
        <FormDesigner formSchema={formSchema} onSave={onSave} />
      </div>
    </div>
  );
}

FormEditPage.propTypes = {
  activities: PropTypes.string,
};
