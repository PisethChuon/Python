import { WorkflowDesigner } from "../../../components/WorkflowDesigner"

export function WorkflowNewPage() {
    return (
    <div className="w-full h-full">
        <WorkflowDesigner workflow={null}/>
    </div>
    )
}